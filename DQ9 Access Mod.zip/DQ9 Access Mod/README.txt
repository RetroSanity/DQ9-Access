DRAGON QUEST IX ACCESS MOD - READ ME
====================================

WHAT THIS MOD IS
----------------
Dragon Quest IX Access is a screen reader mod for Dragon Quest IX: Sentinels of the Starry Skies
(the US version of the game) on the Nintendo DS. It lets you play the whole game without seeing
the screen. It is a Lua script that runs inside the BizHawk emulator (EmuHawk). It reads the
game's memory and speaks what is on screen through the emulator's speech feature.

You play the game on your controller as normal. The mod talks to you, tells you where things
are, gives you directions, and can walk you to places. Keyboard keys and controller shortcuts
give you extra information whenever you want it.


WHAT IS IN THIS FOLDER
----------------------
dq9-access.lua        The mod itself. This is the file you open in EmuHawk.
dq9-access-maps.bin   The walls and floors of every map, taken from the game. The mod needs it to
                      plan routes and walk you to places. Keep it in the same folder as the script.
README.txt            This file.

The mod makes these files by itself in the same folder as you play:
dq9-access-places.txt  Your marks, the names of people you have talked to, places it has learned,
                       and the treasure chests you have opened. Keep it to keep them.
dq9-access-log.txt     Snapshots saved with the C key, for reporting problems.
dq9-access-speech.txt  Only made if you turn on the speech log (see "IF SOMETHING IS SILENT").


WHAT YOU NEED
-------------
- EmuHawk (BizHawk) with speech support: a build that gives Lua scripts the speech.say
  command, like the one you already use. The normal BizHawk download cannot speak.
- The melonDS core, which is the one EmuHawk uses for DS games.
- Your own copy of Dragon Quest IX: Sentinels of the Starry Skies (USA). It is not included.
- An Xbox-style controller is recommended. The keyboard works too.


HOW TO INSTALL
--------------
1. Copy this whole folder ("DQ9 Access Mod") anywhere you like. For example, put it in your
   BizHawk folder next to EmuHawk.exe. Keep the three files together.
2. Start EmuHawk and load your Dragon Quest IX game (File, Open ROM).
3. Open the Lua Console: Tools menu, then Lua Console.
4. In the Lua Console, choose Script, then Open Script (or press Ctrl+O), and pick
   dq9-access.lua in this folder.
5. You will hear "Dragon Quest 9 access is running. Press K for keys."
6. Close or move the Lua Console out of the way and play. Next time, EmuHawk remembers the
   script: in the Lua Console, File, Recent Scripts lists it.

To stop the mod, close the Lua Console or remove the script from its list.
To update the mod, replace dq9-access.lua (and dq9-access-maps.bin if a new one comes with it),
then in the Lua Console double-click the script twice to stop it and start it again.
If you move the mod to a new folder and want to keep your marks, copy dq9-access-places.txt too.


WHAT IT READS BY ITSELF
-----------------------
Stories and messages
- Every message box, one page at a time, with the name of whoever is talking.
- Yes or no questions, and the answer your cursor is on.
- Choices in a conversation, such as Erinn's "Stay at the inn, 1 of 4".
- Windows with a message and nothing to pick, such as being awarded an accolade.
- The name of each place when you arrive, and the building you went into, such as
  "Angel Falls, Inn".

Menus
- Every menu with a cursor: the field menu, items, the bag, spells, the church, and others.
  It says the option and where it is in the list, such as "Spells, 2 of 6". Options you cannot
  pick right now are called "unavailable".
- Using an item: "To who? retro, 1 of 4", then that person's HP, such as "33 of 43 HP".
- Shops: Buy, Sell or Cancel, then each item with its price. When selling it also says how
  many you have.
- The equipment screen. For each slot it says what is in it, such as
  "Shield: Leather shield, 2 of 8". In the list of things you can put on, each item is followed
  by what it would do to that person, such as "Soldier's sword, row 1, column 1.
  Attack up 9, 25 to 34". "equipped" means they already wear it. "cannot equip" means they
  cannot use it.
- The attributes screen, Allocate Skill Points (each skill, the points you are adding and its
  total), and Battle Records.
- The opening movie, the title screen menu (with or without an adventure log), and making your
  character: each choice with a short description of how it looks, and the name keyboard.
- Patty's "Create a companion" screens at the Quester's Rest, and her Call Up list.

Battles
- Every battle message, one after another.
- "Fight, 1 of 4" when the battle waits for your command.
- Whose turn it is each time the command list comes up, such as "Hero's turn. Attack, 1 of 6".
- Experience and gold earned, and each attribute that goes up when you gain a level.

Walking about
- "Blocked" when you walk into a wall.
- People and monsters that come close to you, with the direction.


THE NEARBY LIST (the "E list")
------------------------------
The mod keeps a list of everything around you, sorted into categories, nearest first:
- People: described by how they look, such as "old man with a walking stick" or "dog". Once you
  talk to someone who gives their name, they are called by name. People who matter to the story
  are called "story character".
- Monsters: the monsters walking about in the open.
- Items: treasure chests, pots and barrels, cupboards, and shiny things lying on the ground.
  A chest you opened is called "treasure chest, opened".
- Sparkly spots: the glittering spots in the fields, with the item each one gives.
- Events: places where walking in starts a story scene.
- Doors: every door, named by building when the game names it, such as "Inn door". Where many
  doors have no name, they are named by the side they are on, such as "left door, upper".
- Exits: every way out, such as "exit to the open field". Exits on stairs are called
  "stairs up to ..." or "stairs down to ...". Where several exits lead to the same place, only
  the nearest is listed, such as "archway into the Observatory, nearest of 6".
- Objects: signs, statues and the like. A sign you have read is called by what it says.
- Marks: spots you saved yourself with the M key.

Pick something from the list, then:
- ask for directions ("5 steps up, 3 steps right"),
- ask for the route there, step by step, to walk yourself, or
- let the mod walk you there. It plans a way around walls, up and down stairs, and walks you into
  doors from the right side so they open. Pressing any controller button takes over again.

Directions are given as D-pad presses: "3 steps up" means push up for about three steps. Up,
down, left and right are as the screen faces, so they stay right when the camera is at an angle.


KEYBOARD KEYS
-------------
R   Repeat the last thing said.
Q   Stop speaking.
W   Where am I: the place and your position.
H   Health and magic for the whole party (works in battles too).
S   Attributes for the whole party.
E   What everyone has equipped.
G   Gold.
I   Repeat the last information window, such as experience earned.
O   Read every option in the menu that is open.
V   Next category of the nearby list.
N   Next thing in the category, nearest first, with directions.
B   Previous thing in the category.
D   Directions to the thing you picked, from where you are now.
P   The route to the thing you picked, step by step, for you to walk yourself.
J   Walk there for you. Press J again, or any controller button, to stop.
M   Mark this spot so you can find it again later (category Marks).
T   Turn the "blocked" and "next to you" alerts on or off.
C   Save a snapshot of what the game is showing to dq9-access-log.txt.
K   Hear the list of keys.


CONTROLLER BUTTONS (Xbox-style controller)
------------------------------------------
Play the game with the controller as normal. The mod adds these shortcuts:

Hold the left trigger (LT), then:
  D-pad right   Next category of the nearby list, such as "People, 5".
  D-pad left    Previous category.
  D-pad down    Next thing in that category, nearest first, with its directions.
  D-pad up      Previous thing.
  Press in the left stick (L3)   Walk to the thing you picked. Press it again to stop.
  Press in the right stick (R3)  Your gold.
While the left trigger is held, the D-pad does not move you or the menus.

Press in the right stick (R3) without the trigger:
  - When you have picked something from the list: the route to it, step by step.
  - When nothing is picked: your gold.
  - In a battle: everyone's health and magic.

Any other controller button stops the mod walking for you.


IF SOMETHING IS SILENT
----------------------
Press C while it is on screen. That saves a snapshot to dq9-access-log.txt in this folder.
Send that file, and say what was on screen, so it can be fixed.
To keep a record of everything the mod says, make an empty file called dq9-access-debug.txt in
this folder. Everything spoken is then also written to dq9-access-speech.txt.
