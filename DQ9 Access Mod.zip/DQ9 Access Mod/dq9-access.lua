-- dq9-access.lua  -  Dragon Quest IX: Sentinels of the Starry Skies (US, ROM code YDQE)
-- A screen reader for BizHawk (melonDS core). Open this file from Tools > Lua Console.
--
-- WHAT IT READS OUT
--   * Every message box, page by page, with the speaker's name  (story, people, battle messages)
--   * Cursor menus: field menu, battle commands, spells, items, the bag, the church, and others
--     built the same way, plus the title screen
--   * Yes / No questions
--   * The place name whenever you enter a new area or room
--   * "Blocked" when you walk into a wall (can be switched off)
--   * People who come right next to you
--
-- KEYBOARD COMMANDS (play the game on your controller; these are keys on the keyboard)
--   R  repeat the last thing said            Q  stop speaking
--   W  where am I (area, room, position)     H  party health and magic
--   G  gold                                  I  repeat the last information window
--   O  read every option in the current menu
--   N  next nearby thing (people, doors you have used, your marks)
--   B  previous nearby thing                 D  directions to the selected thing again
--   J  walk to the thing you picked with N or B (any controller button stops it)
--   M  mark this spot, so you can find it again later
--   E  what everyone is wearing and holding
--   T  switch wall bump and "someone nearby" alerts on or off
--   C  capture a debug snapshot to dq9-access-log.txt (send me that file if something is silent)
--   K  list these keys
--
-- DIRECTIONS are given the way you walk: "up" means push up on the D-pad, "right" means push right.
-- The script turns the game's camera into those words for you, so they stay right even when the
-- camera is at an angle.
--
-- HOW IT WORKS (for whoever maintains this)
-- Everything here was found by running the US ROM and watching memory change. The game builds all
-- of its text as plain ASCII with small <TAG> codes before drawing it, so the script reads the
-- game's own finished words straight out of RAM:
--   0x0211819C  the message box text (pages separated by bytes 0D FF)
--   0x02115348  pointer to the start of the page on screen, 0x0211534C to its end
--   0x02118FFC  the menu markup buffer, e.g. "<CURSOR=1><N=0>Fight</N>\n<N=1>Examine</N>..."
--   0x020FB3FC  current map code, e.g. "M01M0100";  0x022A4266  map name shown on screen
--   0x020F33E0  pointer to the player object; position (fixed point /4096) at +0x44 +0x48 +0x4C
--   0x0210A134  camera position (x, y, z) - used to work out which way "up" is on screen
--   0x02107600  table of people/objects on the map, count at 0x02107680, position at +0x24
--   0x020F3888  first party record name; records are 0x964 bytes apart
--   0x020F6D48  gold;  0x020EF0E8  1 while a battle is running
-- Anything read from memory is checked before it is spoken; a check that fails stays silent.

------------------------------------------------------------------------------ settings ------
KEYS = {
	repeat_last = "R", stop = "Q", where = "W", party = "H", gold = "G", info = "I",
	options = "O", next_thing = "N", prev_thing = "B", directions = "D", mark = "M",
	alerts = "T", capture = "C", help = "K", equipment = "E", walk = "J", stats = "S", category = "V", route = "P",
}
SAY_POSITION_IN_MENUS = true   -- add "2 of 6" after a menu option
ALERTS_ON = true               -- wall bumps and people next to you
PLACES_FILE = "dq9-access-places.txt"
LOG_FILE = "dq9-access-log.txt"

------------------------------------------------------------------------------ memory --------
BASE, SIZE = 0x02000000, 0x400000
local function inram(a, n) return a and a >= BASE and a + (n or 1) <= BASE + SIZE end
local function u8(a)  if not inram(a, 1) then return 0 end return mainmemory.read_u8(a - BASE) end
local function u16(a) if not inram(a, 2) then return 0 end return mainmemory.read_u16_le(a - BASE) end
local function u32(a) if not inram(a, 4) then return 0 end return mainmemory.read_u32_le(a - BASE) end
local function s32(a) if not inram(a, 4) then return 0 end return mainmemory.read_s32_le(a - BASE) end

-- read_bytes_as_array is 1-based in BizHawk; this also copes if a build hands back 0-based.
local function read_bytes(a, n)
	if not inram(a, n) then return {} end
	local t = mainmemory.read_bytes_as_array(a - BASE, n)
	if t[0] ~= nil then
		local o = {}
		for i = 0, n - 1 do o[i + 1] = t[i] end
		return o
	end
	return t
end

-- A zero-terminated string, raw bytes kept (the game's control codes use bytes like 0xFF).
local function cstring(a, maxlen)
	maxlen = maxlen or 600
	local parts, got = {}, 0
	while got < maxlen do
		local n = math.min(64, maxlen - got)
		local t = read_bytes(a + got, n)
		if #t == 0 then break end
		local stop
		for i = 1, #t do if t[i] == 0 then stop = i break end end
		if stop then
			if stop > 1 then parts[#parts + 1] = string.char(table.unpack(t, 1, stop - 1)) end
			break
		end
		parts[#parts + 1] = string.char(table.unpack(t, 1, #t))
		got = got + n
	end
	return table.concat(parts)
end

local function printable(s)
	return s ~= "" and not s:find("[^%w%s%p]")
end

------------------------------------------------------------------------------ speech --------
-- This project's EmuHawk build provides a global `speech` table: speech.say(text, interrupt) and
-- speech.stop(). interrupt true cuts off what is being said; false queues behind it.
local last_said, frame = "", 0
SPEECH_LOG = "dq9-access-speech.txt"
local speech_log_on = false   -- turned on when a file called dq9-access-debug.txt is in this folder
do local f = io.open("dq9-access-debug.txt", "r") if f then speech_log_on = true f:close() end end
local function log_line(text)
	if not speech_log_on then return end
	local f = io.open(SPEECH_LOG, "a")
	if f then f:write(os.date("%H:%M:%S "), text, "\n") f:close() end
end
local function say(text, interrupt)
	if not text or text == "" then return end
	last_said = text
	console.log(text)
	log_line((interrupt == false and "+ " or "! ") .. text)
	if speech and speech.say then
		pcall(function() speech.say(text, interrupt ~= false) end)
	end
end
local function queue(text) say(text, false) end
local function stop_speech() if speech and speech.stop then pcall(function() speech.stop() end) end end

------------------------------------------------------------------------------ text ----------
-- The game's font has named glyphs written as <tags>. These are the ones that stand for characters.
GLYPH = {
	["1"] = "'", ["11"] = '"', [","] = ",", ["-"] = "-", ["/"] = "/", ["]"] = "[", ["..."] = "...",
	["_,"] = ",", [":"] = ":", [";"] = ";", ["%"] = "%", ["?"] = "?", ["!"] = "!", ["_%_"] = "%",
	["_66"] = '"', ["_99"] = '"', ["66_"] = '"', ["99_"] = '"', ["DE66"] = '"', ["DE99"] = '"',
	["_6"] = "'", ["_9"] = "'", ["6_"] = "'", ["9_"] = "'", ["6"] = "'", ["9"] = "'",
	["!_"] = "!", ["?_"] = "?", [",_"] = ",", [":_"] = ":", [";_"] = ";", ["%_"] = "%",
	["..._"] = "...", ["_,,"] = ",", [",,_"] = ",", ["^?"] = "?", ["_^?"] = "?", ["_^!"] = "!",
	["^?_"] = "?", ["^!_"] = "!", ["ss"] = "ss", ["ae"] = "ae", ["AE"] = "AE", ["x"] = " times ",
	["G"] = " gold", ["E"] = "E", ["A"] = "A", ["heart"] = " heart ", ["star"] = " star ",
	["blackstar"] = " star ", ["music"] = " ", ["deg"] = " degrees", ["degree"] = " degrees",
	["c"] = "(c)", ["R"] = "(R)", ["+-"] = "+/-", ["r_arrow"] = " to ", ["l_arrow"] = " to ",
}

local function tag_text(tag)
	local g = GLYPH[tag]
	if g then return g end
	local letter = tag:match("^[`'%^:~,](%a)$")          -- accented letters such as <^a> in Grace
	if letter then return letter end
	return " "                                          -- layout tags (<X=74>, <PLTT=3>, <N=0> ...)
end

-- Turn game markup or a message into something a speech engine reads well.
local function clean(s)
	if not s or s == "" then return "" end
	s = s:gsub("[\1-\31]\255", " ")                  -- control codes: new line, wait, end ...
	s = s:gsub("\\n", " "):gsub("[\r\n]", " ")
	s = s:gsub("<([^<>]*)>", tag_text)
	s = s:gsub("^%s*//(.-)//%s*", "%1: ")                -- "//Aquila// text" -> "Aquila: text"
	s = s:gsub("//(.-)//", "%1: ")
	s = s:gsub("^%s*%*:%s*", "")                        -- "*:" marks an unnamed speaker
	s = s:gsub("%s*%*:%s*", " ")
	s = s:gsub("[\128-\255]", "")
	s = s:gsub("%s+", " "):gsub("^ ", ""):gsub(" $", "")
	s = s:gsub(" ([,%.!%?])", "%1")
	return s
end

------------------------------------------------------------------------------ state ---------
local pad_prev, last_button_frame = {}, -1000
local last_button_name, battle_menu_said, battle_round, round_phase = nil, {}, 0, 0
local held_dir = nil
local last_dialogue_frame = -1000
local last_menu_frame = -1000
local last_menu_spoken = -1000
-- A battle is running while the game holds a battle object in the second actor slot.
-- 1 = walking about, 3 = a battle waiting for your command, 4 = a battle turn playing out
local function battle_phase() return mainmemory.read_u8(0x02109DA6 - 0x02000000) end
local function in_battle() local p = battle_phase() return p >= 2 and p <= 8 end

-- menu state lives here because the message reader resets it
MENU = 0x02118FFC
local menu_raw_seen, menu_seen_count = "", 0
local menu_raw_done, menu_sig, menu_cursor = "", "", -1
local menu_items, menu_title = {}, nil
local last_info, last_info_frame, last_info_title = "", -1000, nil

local function pad_state()
	local ok, j = pcall(function() return joypad.get() end)
	if not ok or type(j) ~= "table" then return {} end
	local function b(n) return j[n] == true or j["P1 " .. n] == true end
	return { up = b("Up"), down = b("Down"), left = b("Left"), right = b("Right"),
	         a = b("A"), b = b("B"), x = b("X"), y = b("Y"), l = b("L"), r = b("R"),
	         start = b("Start"), select = b("Select") }
end

------------------------------------------------------------------------------ dialogue ------
DLG = 0x0211819C
PAGE_START, PAGE_END = 0x02115348, 0x0211534C
local dlg_last_raw, dlg_last_page, dlg_last_text = "", -1, ""

-- Pages end at a page break (13), a yes or no question (4: what follows are the answers, each
-- ending with 1) or the end of a message (1).
PAGE_ENDS = { [13] = true, [4] = true, [1] = true }
local function split_pages(raw)
	local pages, from = {}, 1
	local i = 1
	while i < #raw do
		local b, n = raw:byte(i), raw:byte(i + 1)
		if n == 255 and PAGE_ENDS[b] then
			if i > from then pages[#pages + 1] = { from, i - 1 } end
			from = i + 2
			i = i + 2
		else
			i = i + 1
		end
	end
	if from <= #raw then pages[#pages + 1] = { from, #raw } end
	if #pages == 0 then pages[1] = { 1, #raw } end
	return pages
end

local dlg_sig = nil
local on_new_message = nil     -- set further down: learns who you talked to
local experience_fix = nil     -- set further down: puts the amount into "receives some experience"
local function read_dialogue()
	-- Cheap check first: the first bytes and the page pointers change whenever anything does
	-- (the game also blanks the buffer for a frame between messages).
	local head = read_bytes(DLG, 48)
	local sig = table.concat(head, ",") .. ":" .. u32(PAGE_START) .. ":" .. u32(PAGE_END)
	if sig == dlg_sig then return end
	dlg_sig = sig
	local raw = cstring(DLG, 1200)
	if raw == "" then dlg_last_raw, dlg_last_page = "", -1 return end
	local pages = split_pages(raw)
	local offset = u32(PAGE_START) - DLG             -- 0-based byte offset of the page on screen
	local idx = 1
	if offset > 0 and offset < #raw then
		for k, p in ipairs(pages) do if offset + 1 >= p[1] then idx = k end end
	end
	if raw == dlg_last_raw and idx == dlg_last_page then return end
	local new_message = raw ~= dlg_last_raw
	dlg_last_raw, dlg_last_page = raw, idx
	if new_message then menu_sig = "" msg_serial = (msg_serial or 0) + 1 end   -- the next menu after a new message is news
	-- a shopkeeper greeting you again: the Buy / Sell menu that follows is news even if it looks
	-- the same as last time (the game leaves the old menu in memory, so only these lines re-arm it)
	if new_message then
		local low = clean(raw):lower()
		if low:find("welcome", 1, true) or low:find("anything else", 1, true) or low:find("help you", 1, true)
			or low:find("what can i do", 1, true) then
			dialogue_serial = (dialogue_serial or 0) + 1
		end
	end
	local p = pages[idx]
	local text = clean(raw:sub(p[1], p[2]))
	if text == "" then return end
	-- the same words written again with different control codes are not a new message
	if new_message and text == dlg_last_text and frame - last_dialogue_frame < 180 then last_dialogue_frame = frame return end
	dlg_last_text = text
	-- Pressing a button to get here means you want it now; a message that arrives on its own
	-- (battle messages, cut scenes) waits its turn behind whatever is being said.
	local pressed_recently = frame - last_button_frame < 45
	if new_message and experience_fix then text = experience_fix(text) end
	-- an information window (experience, attributes going up) that just came up is not cut off
	if new_message and (not pressed_recently or frame - last_info_frame < 90) then queue(text) else say(text, true) end
	if new_message and pressed_recently and on_new_message and not in_battle() and frame - last_dialogue_frame > 30 then
		pcall(on_new_message, text, clean(raw))
	end
	last_dialogue_frame = frame
end

------------------------------------------------------------------------------ menus ---------

local function parse_menu(m)
	local items = {}
	for s, idx, e in m:gmatch("()<N=(%d+)>()") do items[#items + 1] = { s = s, idx = tonumber(idx), e = e } end
	for k, it in ipairs(items) do
		local nxt = items[k + 1] and items[k + 1].s or #m + 1
		local seg = m:sub(it.e, nxt - 1)
		local nl = seg:find("\\n", 1, true) or seg:find("\n", 1, true)
		if nl then seg = seg:sub(1, nl - 1) end
		it.text = clean(seg)
		local before = m:sub(math.max(1, it.s - 10), it.s - 1)
		it.disabled = before:find("<PLTT=3>", 1, true) ~= nil
	end
	local by_index, count = {}, 0
	for _, it in ipairs(items) do
		if not by_index[it.idx] then by_index[it.idx] = it count = count + 1 end
	end
	local title = m:match("<TITLE=%d+>(.-)</TITLE>")
	return by_index, count, title and clean(title) or nil
end

local function describe_item(it, cursor, count)
	local s = it.text ~= "" and it.text or "blank"
	if it.disabled then s = s .. ", unavailable" end
	if SAY_POSITION_IN_MENUS and count > 1 then s = s .. ", " .. (cursor + 1) .. " of " .. count end
	return s
end

local menu_head = nil
menu_hist, menu_hist_n, menu_cursor_frame = {}, 0, -1000

-- What each picture on the character screens looks like (checked on the game's own previews).
CREATE_LOOKS = {
	[2] = { any = { "tallest and slim", "tall", "average height", "short and stocky", "shortest and small" } },
	[3] = {
		Male = { "short and messy", "wide, flicked out at the sides", "bowl cut", "short crop with a fringe",
			"long, wild and spiky", "straight, shoulder length, parted in the middle", "tall and spiky",
			"neat, with a side-swept fringe", "swept up on top, short at the sides", "bald" },
		Female = { "bob with a straight fringe", "bob with a fringe over one eye", "bunches sticking out",
			"big curly up-do", "short and swept to the side", "shoulder length, flicked out",
			"long and curly", "short and spiky", "high ponytail", "short rounded bob" },
	},
	[4] = { any = { "very dark brown", "reddish brown", "red", "pink", "blonde", "green", "blue", "purple",
		"light blue", "grey" } },
	[5] = {
		Male = { "big round friendly eyes", "determined eyes, bold eyebrows", "narrow, stern eyes",
			"fierce eyes, heavy eyebrows", "sleepy, half-closed eyes", "small round eyes, surprised look",
			"tiny dot eyes", "round eyes, gentle look", "intense, angry eyes", "eyes closed, smiling" },
		Female = { "big round sweet eyes", "determined eyes, raised eyebrows", "tall oval eyes, calm",
			"narrow eyes with long lashes", "sharp eyes, arched eyebrows", "eyes closed, smiling",
			"sleepy, half-closed eyes", "made-up, with eye shadow and lipstick", "small round eyes and freckles",
			"wide round eyes, rosy cheeks" },
	},
	[6] = { any = { "very fair", "fair", "light, rosy", "light tan", "tan", "medium brown", "dark brown",
		"deep brown" } },
	[7] = { any = { "black", "brown", "red", "gold", "green", "blue", "purple", "grey" } },
}
function create_look(field, value, m)
	local looks = CREATE_LOOKS[field]
	local n = tonumber((value or ""):match("Type (%d+)"))
	if not looks or not n then return nil end
	local gender = (m or ""):match("^<PLTT=%d+><X=%d+>(%a+)") or "Male"
	local list = looks.any or looks[gender] or looks.Male
	return list[n]
end
local creation_last = nil
local function read_creation(m)
	if not m:match("^<PLTT=1[45]><X=%d+>") then return false end
	local i, field, value = 0, nil, nil
	for pltt, v in m:gmatch("<PLTT=(%d+)>([^\\]*)") do
		i = i + 1
		if pltt == "14" then field, value = i, (v:gsub("<[XW]=%d+>", "")) end
	end
	if field then
		local names = { "Gender", "Body type", "Hairstyle", "Hair colour", "Face", "Skin colour", "Eye colour", "Name" }
		local text = (names[field] or ("Choice " .. field)) .. ": " .. clean(value)
		local look = create_look(field, clean(value), m)
		if look then text = text .. ", " .. look end
		if create then create.step = field end
		-- the name is read out by the keyboard as you type it
		-- (and the keyboard says "Name entry" when it comes up)
		if field == 8 then creation_last = text return true end
		-- your own hero's Male / Female is said from its picture list (read_create)
		if field == 1 and create and create.grid == HERO_CREATE_GRID then return true end
		if text ~= creation_last then
			creation_last = text
			-- on Patty's companion screen, say which of the pictures this is
			local g = create and create.grid
			if g and create_grid_ok(g) then
				local cols, rows, cx, cy = u32(g + 8), u32(g + 0xC), u32(g + 0x18), u32(g + 0x1C)
				if not (cols == 8 and rows == 1) and cols * rows > 1 and field ~= 8 then
					text = text .. ", " .. (cy * cols + cx + 1) .. " of " .. (cols * rows)
					create.last = "field"
				end
			end
			say(text, true)
		end
	end
	return true
end

-- Allocate Skill Points: five skills, each with the points you are adding now and its total,
-- then Confirm and the points you have left. All of it is in the menu text.
local skill_said = nil
plain_said = nil
function read_skill_points(m, cursor)
	local names = {}
	for k, name in m:gmatch("<N=(%d+)>(.-)</N>") do
		k = tonumber(k)
		if k <= 5 and not names[k] then names[k] = clean(name) end
	end
	local nums = {}
	for n in m:gmatch("<XR=%d+>(%d+)</XR>") do nums[#nums + 1] = tonumber(n) end
	local left = m:match("Points Remaining:%s*(%d+)")
	local text
	if cursor <= 4 then
		local add, total = nums[cursor * 2 + 1], nums[cursor * 2 + 2]
		text = (names[cursor] or "skill") .. (add and (", adding " .. add) or "") ..
			(total and ((add and add > 0) and (", from " .. total .. " to " .. (total + add)) or (", total " .. total)) or "")
	else
		text = names[5] or "Confirm"
	end
	local pos = ", " .. (math.min(cursor, 5) + 1) .. " of 6"
	local tail = left and (". " .. left .. " points left") or ""
	local key = cursor .. "|" .. table.concat(nums, ",") .. "|" .. tostring(left)
	if key == skill_said then return end
	local first = skill_said == nil
	local same_row = skill_said and skill_said:match("^(%d+)|") == tostring(cursor)
	skill_said = key
	menu_cursor = cursor
	if first then
		say("Allocate skill points. Left and right change how many go into a skill. " .. text .. tail .. pos, true)
	elseif same_row and cursor <= 4 then
		say(text:gsub("^[^,]*, ", "") .. tail, true)       -- only the numbers changed
	else
		say(text .. pos .. tail, true)
	end
end

-- a quick look at whether the menu text changed: BizHawk can fingerprint memory itself, which
-- is much cheaper than copying it into Lua every frame
menu_hash_ok = nil
function menu_fingerprint()
	if menu_hash_ok ~= false then
		local ok, h = pcall(function() return mainmemory.hash_region(MENU - 0x02000000, 256) end)
		if ok and type(h) == "string" and #h > 0 then menu_hash_ok = true return h end
		menu_hash_ok = false
	end
	return table.concat(read_bytes(MENU, 256), ",")
end
local function read_menu()
	local head = menu_fingerprint()
	if head == menu_head and menu_seen_count > 1 then return end
	menu_head = head
	local m = cstring(MENU, 2400)
	local has_cursor = m:find("<CURSOR=", 1, true) ~= nil
	-- A menu is only trusted once it has stayed the same for two frames: the game sometimes
	-- writes a half-built list into this buffer for a single frame.
	-- Some screens share the buffer between two windows drawn in turn ("To who?" and the HP of
	-- the one picked): a list that keeps coming back every few frames is steady too.
	if m ~= menu_raw_seen then
		local back = has_cursor and menu_hist[m] and frame - menu_hist[m] <= 8
		menu_hist_n = menu_hist_n + 1
		if menu_hist_n > 40 then menu_hist, menu_hist_n = {}, 0 end
		menu_hist[m] = frame
		menu_raw_seen, menu_seen_count = m, 0
		last_menu_frame = frame
		if has_cursor then menu_cursor_frame = frame end
		if read_creation(m) then return end
		-- the HP (and MP) of the one picked in "To who?"
		if not has_cursor and menu_title == "To who?" then
			local nums = {}
			for v in m:gmatch("<XR=%d+>(%d+)</XR>") do nums[#nums + 1] = v end
			local label = m:match("(%u%u):")
			if label and #nums >= 2 then
				local key = menu_cursor .. "|" .. table.concat(nums, ",")
				if key ~= towho_said then
					towho_said = key
					queue(nums[1] .. " of " .. nums[2] .. " " .. label .. (nums[4] and (", " .. nums[3] .. " of " .. nums[4] .. " MP") or ""))
				end
			end
		end
		if not back then
			-- Anything other than a cursor menu passing through this buffer (the gold window when the
			-- menu opens, a message, an information window) means the next menu is a fresh arrival
			-- (but not the other half of a pair of windows drawn in turn).
			if not has_cursor and frame - menu_cursor_frame > 8 then menu_sig, menu_raw_done = "", "" end
			return
		end
	else
		menu_hist[m] = frame
		if has_cursor then menu_cursor_frame = frame end
	end
	menu_seen_count = menu_seen_count + 1
	if menu_seen_count ~= 1 or m == menu_raw_done then return end
	menu_raw_done = m
	if m == "" then return end

	local cursor = tonumber(m:match("<CURSOR=(%d+)>") or "")
	if not cursor then
		-- A window with a title and no cursor is information (experience earned, status ...).
		local title = m:match("<TITLE=%d+>(.-)</TITLE>")
		if not title then
			-- a window with a sentence in it and nothing to pick (an accolade, a notice)
			-- (the text of a conversation also passes through here; the message box reads that)
			-- (also a message the game has not filled in yet: "<IF_SING>... draws near<ELSE>... draw near")
			local script = m:find("<PAGE>", 1, true) or m:find("<END>", 1, true) or m:find("<YESNO>", 1, true) or m:find("<N_TURN>", 1, true)
				or m:find("<IF_", 1, true) or m:find("<ELSE", 1, true) or m:find("_NAME>", 1, true)
			local t = script and "" or clean(m)
			if #t > 12 and t:match("%a%a%a") and t:match("[%.!%?]$") and t ~= plain_said then
				plain_said = t
				queue(t)
			end
			return
		end
		if title then
			local body = clean((m:gsub("<TITLE=%d+>.-</TITLE>", "")))
			local t = clean(title)
			-- a window that updates line by line (attributes going up): say its title only once
			local repeat_title = t == last_info_title and frame - last_info_frame < 300
			last_info = t .. (body ~= "" and (". " .. body) or "")
			last_info_title, last_info_frame = t, frame
			if repeat_title then
				if body ~= "" then queue(body) end
			else
				queue(last_info)
			end
		end
		return
	end
	if m:find("Allocate Skill Points", 1, true) then read_skill_points(m, cursor) return end
	skill_said = nil
	-- In a battle the game builds its command lists before it shows them; only trust a list
	-- while the battle is waiting for your command.
	if in_battle() and (battle_phase() ~= 3 or frame - last_button_frame > 30) then return end
	local items, count, title = parse_menu(m)
	-- The little Equip / Move / Discard / Cancel list on the equipment screen. Its text stays in
	-- this buffer afterwards, and the list of who to equip moves the old cursor through it.
	if items[0] and items[0].text == "Equip" and items[2] and items[2].text == "Discard" then
		if not equip_popup_open and frame - (equip_popup_arm or -1000) < 60 then equip_popup_open = true end
		if not equip_popup_open then
			if equip_who_items and equip_who_count == count then
				items, title = equip_who_items, "Equip"
			else
				return
			end
		end
	elseif title == "Equip" then
		equip_who_items, equip_who_count = items, count
	end
	local it = items[cursor]
	if not it then return end                        -- a list that is shown but not in use
	local sig = m:gsub("<CURSOR=%d+>", "")
	local same_menu = sig == menu_sig
	if same_menu and cursor == menu_cursor then return end   -- redrawn, nothing moved
	-- In a battle, picking a command redraws the list you picked from: that is not news.
	if in_battle() then
		-- a fresh set of commands each round
		if battle_phase() ~= 3 or battle_menu_said.round ~= battle_round then battle_menu_said = { round = battle_round } end
		if last_button_name == "a" and battle_menu_said[sig .. cursor] then
			menu_sig, menu_cursor = sig, cursor
			return
		end
		battle_menu_said[sig .. cursor] = true
	end
	menu_sig, menu_cursor, menu_items, menu_title = sig, cursor, items, title
	local text = describe_item(it, cursor, count)
	-- the list of commands: say whose turn it is when that changes
	if in_battle() and items[0] and items[0].text == "Attack" then
		local who = battle_actor_name()
		if who and who ~= battle_actor_said then
			battle_actor_said, battle_actor_seen = who, who
			battle_actor_text, battle_actor_frame = text, frame
			last_menu_spoken = frame
			last_menu_item = it.text
			say(turn_text(who) .. text, true)
			return
		end
		-- just said with the turn a moment ago
		if who == battle_actor_said and text == battle_actor_text and frame - battle_actor_frame < 60 then return end
	end
	last_menu_spoken = frame
	last_menu_item = it.text
	if same_menu then
		say(text, true)
	else
		if title then text = title .. (title:find("[%.%?!:]$") and " " or ". ") .. text end
		-- A menu that opens together with a question waits for the question to be read.
		if frame - last_dialogue_frame < 150 then queue(text) else say(text, true) end
	end
end

local function read_all_options()
	if menu_sig == "" then say("No menu.") return end
	local list, n = {}, 0
	for i = 0, 40 do
		local it = menu_items[i]
		if it then
			n = n + 1
			list[#list + 1] = it.text .. (it.disabled and " (unavailable)" or "")
		end
	end
	if n == 0 then say("No menu.") return end
	say((menu_title and (menu_title .. ": ") or "") .. table.concat(list, ", "))
end

-- When a battle turn is over and the game asks for your command again, the command list is not
-- rewritten, so say it here. The list and its cursor live in the battle's menu (checked by count).
BATTLE_COMMANDS = { [0] = "Fight", "Examine", "Flee", "Misc." }
local last_phase, cmd_pending = 1, false
local function read_battle_phase()
	local ph = battle_phase()
	if ph == 3 and last_phase ~= 3 then
		-- a new battle waits for its "... draws near!" message; a new turn does not
		cmd_pending = { since = frame, need_message = last_phase < 2 or last_phase > 8 }
	end
	if ph ~= 3 then cmd_pending = false end
	last_phase = ph
	-- say the command list once the battle messages have gone quiet, unless you already moved
	if cmd_pending and cmd_pending.need_message and last_dialogue_frame > cmd_pending.since then
		cmd_pending.need_message = false
	end
	if cmd_pending and not cmd_pending.need_message and frame - last_dialogue_frame > 40
	   and frame - cmd_pending.since > 20 and last_menu_spoken < cmd_pending.since then
		cmd_pending = false
		local cur = 0
		if mainmemory.read_u32_le(0x0239533C - 0x02000000) == 4 then
			local c = mainmemory.read_u32_le(0x02395358 - 0x02000000)
			if c <= 3 then cur = c end
		end
		menu_sig = "<N=0>Fight</N>\\n<N=1>Examine</N>\\n<N=2>Flee</N>\\n<N=3>Misc.</N>"
		menu_cursor, menu_title = cur, nil
		menu_items = {}
		for i = 0, 3 do menu_items[i] = { text = BATTLE_COMMANDS[i] } end
		battle_actor_said = nil
		queue(BATTLE_COMMANDS[cur] .. ", " .. (cur + 1) .. " of 4")
	end
end

------------------------------------------------------------------------------ yes / no ------
YESNO_VTABLE = 0x0214E628
local yesno_obj = 0x0239CA5C
local yesno_visible, yesno_choice, yesno_search_frame = false, -1, -1000
PLAYER_PTR = 0x020F33E0

local function find_yesno()
	-- The yes/no box lives in the field menu heap. It is normally at the same place, but if a
	-- different map moves it, look for it again (it is recognised by its class pointer).
	if u32(yesno_obj) == YESNO_VTABLE then return true end
	-- one look per message is enough (the search reads a lot of memory)
	if yesno_search_frame == (msg_serial or 0) then return false end
	yesno_search_frame = msg_serial or 0
	local heap = 0x02388B6C
	if u32(heap) ~= 0x46524D48 then return false end     -- "HMRF" heap header
	local t = read_bytes(heap, 0x17000)
	for i = 1, #t - 3, 4 do
		if t[i] == 0x28 and t[i + 1] == 0xE6 and t[i + 2] == 0x14 and t[i + 3] == 0x02 then
			yesno_obj = heap + i - 1
			return true
		end
	end
	return false
end

-- Story scenes ask their yes or no questions with a different box: a two-line cursor list
-- whose count and cursor sit at fixed places.
EVENT_CHOICE_COUNT, EVENT_CHOICE_CURSOR = 0x021153A4, 0x021153C0
local yesno_question = nil
local function read_yesno()
	local visible = false
	if u32(yesno_obj) == YESNO_VTABLE or (dlg_last_raw:find("\10\255", 1, true) and find_yesno()) then
		visible = u8(yesno_obj + 0x28) == 1
	end
	local player = u32(PLAYER_PTR)
	local choice = inram(player, 0x260) and u8(player + 0x250) or 0
	if not visible and u32(EVENT_CHOICE_COUNT) == 2 then
		visible = true
		choice = u32(EVENT_CHOICE_CURSOR) == 1 and 1 or 0
		-- a new question while the box stays up: announce it again
		if yesno_question and yesno_question ~= dlg_last_raw then yesno_visible = false end
		yesno_question = dlg_last_raw
	elseif not visible then
		yesno_question = nil
	end
	if visible then
		local word = choice == 1 and "No" or "Yes"
		if not yesno_visible then queue("Yes or no? " .. word)
		elseif choice ~= yesno_choice then say(word, true) end
	end
	yesno_visible, yesno_choice = visible, choice
end


------------------------------------------------------------------------------ name entry ----
-- The name keyboard is drawn as pictures. Its cursor is a pixel position in the keyboard's
-- control (recognised by four pointers back into itself); the name typed so far is written into
-- the menu buffer as "<X=18>Retro****" with one star per free letter.
KB = 0x022A517C
KB_ROWS = { [64] = { 32, "1234567890-=" }, [80] = { 40, "qwertyuiop[]" },
	[96] = { 48, "asdfghjkl;'" }, [112] = { 56, "zxcvbnm,./" } }
KB_SPECIAL = { ["24,96"] = "Small letters", ["24,112"] = "Capital letters", ["24,136"] = "Change letters",
	["48,136"] = "Accented letters", ["72,136"] = "Symbols", ["96,136"] = "Space",
	["160,136"] = "question mark", ["184,136"] = "Delete", ["208,136"] = "OK, finish the name" }
KB_SAY = { ["-"] = "dash", ["="] = "equals", ["["] = "open bracket", ["]"] = "close bracket",
	[";"] = "semicolon", ["'"] = "apostrophe", [","] = "comma", ["."] = "full stop", ["/"] = "slash" }
local kb_last, kb_name = nil, nil
local function kb_key(x, y)
	local sp = KB_SPECIAL[x .. "," .. y]
	if sp then return sp end
	local row = KB_ROWS[y]
	if row then
		local i = math.floor((x - row[1]) / 16 + 0.5) + 1
		local ch = row[2]:sub(i, i)
		if ch ~= "" then return KB_SAY[ch] or ch end
	end
	if y >= 130 then
		if x < 36 then return KB_SPECIAL["24,136"] elseif x < 60 then return KB_SPECIAL["48,136"]
		elseif x < 84 then return KB_SPECIAL["72,136"] elseif x < 150 then return "Space"
		elseif x < 172 then return "question mark"
		elseif x < 196 then return "Delete" else return "OK, finish the name" end
	end
	return nil
end
function companion_name() return COMPANION_NAME and clean(cstring(COMPANION_NAME, 20)) or "" end
local function kb_ok(b)
	return u32(b + 0x20) == b + 0xC and u32(b + 0x24) == b + 8 and u32(b + 0x28) == b + 0x1C
		and u32(b + 0x2C) == b + 0x18
end
local function read_name_entry()
	local b = KB
	local valid = kb_ok(b)
	-- Patty's companion screen has its own keyboard (the same kind of control, elsewhere)
	local companion = false
	if create and create.grid and create.step == 8 and kb_ok(create.grid) and ui_string(5) == "Recruit a Friend" then
		b, valid, companion = create.grid, true, true
	end
	local name = menu_raw_seen:match("^<X=%d+>([^<%*]*)%**$")
	-- before the first letter is typed the buffer still holds the list of steps, with
	-- "Name" (the 8th line) highlighted: the name so far is on that line
	if not name and menu_raw_seen:match("^<PLTT=1[45]>") then
		local i = 0
		for pltt, v in menu_raw_seen:gmatch("<PLTT=(%d+)>([^\\]*)") do
			i = i + 1
			if pltt == "14" and i == 8 then name = (v:gsub("<[XW]=%d+>", "")):gsub("%*", "") end
		end
	end
	if not valid then kb_last, kb_name, kb_caps = nil, nil, false return end
	if companion and not name then name = kb_name or "" end
	if not name then return end            -- the buffer is busy for a moment; keep what we had
	name = clean(name)
	local x, y = u16(b + 0x60), u16(b + 0x62)
	local key = kb_key(x, y)
	local pos = x .. "," .. y
	-- the up arrow key switches the letters to capitals, the down arrow key back to small ones
	if last_button_frame == frame and last_button_name == "a" then
		if key == "Capital letters" then kb_caps = true
		elseif key == "Small letters" then kb_caps = false end
	end
	if key and #key == 1 and key:match("%a") and kb_caps then key = "capital " .. key:upper() end
	if kb_name == nil then
		say("Name entry. " .. (name ~= "" and ("Name so far: " .. name .. ". ") or "") ..
			"Move with the D-pad, A types a letter. " .. (key or ""), true)
	else
		if name ~= kb_name then
			if #name > #kb_name then say(name:sub(#kb_name + 1) .. ", name is now " .. name, true)
			else say("Deleted, name is now " .. (name ~= "" and name or "empty"), true) end
		end
		if pos ~= kb_last and key then
			say(key, true)
			-- moving on the keyboard again: "Begin your adventure...?" is news the next time
			if create and not menu_raw_seen:find("<N=0>Yes</N>", 1, true) then create.asked = false end
		end
	end
	kb_last, kb_name = pos, name
end

------------------------------------------------------------------------------ places --------
MAPCODE, MAPNAME, MAPID = 0x020FB3FC, 0x022A4266, 0x020FB3F0
CAMERA = 0x0210A134
OBJ_TABLE, OBJ_COUNT = 0x02107600, 0x02107680

------------------------------------------------------------------------------ title ---------
-- The title menu is run by the game's script engine, not the menu system, so it has its own reader.
-- Two script variables hold the cursor: one for a cartridge with no adventure log, one with a log.
TITLE_VAR_CLASS = 0x021FE80C
TITLE_MENUS = {
	{ obj = 0x0231624C, id = 0x12D, items = { "Create a new adventure log", "Configure Nintendo Wi-Fi Connection settings" } },
	{ obj = 0x023162D4, id = 0x12E, items = { "Continue your adventure", "Delete adventure log", "Configure Nintendo Wi-Fi Connection settings" } },
}
local title_last, title_frames, title_menu = nil, 0, nil
title_movie = 0
local function read_title()
	if cstring(MAPCODE, 12) ~= "" or u32(PLAYER_PTR) ~= 0 then
		title_last, title_frames, title_deleted, title_moved, title_rebuild = nil, 0, false, nil, false
		for _, m in ipairs(TITLE_MENUS) do m.seen = nil end
		return
	end
	-- the opening movie ("Begin your adventure. START" on the lower screen): the title menus
	-- are not built yet and their memory holds the film
	local o1, o2 = u32(TITLE_MENUS[1].obj), u32(TITLE_MENUS[2].obj)
	if o1 ~= TITLE_VAR_CLASS and o2 ~= TITLE_VAR_CLASS then
		if o1 ~= 0 and cstring(MENU, 8) == "" then
			title_movie = title_movie + 1
			if title_movie == 90 then queue("Opening movie. Press Start to begin your adventure.") end
		else
			title_movie = 0
		end
	elseif title_movie >= 90 then
		title_movie = 0
	end
	if title_last == nil and cstring(MENU, 8) ~= "" then return end   -- character creation, not the title
	-- Which of the two menus is up: a log on the cartridge leaves its hero's name in memory, but
	-- deleting the log from this menu does not clear the name, so remember that it was deleted.
	if last_said == "Adventure log deleted." and not title_deleted then title_deleted, title_moved, title_rebuild = true, nil, true end
	-- the menu is built again once the message is closed: wait for that before saying it
	if title_rebuild then
		local m1, m2 = TITLE_MENUS[1], TITLE_MENUS[2]
		if u16(m1.obj + 0x74) ~= 0 and u16(m2.obj + 0x74) == 0 then title_rebuild, title_frames, title_last = false, 0, nil end
		return
	end
	local has_log = cstring(0x020FB258, 12) ~= "" and not title_deleted
	local menu = TITLE_MENUS[has_log and 2 or 1]
	-- and whichever menu's cursor moves is the one on screen
	for _, m in ipairs(TITLE_MENUS) do
		local c = u32(m.obj + 0x28)
		local pressed = (last_button_name == "up" or last_button_name == "down") and frame - last_button_frame < 15
		if pressed and m.seen and c ~= m.seen and u32(m.obj) == TITLE_VAR_CLASS then title_moved = m end
		m.seen = c
	end
	if title_moved then menu = title_moved end
	-- best of all: only the menu on screen has its list of choices filled in
	local filled = {}
	for _, m in ipairs(TITLE_MENUS) do
		if u32(m.obj) == TITLE_VAR_CLASS and u16(m.obj + 6) == m.id and u16(m.obj + 0x74) ~= 0 then filled[#filled + 1] = m end
	end
	if #filled == 1 then menu = filled[1] end
	if u32(menu.obj) ~= TITLE_VAR_CLASS or u16(menu.obj + 6) ~= menu.id then title_last, title_frames = nil, 0 return end
	if menu ~= title_menu then title_menu, title_frames, title_last = menu, 0, nil end
	title_frames = title_frames + 1
	if title_frames < 40 then return end            -- let the adventure log panel finish loading
	local cursor = u32(menu.obj + 0x28)
	local item = menu.items[cursor + 1]
	if not item then return end
	if title_last == nil then queue("Title screen. " .. item)
	elseif cursor ~= title_last then say(item, true) end
	title_last = cursor
end


-- map id -> { code, name }  (names from the game's own debug map list)
MAPIDS = {
	[1]={"K01"}, [3]={"K03"}, [100]={"C01","Stornway"}, [103]={"C01M03","House 3"},
	[104]={"C01M04","Weapon Shop"}, [105]={"C01M05","House 1"}, [106]={"C01M06","House 2"},
	[107]={"C01M07","Armour Shop"}, [108]={"C01M08","Item Shop"}, [109]={"C01M09","Church"},
	[110]={"C01M10"}, [112]={"C01M12","Basement"}, [114]={"C01M14","Interior"},
	[115]={"C01M15","Interior B1 - Dungeon"}, [116]={"C01M16","Interior B1 - Training Room"},
	[117]={"C01M17","Interior Lv 2 - Barracks"}, [118]={"C01M18","Interior Lv 2 - Throneroom"},
	[119]={"C01M19","Interior Lv 2 - Princess"}, [120]={"C01M20","Interior Lv 3"},
	[121]={"C01M21","Interior Lv 3 - Treasure Room"}, [123]={"C01M23","Well"},
	[124]={"C01M24","Underground Passage"}, [125]={"C01M25","Sealed Room"}, [198]={"C01M98","Exterior"},
	[200]={"C02","Gleeba"}, [201]={"C02M01"}, [202]={"C02M02","Palace Lv 1-1"},
	[203]={"C02M03","Palace Lv 1-2"}, [204]={"C02M04","Palace Lv 1-3"}, [205]={"C02M05","Palace Lv 2-1"},
	[206]={"C02M06","Palace Lv 2-2"}, [207]={"C02M07","Palace Lv 3"}, [208]={"C02M08"}, [209]={"C02M09"},
	[210]={"C02M10","New Well"}, [211]={"C02M11","Inn"}, [212]={"C02M12","Inn Lv 2"},
	[213]={"C02M13","Barracks"}, [214]={"C02M14","Barracks Lv 2"}, [215]={"C02M15","Dried-Up Well"},
	[216]={"C02M16"}, [217]={"C02M17","Casino Lv 1 (Old)"}, [218]={"C02M18","Casino Lv 2 (Old)"},
	[219]={"C02M19","Dance Hall"}, [400]={"C04","Gittingham Palace"}, [401]={"C04M01","South"},
	[402]={"C04M02","East"}, [403]={"C04M03","West"}, [404]={"C04M04","North"}, [405]={"C04M05","North Lv 2"},
	[406]={"C04M06"}, [407]={"C04M07","Lv 2"}, [408]={"C04M08","Lv 3"}, [409]={"C04M09","Lv 4"},
	[410]={"C04M10"}, [1100]={"M01","Angel Falls"}, [1101]={"M01M01","House A"}, [1102]={"M01M02","Inn"},
	[1103]={"M01M03"}, [1104]={"M01M04","Stable"}, [1105]={"M01M05","Mayor's House"}, [1106]={"M01M06"},
	[1107]={"M01M07","Erinn's House"}, [1108]={"M01M08"}, [1109]={"M01M09","Mayor's House Lv 2"},
	[1110]={"M01M10","Erinn's House Lv 2"}, [1111]={"M01M11"}, [1112]={"M01M12"}, [1200]={"M02","Zere"},
	[1201]={"M02M01","Petra's House"}, [1202]={"M02M02"}, [1203]={"M02M03"}, [1204]={"M02M04","House"},
	[1205]={"M02M05","Cave"}, [1206]={"M02M06","Petra's house B1"}, [1207]={"M02M07"},
	[1300]={"M03","Coffinwell"}, [1301]={"M03M01"}, [1302]={"M03M02","Inn Roof"}, [1303]={"M03M03"},
	[1304]={"M03M04","House B"}, [1305]={"M03M05","House B Lv 2"}, [1306]={"M03M06","Weapon & Armour Shop"},
	[1307]={"M03M07"}, [1308]={"M03M08","House C"}, [1309]={"M03M09"}, [1310]={"M03M10"},
	[1311]={"M03M11","Scholar's House"}, [1312]={"M03M12","Scholar's Study"}, [1313]={"M03M13"},
	[1500]={"M05","Porth Llaffan"}, [1501]={"M05M01"}, [1502]={"M05M02"}, [1503]={"M05M03"},
	[1504]={"M05M04"}, [1505]={"M05M05","Mayor's House"}, [1506]={"M05M06"}, [1700]={"M07","Zere Rocks"},
	[1701]={"M07M01"}, [1705]={"M07M05"}, [1706]={"M07M06","Petra's House B1"},
	[1800]={"M08","Dourbridge"}, [1801]={"M08M01"}, [1802]={"M08M02"}, [1803]={"M08M03","Mason's House"},
	[1804]={"M08M04","Bar on Left Under Bridge"}, [1805]={"M08M05","Item shop on Right Under Bridge"},
	[1806]={"M08M06"}, [1807]={"M08M07","Cap'n Meddlin's 'Castle'"},
	[1808]={"M08M08","Basement on Right Under Bridge"}, [1900]={"M09","Basement on Right Under Bridge"},
	[1901]={"M09M01"}, [1902]={"M09M02","Workshop"}, [1903]={"M09M03"},
	[1904]={"M09M04","Marion's House"}, [1905]={"M09M05","Marion's House Lv 2"},
	[1906]={"M09M06","Marion's House garden"}, [1907]={"M09M07","Terrace House"},
	[1908]={"M09M08","Craftsman's House"}, [1909]={"M09M09"}, [1910]={"M09M10"},
	[1911]={"M09M11","Inn B1"}, [1912]={"M09M12","Haunted House"}, [1913]={"M09M13","Haunted House B1"},
	[1914]={"M09M14"}, [1915]={"M09M15","Marion Bloome (Sepia)"},
	[1916]={"M09M16","x Marion Bloome garden (Sepia)"}, [2000]={"M10","Batsureg"}, [2001]={"M10M01"},
	[2002]={"M10M02"}, [2003]={"M10M03","Yurt A"}, [2004]={"M10M04","Yurt B"}, [2005]={"M10M05"},
	[2006]={"M10M06","Yurt C (Batzorig)"}, [2007]={"M10M07","Village Head's Yurt"},
	[2100]={"M11","Swinedimples Academy"}, [2101]={"M11M01","School Hall"}, [2102]={"M11M02","Corridor"},
	[2103]={"M11M03","Main Building@"}, [2104]={"M11M04","Chapel"}, [2105]={"M11M05","Main Building@Lv 2"},
	[2106]={"M11M06","Roof (Small Room A)"}, [2107]={"M11M07","Dormitory Lv 1 (Cafeteria)"},
	[2108]={"M11M08","Dormitory Lv 2"}, [2109]={"M11M09","Dormitory Lv 3 (Small Room B)"},
	[2200]={"M12","Wormwood Creek"}, [2201]={"M12M01"}, [2202]={"M12M02"}, [2203]={"M12M03"},
	[2204]={"M12M04"}, [2205]={"M12M05"}, [2206]={"M12M06"}, [2207]={"M12M07","x Exterior (Sepia)"},
	[2208]={"M12M08","x House (Sepia)"}, [2209]={"M12M09","x Church (Sepia)"}, [2210]={"M12M10"},
	[2211]={"M12M11"}, [2300]={"M13","Upover"}, [2301]={"M13M01","House 01"}, [2302]={"M13M02","House 02"},
	[2303]={"M13M03","House 03"}, [2304]={"M13M04"}, [2305]={"M13M05"}, [2306]={"M13M06"},
	[2307]={"M13M07"}, [2308]={"M13M08"}, [2309]={"M13M09"},
	[2310]={"M13M10","Underground Passage & Cave"}, [2311]={"M13M11"}, [2399]={"M13M99"},
	[4100]={"X01","Observatory"}, [4101]={"X01M01","Exterior 1"}, [4103]={"X01M03","Exterior 3"},
	[4104]={"X01M04","Exterior 4"}, [4105]={"X01M05","Lv 1-1"}, [4106]={"X01M06","Lv 1-2"},
	[4107]={"X01M07"}, [4109]={"X01M09"}, [4110]={"X01M10"}, [4200]={"X02","Alltrades Abbey"},
	[4201]={"X02M01"}, [4202]={"X02M02","Interior B1"}, [4300]={"X03","Realm of the Almighty"},
	[4301]={"X03M01","Realm of the Almighty 1"}, [4302]={"X03M02","Realm of the Almighty 2"},
	[4303]={"X03M03","Temple of the Almighty"}, [4304]={"X03M04","Temple of the Almighty Lv 2"},
	[4305]={"X03M05","Small Temple 1"}, [4306]={"X03M06","Small Temple 2"},
	[4309]={"X03M09","Temple of the Almighty Lv 1 (Sepia)"}, [4400]={"X04","Realm of the Mighty"},
	[4401]={"X04M01","Exterior 2"}, [4402]={"X04M02"}, [4403]={"X04M03","Realm of the Mighty -"},
	[4404]={"X04M04","Interior 1"}, [4405]={"X04M05","Interior 1-A"}, [4406]={"X04M06","Interior 1-B"},
	[4407]={"X04M07","Interior 1-C"}, [4408]={"X04M08","Interior 2"}, [4409]={"X04M09","Interior 3"},
	[4410]={"X04M10","Interior 4"}, [4411]={"X04M11","Interior 5"}, [4412]={"X04M12","Interior 6"},
	[4413]={"X04M13","Interior 7"}, [4414]={"X04M14","Disc 1"}, [4415]={"X04M15","Exterior - Disc"},
	[4416]={"X04M16","Disc 2"}, [4417]={"X04M17","Disc 3"}, [4418]={"X04M18","Disc 4"},
	[4419]={"X04M19","Disc 5"}, [4420]={"X04M20","Disc 6"}, [4421]={"X04M21","Disc 7"},
	[4422]={"X04M22","Exterior - Summit"}, [4423]={"X04M23","Summit -"}, [4424]={"X04M24","Summit - Lv 2"},
	[4425]={"X04M25","Corvus Appears"}, [4498]={"X04M98"}, [4499]={"X04M99"},
	[4500]={"X05","Observatory (After Attack)"}, [4501]={"X05M01"}, [4503]={"X05M03"},
	[4504]={"X05M04"}, [4505]={"X05M05"}, [4506]={"X05M06"}, [4507]={"X05M07"},
	[4509]={"X05M09"}, [4510]={"X05M10"}, [4511]={"X05M11","Exterior 4 (Destroyed)"},
	[4512]={"X05M12","For Ending (All Together)"}, [4513]={"X05M13","Lv 2 (sepia)"}, [5101]={"S01M01"},
	[5102]={"S01M02"}, [5200]={"S02","Loch Storn"}, [5300]={"S03","Eastern Checkpoint"},
	[5301]={"S03M01","Barracks"}, [5400]={"S04","Hexagon Hill"}, [5500]={"S05","Cuddiedig Cliff"},
	[5600]={"S06","Hunters' Yurts"}, [5601]={"S06M01"}, [5602]={"S06M02","Gortress"},
	[5700]={"S07","Gortress"}, [5701]={"S07M01","Cells - Stairs"}, [5702]={"S07M02","Watchtower -"},
	[5703]={"S07M03","Watchtower - Lv 2"}, [5704]={"S07M04","Gortress - Lv 2"},
	[5705]={"S07M05","Gortress - B1"}, [5706]={"S07M06","Slurry Quay"}, [5707]={"S07M07","Exterior - Cells"},
	[5800]={"S08","Slurry Quay"}, [5801]={"S08M01"}, [5900]={"S09","Ship - Deck"},
	[5901]={"S09M01","Captain's Cabin"}, [5902]={"S09M02","Passenger Cabin"}, [5903]={"S09M03","Hold"},
	[6000]={"S10","Mountain Hut"}, [6001]={"S10M01","Interior"}, [6100]={"S11","Ulbaruun Cave"},
	[6101]={"S11M01","Interior of the cave"}, [6200]={"S12","Bloomingdale Region"}, [6201]={"S12M01"},
	[6202]={"S12M02","Hope Springs"}, [6302]={"S13M02"}, [6303]={"S13M03"},
	[6304]={"S13M04","Exterior (Sepia)"}, [6305]={"S13M05","Cave (Sepia)"}, [6401]={"S14M01"},
	[6402]={"S14M02","Starflight Express - Carriage 3"}, [6403]={"S14M03","Starflight Express - ???"},
	[6404]={"S14M04","Starflight Express - Carriage 3, Small Room"}, [6405]={"S14M05"},
	[6500]={"S15","Wyrmward"}, [7100]={"D01","The Hexagon"}, [7101]={"D01M01"}, [7102]={"D01M02","B1"},
	[7103]={"D01M03","B2"}, [7104]={"D01M04","B1-A"}, [7105]={"D01M05","B1-B"}, [7301]={"D03M01"},
	[7302]={"D03M02","Interior - North-Western Tower"}, [7303]={"D03M03","Interior - B1"},
	[7304]={"D03M04","Interior - Eastern Tower"}, [7305]={"D03M05","Interior - Western Tower"},
	[7306]={"D03M06","Interior - Lv 2, Northern Tower Throneroom"},
	[7307]={"D03M07","Interior - Lv 1, Princess's Room"}, [7400]={"D04","Quarantomb"},
	[7401]={"D04M01","Inside the Shrine"}, [7402]={"D04M02","Interior -"}, [7403]={"D04M03"},
	[7601]={"D06M01","Exterior 01"}, [7602]={"D06M02","Interior - Lv 1-01"},
	[7603]={"D06M03","Interior - Lv 1-02"}, [7604]={"D06M04","Interior - Lv 2"}, [7605]={"D06M05","Exterior 02"},
	[7700]={"D07","Heights of Loneliness"}, [7701]={"D07M01","Heights of Loneliness 2"},
	[7702]={"D07M02","Heights of Loneliness 3"}, [7703]={"D07M03","Heights of Loneliness 4"},
	[7704]={"D07M04","Heights of Loneliness 5"}, [7705]={"D07M05","Heights of Loneliness 6"},
	[7706]={"D07M06","Heights of Loneliness 7"}, [7707]={"D07M07","Heights of Loneliness 8"},
	[7708]={"D07M08","Heights of Loneliness 9"}, [7709]={"D07M09","Heights of Loneliness 10"},
	[7802]={"D08M02","Interior - B1-A"}, [7803]={"D08M03","Interior - B1-B"},
	[7804]={"D08M04","Interior - B1 Room"}, [7805]={"D08M05","Interior - B2"}, [7806]={"D08M06","Interior - B3"},
	[7807]={"D08M07","Interior - B1 Dungeon"}, [7808]={"D08M08","Interior - B2 Graves"},
	[7809]={"D08M09","Interior - B3 Boss Room"}, [7900]={"D09","The Bad Cave"}, [7901]={"D09M01"},
	[7902]={"D09M02"}, [7903]={"D09M03","Interior - Lv 1-03"}, [7904]={"D09M04"},
	[7905]={"D09M05","Interior - B2-01"}, [7906]={"D09M06","Interior - B2-02"}, [8201]={"D12M01"},
	[8202]={"D12M02"}, [8203]={"D12M03"}, [8204]={"D12M04"}, [8205]={"D12M05"},
	[8206]={"D12M06","Gerzuun - Underground Passage"}, [8207]={"D12M07","Hidden Passage"},
	[8208]={"D12M08","Depths"}, [8301]={"D13M01","Interior - B1 Library"}, [8302]={"D13M02"},
	[8303]={"D13M03","Interior - B2 Classroom"}, [8400]={"D14","The Bowhole"}, [8401]={"D14M01","Cave 2 -"},
	[8402]={"D14M02","Cave 3 - B1"}, [8403]={"D14M03","Cave 4 -"}, [8404]={"D14M04","Cave 5 - B2"},
	[8405]={"D14M05","Cave 6 - B3"}, [8406]={"D14M06","Cave 7 - B4"}, [8407]={"D14M07","Cave 8 - B4 Interior"},
	[8602]={"D16M02"}, [8603]={"D16M03","Exterior - Lv 2"}, [8604]={"D16M04","Interior - Lv 3"},
	[8605]={"D16M05","Interior - Lv 4-1"}, [8606]={"D16M06","Interior - Lv 4-2"},
	[8607]={"D16M07","Interior - Lv 4-3"}, [8608]={"D16M08","Interior - Lv 5"},
	[8609]={"D16M09","Interior - Lv 6"}, [8610]={"D16M10","Exterior - Lv 6"},
	[8611]={"D16M11","Interior - Lv 7"}, [8612]={"D16M12"}, [8613]={"D16M13","Interior - Summit Interior"},
	[8701]={"D17M01"}, [8702]={"D17M02","Oubliette - B3"}, [8703]={"D17M03","B3"}, [8704]={"D17M04","B4"},
	[8705]={"D17M05","B5"}, [8706]={"D17M06","B6"}, [8707]={"D17M07"}, [9000]={"T01","Tower of Trades"},
	[9001]={"T01M01"}, [9002]={"T01M02","Tower of Trades - Lv 3"},
	[9003]={"T01M03","Tower of Trades - Lv 4"}, [9004]={"T01M04","Tower of Trades - Lv 5"},
	[9005]={"T01M05","Lv 5"}, [9006]={"T01M06","Lv 6"}, [9007]={"T01M07","Lv 7"},
	[9008]={"T01M08","Ceremonial Chamber"}, [9100]={"T02","Tower of Nod"}, [9101]={"T02M01"},
	[9102]={"T02M02","Tower of Nod - Lv 3"}, [9103]={"T02M03","Tower of Nod - Lv 4"},
	[9104]={"T02M04","Tower of Nod - Lv 5"}, [9105]={"T02M05"}, [9106]={"T02M06","Lv 5 Exterior"},
	[9107]={"T02M07"}, [9108]={"T02M08","Exterior - Top"}, [9199]={"T02M99"}, [10000]={"O00","Ocean"},
	[10100]={"O01"}, [15100]={"H01","Island Shrine"}, [15200]={"H02","Way-Out Well"},
	[15300]={"H03","Pool of Spirits"}, [15400]={"H04","Forest Clearing"}, [15500]={"H05","Nicholas's Cabin"},
	[15600]={"H06","Woody Nickitt's House"}, [15700]={"H07","Tree in Lake"}, [15800]={"H08","Sequoia's Hideout"},
	[15900]={"H09","Uhohasis"}, [16000]={"H10","Herman's House"}, [16100]={"H11","Chris Cringle's Cottage"},
	[16200]={"H12","Chris Cringle's Paddock"}, [16300]={"H13","Brian's Cave"}, [16400]={"H14","Sealed Well"},
	[16500]={"H15","Doris's House"}, [16600]={"H16","Monster Research Institute"},
	[16700]={"H17","Eastern Wormwood"}, [16800]={"H18","Mountaintop Well - South"},
	[16900]={"H19","Western Wormwood"}, [17000]={"H20","Wyrmtail"}, [19997]={"F99M02"},
	[19998]={"F99M01"}, [19999]={"F99"}, [20000]={"K02"}, [20001]={"F01"},
	[20002]={"F02","Western Stornway Region"}, [20003]={"F03"}, [20004]={"F04","Doomingale Forest"},
	[20005]={"F05","Eastern Coffinwell Region"}, [20006]={"F06","Western Coffinwell Region"},
	[20007]={"F07","Newid Isle"}, [20008]={"F08"}, [20009]={"F09","Slurry Coast"},
	[20010]={"F10","Bloomingdale"}, [20011]={"F11","Dourbridge Region"}, [20012]={"F12","Lonely Plains"},
	[20013]={"F13"}, [20014]={"F14"}, [20015]={"F15","Djust Desert"}, [20016]={"F16","Hermany"},
	[20017]={"F17","Pluvi Isle"}, [20018]={"F18","Snowberia"}, [20019]={"F19","Cringle Coast"},
	[20020]={"F20","Urdus Marshland"}, [20021]={"F21","Iluugazar Plains"}, [20022]={"F22","Mt Ulzuun"},
	[20023]={"F23","Mt Ulbaruun"}, [20024]={"F24","Khaalag Coast"}, [20025]={"F25","Ondor Cliffs"},
	[20026]={"F26","Eastern Wormwood Region"}, [20027]={"F27","Western Wormwood Region"},
	[20028]={"F28","Wormwood Canyon"}, [20029]={"F29","Wyrmtail Region"}, [20030]={"F30","Wyrmwing Region"},
	[20031]={"F31"}, [20032]={"F32","Wyrmsmaw Region"}, [20033]={"F33","Wyrmneck Region"},
	[20034]={"F34","The Gittish Empire"}, [20038]={"F38","Eastern Stornway Region"},
	[20039]={"F39","Snowberian Coast"}, [20040]={"F40","Lonely Coast"}, [20041]={"F41"}, [20042]={"F42"},
	[20043]={"F43"}, [20044]={"F44"}, [20045]={"F45"}, [20046]={"F46"}, [20047]={"F47"},
	[20048]={"F48"}, [20049]={"F49"}, [20050]={"F50"}, [20051]={"F51"}, [20052]={"F52"},
	[20053]={"F53"}, [20054]={"F54"}, [20055]={"F55"}, [20056]={"F56"},
	[20057]={"F57","Hermany (Starflight)"}, [20058]={"F58"}, [20059]={"F59"}, [20060]={"F60"},
	[20061]={"F61"}, [20062]={"F62"}, [20063]={"F63","Zere Region"}, [20101]={"F01M01"},
	[20102]={"F01M02"}, [20111]={"F10M01","Bloomingdale (ending)"}, [20207]={"F07M02","Newid Isle (ending)"},
	[20341]={"F34M01","The Gittish Empire (ending)"}, [40001]={"Z00M01","Treasure Map -"},
	[40002]={"Z00M02","Treasure Map - Lv 2"}, [40003]={"Z00M03","Treasure Map - Lv 3"},
	[40004]={"Z00M04","Treasure Map - Lv 4"}, [40005]={"Z00M05","Treasure Map - Lv 5"},
	[40006]={"Z00M06","Treasure Map - Lv 6"}, [40007]={"Z00M07","Treasure Map - Lv 7"},
	[40008]={"Z00M08","Treasure Map - Lv 8"}, [40009]={"Z00M09","Treasure Map - Lv 9"},
	[40010]={"Z00M10","Treasure Map - Lv 10"}, [40011]={"Z00M11","Treasure Map - Lv 11"},
	[40012]={"Z00M12","Treasure Map - Lv 12"}, [40013]={"Z00M13","Treasure Map - Lv 13"},
	[40014]={"Z00M14","Treasure Map - Lv 14"}, [40015]={"Z00M15","Treasure Map - Lv 15"},
	[40016]={"Z00M16","Treasure Map - Lv 16"}, [40021]={"Z00M21"}, [40022]={"Z00M22"},
	[40023]={"Z00M23"}, [40024]={"Z00M24"}, [40025]={"Z00M25"}, [40026]={"Z00M26"},
	[40027]={"Z00M27"}, [40028]={"Z00M28"}, [40029]={"Z00M29"}, [40030]={"Z00M30"},
	[40031]={"Z00M31"}, [40032]={"Z00M32"}, [40033]={"Z00M33"}, [40034]={"Z00M34"},
	[40035]={"Z00M35"}, [40036]={"Z00M36"}, [40041]={"Z00M41"}, [40042]={"Z00M42"},
	[40043]={"Z00M43"}, [40044]={"Z00M44"}, [40045]={"Z00M45"}, [40046]={"Z00M46"},
	[40047]={"Z00M47"}, [40048]={"Z00M48"}, [40049]={"Z00M49"}, [40050]={"Z00M50"},
	[40051]={"Z00M51"}, [40052]={"Z00M52"}, [40053]={"Z00M53"}, [40054]={"Z00M54"},
	[40055]={"Z00M55"}, [40056]={"Z00M56"}, [40061]={"Z00M61"}, [40062]={"Z00M62"},
	[40063]={"Z00M63"}, [40064]={"Z00M64"}, [40065]={"Z00M65"}, [40066]={"Z00M66"},
	[40067]={"Z00M67"}, [40068]={"Z00M68"}, [40069]={"Z00M69"}, [40070]={"Z00M70"},
	[40071]={"Z00M71"}, [40072]={"Z00M72"}, [40073]={"Z00M73"}, [40074]={"Z00M74"},
	[40075]={"Z00M75"}, [40076]={"Z00M76"}, [40081]={"Z00M81"}, [40082]={"Z00M82"},
	[40083]={"Z00M83"}, [40084]={"Z00M84"}, [40085]={"Z00M85"}, [40086]={"Z00M86"},
	[40087]={"Z00M87"}, [40088]={"Z00M88"}, [40089]={"Z00M89"}, [40090]={"Z00M90"},
	[40091]={"Z00M91"}, [40092]={"Z00M92"}, [40093]={"Z00M93"}, [40094]={"Z00M94"},
	[40095]={"Z00M95"}, [40096]={"Z00M96"}, [40101]={"Z01M01","Natural Level 1"},
	[40102]={"Z01M02","Natural Level 2"}, [40103]={"Z01M03","Natural Level 3"},
	[40104]={"Z01M04","Natural Level 4"}, [40105]={"Z01M05","Natural Level 5"},
	[40106]={"Z01M06","Natural Level 6"}, [40107]={"Z01M07","Natural Level 7"},
	[40108]={"Z01M08","Natural Level 8"}, [40109]={"Z01M09","Natural Level 9"},
	[40110]={"Z01M10","Natural Level 10"}, [40111]={"Z01M11","Natural Level 11"},
	[40112]={"Z01M12","Natural Level 12"}, [40201]={"Z02M01","Man-Made Level 1"},
	[40202]={"Z02M02","Man-Made Level 2"}, [40203]={"Z02M03","Man-Made Level 3"},
	[40204]={"Z02M04","Man-Made Level 4"}, [40205]={"Z02M05","Man-Made Level 5"},
	[40206]={"Z02M06","Man-Made Level 6"}, [40207]={"Z02M07","Man-Made Level 7"},
	[40208]={"Z02M08","Man-Made Level 8"}, [40209]={"Z02M09","Man-Made Level 9"},
	[40210]={"Z02M10","Man-Made Level 10"}, [40211]={"Z02M11","Man-Made Level 11"},
	[40212]={"Z02M12","Man-Made Level 12"}, [40301]={"Z03M01","Icy Level 1"}, [40302]={"Z03M02","Icy Level 2"},
	[40303]={"Z03M03","Icy Level 3"}, [40304]={"Z03M04","Icy Level 4"}, [40305]={"Z03M05","Icy Level 5"},
	[40306]={"Z03M06","Icy Level 6"}, [40307]={"Z03M07","Icy Level 7"}, [40308]={"Z03M08","Icy Level 8"},
	[40309]={"Z03M09","Icy Level 9"}, [40310]={"Z03M10","Icy Level 10"}, [40311]={"Z03M11","Icy Level 11"},
	[40312]={"Z03M12","Icy Level 12"}, [40401]={"Z04M01","Watery Level 1"}, [40402]={"Z04M02","Watery Level 2"},
	[40403]={"Z04M03","Watery Level 3"}, [40404]={"Z04M04","Watery Level 4"},
	[40405]={"Z04M05","Watery Level 5"}, [40406]={"Z04M06","Watery Level 6"},
	[40407]={"Z04M07","Watery Level 7"}, [40408]={"Z04M08","Watery Level 8"},
	[40409]={"Z04M09","Watery Level 9"}, [40410]={"Z04M10","Watery Level 10"},
	[40411]={"Z04M11","Watery Level 11"}, [40412]={"Z04M12","Watery Level 12"},
	[40501]={"Z05M01","Fiery Level 1"}, [40502]={"Z05M02","Fiery Level 2"}, [40503]={"Z05M03","Fiery Level 3"},
	[40504]={"Z05M04","Fiery Level 4"}, [40505]={"Z05M05","Fiery Level 5"}, [40506]={"Z05M06","Fiery Level 6"},
	[40507]={"Z05M07","Fiery Level 7"}, [40508]={"Z05M08","Fiery Level 8"}, [40509]={"Z05M09","Fiery Level 9"},
	[40510]={"Z05M10","Fiery Level 10"}, [40511]={"Z05M11","Fiery Level 11"},
	[40512]={"Z05M12","Fiery Level 12"}, [41101]={"Z01M95","Natural Level Boss Floor"}, [41102]={"Z01M96"},
	[41103]={"Z01M97"}, [41104]={"Z01M98"}, [41105]={"Z01M99"},
	[41201]={"Z02M95","Man-Made Level Boss Floor"}, [41202]={"Z02M96"}, [41203]={"Z02M97"},
	[41204]={"Z02M98"}, [41205]={"Z02M99"}, [41301]={"Z03M95","Icy Level Boss Floor"},
	[41302]={"Z03M96"}, [41303]={"Z03M97"}, [41304]={"Z03M98"}, [41305]={"Z03M99"},
	[41401]={"Z04M95","Watery Level Boss Floor"}, [41402]={"Z04M96"}, [41403]={"Z04M97"},
	[41404]={"Z04M98"}, [41405]={"Z04M99"}, [41501]={"Z05M95","Fiery Level Boss Floor"},
	[41502]={"Z05M96"}, [41503]={"Z05M97"}, [41504]={"Z05M98"},
	[41505]={"Z05M99","R - Quester's Rest"}, [50101]={"R01M01","Lobby Interior 1"},
	[50102]={"R01M02","Lounge Interior 1"}, [50103]={"R01M03","Guest Room Interior 1"},
	[50107]={"R01M07","Guardian Fountain"}, [50108]={"R01M08","Royal Suites - Corridor"},
	[50109]={"R01M09","Royal Suites - East"}, [50110]={"R01M10","Royal Suites - West"},
	[50201]={"R02M01","Lobby Interior 2"}, [50202]={"R02M02","Lounge Interior 2"},
	[50203]={"R02M03","Guest Room Interior 2"}, [50204]={"R02M04","Cafeteria Interior 2"},
	[50205]={"R02M05","Executive Suite Interior 2"}, [50301]={"R03M01","Lobby Interior 3"},
	[50302]={"R03M02","Lounge Interior 3"}, [50303]={"R03M03","Guest Room Interior 3"},
	[50304]={"R03M04","Cafeteria Interior 3"}, [50305]={"R03M05","Executive Suite Interior 3"},
	[50306]={"R03M06","Library Interior 3"}, [50401]={"R04M01","Lobby Interior 4"},
	[50402]={"R04M02","Lounge Interior 4"}, [50403]={"R04M03","Guest Room Interior 4"},
	[50404]={"R04M04","Cafeteria Interior 4"}, [50405]={"R04M05","Executive Suite Interior 4"},
	[50406]={"R04M06","Library Interior 4"}, [50501]={"R05M01","VIP - Cannock"},
	[50502]={"R05M01","VIP - Cannock"}, [50503]={"R05M01","VIP - Cannock"}, [50504]={"R05M01","VIP - Cannock"},
	[50505]={"R05M01","VIP - Cannock"}, [50506]={"R05M01","VIP - Cannock"}, [50507]={"R05M01","VIP - Cannock"},
	[50508]={"R05M01","VIP - Cannock"}, [50509]={"R05M01","VIP - Cannock"}, [50510]={"R05M01","VIP - Cannock"},
	[50511]={"R05M01","VIP - Cannock"}, [50512]={"R05M01","VIP - Cannock"}, [50513]={"R05M01","VIP - Cannock"},
	[50514]={"R05M01","VIP - Cannock"}, [50515]={"R05M01","VIP - Cannock"}, [50516]={"R05M01","VIP - Cannock"},
	[50517]={"R05M01","VIP - Cannock"}, [50518]={"R05M01","VIP - Cannock"}, [50519]={"R05M01","VIP - Cannock"},
	[50520]={"R05M01","VIP - Cannock"}, [50521]={"R05M01","VIP - Cannock"}, [50522]={"R05M01","VIP - Cannock"},
	[50523]={"R05M01","VIP - Cannock"}, [51101]={"E01M01","Credits B"}, [51102]={"E01M02","Credits C"},
	[51103]={"E01M03","Credits D"}, [51104]={"E01M04","Credits F"}, [51105]={"E01M05","Credits H"},
	[51106]={"E01M06","Credits I"}, [51107]={"E01M07","Credits S"}, [51108]={"E01M08","Credits T"},
	[51109]={"E01M09","Credits J"}, [51110]={"E01M10","Credits K"}, [51111]={"E01M11","Credits L"},
}
AREAS = {
	C01="Stornway", C02="Gleeba", C04="Gittingham Palace", D01="The Hexagon", D04="Quarantomb",
	D07="Heights of Loneliness", D09="The Bad Cave", D14="The Bowhole", F02="Western Stornway Region",
	F04="Doomingale Forest", F05="Eastern Coffinwell Region", F06="Western Coffinwell Region", F07="Newid Isle",
	F09="Slurry Coast", F10="Bloomingdale", F11="Dourbridge Region", F12="Lonely Plains", F15="Djust Desert",
	F16="Hermany", F17="Pluvi Isle", F18="Snowberia", F19="Cringle Coast", F20="Urdus Marshland",
	F21="Iluugazar Plains", F22="Mt Ulzuun", F23="Mt Ulbaruun", F24="Khaalag Coast", F25="Ondor Cliffs",
	F26="Eastern Wormwood Region", F27="Western Wormwood Region", F28="Wormwood Canyon", F29="Wyrmtail Region",
	F30="Wyrmwing Region", F32="Wyrmsmaw Region", F33="Wyrmneck Region", F34="The Gittish Empire",
	F38="Eastern Stornway Region", F39="Snowberian Coast", F40="Lonely Coast", F57="Hermany (Starflight)",
	F63="Zere Region", H01="Island Shrine", H02="Way-Out Well", H03="Pool of Spirits", H04="Forest Clearing",
	H05="Nicholas's Cabin", H06="Woody Nickitt's House", H07="Tree in Lake", H08="Sequoia's Hideout",
	H09="Uhohasis", H10="Herman's House", H11="Chris Cringle's Cottage", H12="Chris Cringle's Paddock",
	H13="Brian's Cave", H14="Sealed Well", H15="Doris's House", H16="Monster Research Institute",
	H17="Eastern Wormwood", H18="Mountaintop Well - South", H19="Western Wormwood", H20="Wyrmtail",
	M01="Angel Falls", M02="Zere", M03="Coffinwell", M05="Porth Llaffan", M07="Zere Rocks", M08="Dourbridge",
	M09="Basement on Right Under Bridge", M10="Batsureg", M11="Swinedimples Academy", M12="Wormwood Creek",
	M13="Upover", O00="Ocean", S02="Loch Storn", S03="Eastern Checkpoint", S04="Hexagon Hill",
	S05="Cuddiedig Cliff", S06="Hunters' Yurts", S07="Gortress", S08="Slurry Quay", S09="Ship - Deck",
	S10="Mountain Hut", S11="Ulbaruun Cave", S12="Bloomingdale Region", S15="Wyrmward", T01="Tower of Trades",
	T02="Tower of Nod", X01="Observatory", X02="Alltrades Abbey", X03="Realm of the Almighty",
	X04="Realm of the Mighty", X05="Observatory (After Attack)",
}
-- item number -> name, read from the game's own item table
ITEM_NAMES = {
	[12170]="wonder helm", [12171]="heavenly helm", [12180]="raging bull helm", [12181]="minotaur helm", [12182]="great helm", [12183]="veteran's helm",
	[12184]="skull helm", [12185]="liquid metal helm", [12186]="metal king helm", [12187]="rusty helmet", [12188]="hallowed helm", [12189]="blessed helm",
	[12191]="iron helmet", [12192]="Ragnar's helm", [12193]="Alefgard helm", [12194]="Erdrick's helmet", [12195]="Midenhall helm", [12197]="metal slime helm",
	[12198]="steel helmet", [12199]="gigasteel helmet", [12200]="feather headband", [12201]="circlet", [12202]="battler's band", [12204]="ravishing ribbon",
	[12205]="hairband", [12206]="crown of clarity", [12207]="steely sweatband", [12208]="silver tiara", [12209]="golden tiara", [12211]="gold circlet",
	[12212]="star circlet", [12290]="Aliahan headpiece", [12291]="spellward circlet", [12292]="Zenithian helm", [12295]="thinking cap", [12296]="scholar's circlet",
	[12400]="warrior's helm", [12401]="hocus hat", [12402]="hermetic hat", [12403]="musketeer hat", [12404]="cavalier hat", [12405]="Minerva's mitre",
	[12406]="canny cap", [12407]="hunter's hat", [12408]="ear cosy", [12409]="top hat", [12410]="bandana", [12411]="hardwood headwear",
	[12412]="sun crown", [12413]="Apollo's crown", [12414]="trailblazing bandana", [12415]="Mercury's bandana", [12416]="feathered cap", [12417]="magical hat",
	[12418]="mega-magical hat", [12419]="witch's hat", [12420]="unhappy hat", [12421]="happy hat", [12422]="spring breeze hat", [12423]="summer cloud hat",
	[12424]="autumn shower hat", [12425]="winter sky hat", [12426]="Kiryl's kamilavka", [12428]="Santa's hat", [12429]="holy hat", [12430]="Torneko's cap",
	[12431]="Yangus's titfer", [12432]="Erinn's headkerchief", [12433]="tip-top topper", [12434]="proper topper", [12436]="swashbuckler's bonnet", [12480]="mitre",
	[12491]="Trodain bandana", [12492]="Gothan turban", [12493]="Estard hood", [12494]="Alena's hat", [12495]="turban", [12496]="pointy hat",
	[12497]="slime crown", [12498]="leather hat", [12499]="wizard's hat", [12500]="thug's mug", [12501]="Trodeface", [12502]="pumpkin head",
	[12503]="skull cap", [12600]="tricky turban", [12700]="thief's turban", [12701]="disturbin' turban", [12702]="mail coif", [12780]="Moonbrooke hood",
	[12781]="Maribel's hood", [12785]="dragon warrior helm", [12790]="iron mask", [12791]="filigree mask", [12792]="platinum headgear", [12793]="mythril coif",
	[12794]="Hades' helm", [12795]="mythril helm", [12796]="fur hood", [12797]="slood", [12800]="bunny ears", [12801]="cat ears",
	[12802]="phantom mask", [12803]="stellar starflower", [12804]="Fleurette's floret", [12805]="halo", [12806]="Debora's damasks", [12807]="malleable mask",
	[12808]="papillon mask", [12809]="maid's mop", [12810]="silken veil", [12811]="supernatural specs", [12812]="sharp shades", [12813]="monarchic moustache",
	[12814]="x-ray specs", [12815]="silver specs", [12900]="Somnia hair", [12901]="Cannock helm", [12902]="Borya's bouffant", [12903]="Maya's mane",
	[12904]="Meena's mane", [12907]="Bianca's braid", [12908]="Nera's hair", [12909]="Carver's hair", [12910]="Milly's hair", [12911]="Ashlynn's hair",
	[12912]="Kiefer's hair", [12913]="Jess's tresses", [12914]="Templar's tresses", [12915]="Morrie's mullet", [12916]="brown afro", [12917]="red afro",
	[13000]="warrior's armour", [13001]="tussler's top", [13002]="flamenco shirt", [13003]="fur vest", [13004]="star's suit", [13005]="plain clothes",
	[13006]="training top", [13007]="celestial suit", [13009]="Swinedimples blazer", [13010]="tracksuit top", [13011]="garish garb", [13012]="cloak of evasion",
	[13013]="cloak of concealment", [13014]="gooey gear", [13015]="smart suit", [13016]="superstar's suit", [13017]="dragon top", [13018]="combat top",
	[13020]="twinkling tuxedo", [13021]="tropotoga", [13022]="stratotoga", [13023]="mesotoga", [13024]="exotoga", [13025]="Carver's vest",
	[13026]="Kiefer's clothes", [13027]="Yangus's billy", [13028]="GUSTO garb", [13031]="muscle belt", [13032]="best vest", [13033]="glombolero",
	[13034]="Aquila's armour", [13035]="white tuxedo", [13036]="Santa suit", [13037]="skeleton suit", [13038]="captain's coat", [13039]="white t-shirt",
	[13040]="jolly roger jumper", [13041]="shipmate's shirt", [13080]="Midenhall garb", [13095]="wayfarer's clothes", [13096]="Trodain togs", [13097]="Somnia clothes",
	[13098]="Estard clothes", [13099]="Zenithian clothes", [13100]="tactical vest", [13101]="leather armour", [13102]="scale armour", [13103]="chain mail",
	[13160]="mythical armour", [13161]="legendary armour", [13162]="dragon warrior armour", [13170]="sacrosanct armour", [13171]="veteran's armour", [13172]="mirror armour",
	[13173]="catoptric armour", [13174]="gigant armour", [13175]="liquid metal armour", [13176]="metal king armour", [13177]="rusty armour", [13178]="victorious armour",
	[13179]="glorious armour", [13180]="silver mail", [13181]="gold mail", [13182]="platinum mail", [13183]="heavy armour", [13184]="magic armour",
	[13185]="enchanted armour", [13186]="ethereal armour", [13187]="dragon mail", [13188]="spiked armour", [13189]="sacred armour", [13190]="metal slime armour",
	[13192]="iron armour", [13193]="Ragnar's armour", [13194]="Alefgard armour", [13195]="Erdrick's armour", [13196]="large-scale armour", [13197]="bronze armour",
	[13198]="full plate armour", [13199]="gigasteel armour", [13200]="holy mail", [13201]="fencing frock", [13202]="nomadic deel", [13203]="leather cape",
	[13204]="fur poncho", [13205]="velvet cape", [13206]="majestic mantle", [13207]="dark robe", [13208]="macabre mantle", [13209]="Pallium Regale",
	[13210]="cape of good karma", [13211]="Templar's togs", [13290]="Aliahan clothes", [13291]="Gothan robe", [13292]="divine dress", [13300]="ascetic robe",
	[13301]="rogue's robes", [13302]="roguess's robes", [13303]="fencing jacket", [13304]="sage's robe", [13305]="silk robe", [13306]="robe of serenity",
	[13307]="nightmare gown", [13308]="Celestria's gown", [13309]="Celestria's raiment", [13310]="dragon robe", [13311]="Xenlon robe", [13312]="angel's robe",
	[13313]="archangel's robe", [13314]="aeon's robe", [13315]="seraph's robe", [13316]="Kiryl's clothes", [13317]="Borya's robe", [13318]="Torneko's clothes",
	[13320]="Trode's robes", [13324]="robe of sweet dreams", [13325]="magical robes", [13326]="enchanted robes", [13327]="ethereal robes", [13328]="saintly robe",
	[13329]="flowing dress", [13390]="wizard's robe", [13391]="witch's robe", [13490]="surplice", [13491]="Cannock cloak", [13500]="strongsam",
	[13501]="priestess's pinafore", [13502]="dancer's dress", [13503]="maiden's mantle", [13504]="spangled dress", [13505]="dragon dress", [13506]="shimmering dress",
	[13507]="queen's robe", [13508]="empress's robe", [13509]="prince's pea coat", [13510]="king's coat", [13511]="emperor's attire", [13513]="Moonbrooke dress",
	[13514]="Meena's robe", [13515]="Nera's dress", [13516]="Milly's clothes", [13517]="Maribel's clothes", [13518]="Jessica's frock", [13519]="leather dress",
	[13520]="plain dress", [13521]="summer dress", [13522]="jaguarment", [13590]="princess's robe", [13600]="Fizzle-retardant blouse", [13601]="Femiscyran mail",
	[13602]="brawling byrnie", [13603]="holy femail", [13604]="tint-tastic tutu", [13605]="dancer's costume", [13606]="bunny suit", [13607]="technicolour tutu",
	[13608]="dangerous bikini top", [13609]="hot bikini top", [13610]="sizzling bikini top", [13612]="dangerous bustier", [13613]="silk bustier", [13614]="divine bustier",
	[13615]="Maya's outfit", [13616]="Bianca's clothes", [13617]="Ashlynn's clothes", [13618]="stellar suit", [13619]="Fleurette's frock", [13620]="maid outfit",
	[13621]="Debora's dress", [13622]="Erinn's outfit", [13623]="Patty's dirndl", [13624]="Sellma's frock", [13625]="wedding dress", [13626]="Santa's little helper suit",
	[13627]="combat costume", [13695]="Zenithian leotard", [13696]="Alena's dress", [13700]="Fizzle-retardant suit", [13701]="Fizzle-proof suit", [13790]="iron cuirass",
	[13791]="tortoise shell", [13793]="silver cuirass", [13794]="tortoiseshell armour", [15000]="warrior's gloves", [15001]="gorgeous gloves", [15002]="mental mittens",
	[15003]="cotton gloves", [15004]="linen gloves", [15005]="leather gloves", [15007]="riotous wristbands", [15008]="blessed bindings", [15009]="rubber gloves",
	[15010]="wayfarer's gloves", [15013]="mayoress's mittens", [15014]="marquess's mittens", [15015]="monarch's mittens", [15016]="veteran's gloves", [15017]="enchantress's gloves",
	[15018]="minister's mittens", [15019]="glommer's gloves", [15020]="guru's gloves", [15021]="gloomy gloves", [15022]="murky mittens", [15023]="matador's gloves",
	[15024]="apprentice's gloves", [15025]="master's gloves", [15026]="grandmaster's gloves", [15027]="godly gloves", [15028]="Zenithian gauntlet", [15029]="Gothan wristbands",
	[15030]="Maya's bracelets", [15031]="Meena's bracelets", [15032]="heavy handwear", [15033]="silver bracelets", [15034]="Bianca's bracelets", [15035]="Nera's bracelets",
	[15036]="Carver's bracers", [15037]="Milly's bracers", [15038]="Ashlynn's gloves", [15039]="ultramarine mittens", [15040]="blindin' bracers", [15041]="Angelo's gloves",
	[15042]="grandissimo gloves", [15043]="battler's bracers", [15045]="einhander", [15047]="crimson gauntlets", [15048]="lockpicker's mitts", [15091]="Kiefer's gloves",
	[15092]="Alefgard gloves", [15093]="Midenhall gloves", [15094]="Cannock gloves", [15095]="Aliahan gloves", [15096]="McRyan's mittens", [15097]="Alena's gloves",
	[15100]="fingerless gauntlets", [15101]="bruiser's bracers", [15102]="Femiscyran fingerwear", [15103]="metallic mitts", [15105]="light gauntlets", [15106]="archer's armguard",
	[15107]="sturdy gauntlets", [15108]="heavy gauntlets", [15109]="fingerless gloves", [15190]="Somnia gloves", [15200]="leather gauntlets", [15280]="ethereal gloves",
	[15281]="rusty gauntlets", [15282]="Vesta gauntlets", [15283]="Diana gauntlets", [15284]="Tempestes gauntlets", [15285]="Sol Invictus gauntlets", [15286]="dragon warrior gloves",
	[15291]="iron gauntlets", [15292]="Erdrick's gauntlets", [15293]="steel gauntlets", [15294]="gigasteel gauntlets", [15295]="metal slime gauntlets", [15296]="liquid metal slime gloves",
	[15297]="metal king slime gloves", [15298]="magic mittens", [15299]="enchanted gloves", [16093]="Somnia shorts", [16094]="boxer shorts", [16095]="leather kilt",
	[16100]="Femiscyran bottoms", [16103]="chainmail socks", [16104]="pop socks", [16191]="Zenithian leggings", [16200]="warrior's trousers", [16202]="nicker's knickers",
	[16203]="tussler's trousers", [16204]="wizard's trousers", [16205]="loud trousers", [16206]="battle britches", [16207]="swordsman's slacks", [16208]="red tights",
	[16209]="green tights", [16210]="steppe steppers", [16211]="blessed bottoms", [16212]="white tights", [16213]="cotton trousers", [16214]="training trousers",
	[16215]="celestial stockings", [16216]="boomer briefs", [16217]="wonder pants", [16218]="iron kneecaps", [16219]="steel kneecaps", [16220]="gigasteel kneecaps",
	[16221]="fancy pants", [16222]="transparent tights", [16223]="dragon trousers", [16224]="combat trousers", [16228]="tantric trousers", [16229]="sturdy slacks",
	[16230]="impregnable leggings", [16231]="invincible trousers", [16232]="immortal trousers", [16233]="eternity trousers", [16234]="infinity trousers", [16235]="Cannock trousers",
	[16236]="Kiryl's trousers", [16237]="Torneko's trousers", [16240]="Carver's shorts", [16241]="Milly's pants", [16243]="Kiefer's trousers", [16244]="cor blimey trousers",
	[16245]="PASSION tights", [16246]="stellar stockings", [16248]="Fleurette's chaussettes", [16251]="toughie trousers", [16252]="Templar's trousers", [16255]="tracky bottoms",
	[16256]="dragon warrior trousers", [16257]="Aquila's trousers", [16258]="Swinedimples slacks", [16259]="white tuxedo trousers", [16260]="Santa's slacks", [16261]="skeletal slacks",
	[16262]="pirate pantaloons", [16263]="blue jeans", [16283]="trinity tights", [16286]="Midenhall trousers", [16287]="Alefgard trousers", [16288]="Aliahan trousers",
	[16289]="Zenithian trousers", [16290]="Estard trousers", [16291]="Trodain trousers", [16300]="sorcerer's slacks", [16301]="slick slacks", [16302]="fishnet stockings",
	[16303]="dangerous midriff wrap", [16304]="hot bikini bottoms", [16305]="sizzling bikini bottoms", [16306]="Swinedimples skirt", [16307]="red skirt", [16308]="blue skirt",
	[16309]="kiltlet", [16310]="Maya's bottoms", [16311]="denim skirt", [16312]="blue knickers", [16313]="black knickers", [16316]="springtime skirt",
	[16317]="snazzy skirt", [16318]="magical skirt", [16319]="seabreeze skirt", [16390]="Alena's tights", [17091]="Gothan gumboots", [17092]="Somnia boots",
	[17093]="Estard shoes", [17094]="Zenithian boots", [17095]="Aliahan boots", [17096]="Trodainers", [17100]="warrior's boots", [17101]="frugal footwear",
	[17102]="bandit boots", [17103]="sneakers", [17104]="kung fu shoes", [17105]="wizard wellies", [17106]="acroboots", [17107]="wu shoes",
	[17108]="Femiscyran footwear", [17109]="cowboy boots", [17110]="hip boots", [17111]="safety shoes", [17112]="clever clogs", [17113]="shaman shoes",
	[17114]="agiliboots", [17115]="hiking boots", [17116]="bardic boots", [17117]="crimson boots", [17118]="leather boots", [17119]="wellington boots",
	[17120]="celestial shoes", [17140]="Erinn's boots", [17141]="Patty's pumps", [17142]="Aquila's boots", [17143]="white wing-tips", [17150]="Blahnolo Maniks",
	[17152]="chic chaussures", [17155]="thug boots", [17158]="Borya's boots", [17159]="spellspadrilles", [17160]="Ashlynn's shoes", [17163]="Kiefer's shoes",
	[17164]="Maribel's shoes", [17165]="Trode's treads", [17166]="bovver boots", [17167]="posh pumps", [17168]="Templar boots", [17169]="Casanova clogs",
	[17170]="pixie boots", [17171]="tricksie boots", [17172]="Moonbrooke shoes", [17173]="Kiryl's boots", [17176]="Bianca's boots", [17177]="Nera's boots",
	[17178]="Carver's shoes", [17179]="Milly's shoes", [17181]="brahman boots", [17182]="hero's boots", [17183]="basilic boots", [17184]="emperor's boots",
	[17185]="boots of beatitude", [17186]="safer shoes", [17187]="safest shoes", [17188]="depressing shoes", [17189]="elevating shoes", [17191]="valenki",
	[17192]="Alefgard boots", [17193]="Midenhall boots", [17194]="Cannock boots", [17195]="hobnail boots", [17196]="veteran's boots", [17197]="combat boots",
	[17198]="she-mage shoes", [17199]="blessed boots", [17300]="payback pumps", [17302]="saintly sollerets", [17303]="dragon warrior boots", [17391]="iron sabatons",
	[17392]="highland boots", [17394]="metal slime sollerets", [17395]="steel sabatons", [17396]="gigasteel sabatons", [17397]="liquid metal slime boots", [17398]="metal king slime boots",
	[17400]="siren sandals", [17401]="she-fu shoes", [17402]="sheepskin shoes", [17403]="starlet sandals", [17404]="leather shoes", [17405]="clogs",
	[17406]="sandals", [17407]="classy clogs", [17408]="high heels", [17409]="stiletto heels", [17410]="highness heels", [17411]="galvanised geta",
	[17412]="sorceress sandals", [17413]="high-class heels", [17414]="sensible sandals", [17415]="sagacious sandals", [17416]="sapient sandals", [17417]="sentient sandals",
	[17419]="Torneko's sandals", [17420]="Sattriya sandals", [17421]="Samhita sandals", [18000]="strength ring", [18001]="tough guy tattoo", [18002]="raging ruby",
	[18003]="mighty armlet", [18004]="gold bracer", [18005]="slime earrings", [18006]="dragon scale", [18007]="gold ring", [18008]="ruby of protection",
	[18009]="bunny tail", [18010]="pink pearl", [18011]="bow tie", [18012]="utility belt", [18013]="agility ring", [18014]="meteorite bracer",
	[18015]="sorcerer's ring", [18016]="gold rosary", [18017]="rosary", [18018]="sorcerer's stone", [18019]="brainy bracer", [18020]="life bracer",
	[18021]="spirit bracer", [18022]="monarchic mark", [18023]="prayer ring", [18024]="holy talisman", [18025]="sober ring", [18026]="contra band",
	[18027]="full moon ring", [18028]="rousing ring", [18029]="ring of clarity", [18030]="catholicon ring", [18031]="terrible tattoo", [18032]="skull ring",
	[18033]="elfin charm", [18034]="life ring", [18035]="Goddess ring", [18038]="reckless necklace", [18039]="lucky pendant", [18040]="Venus' tear",
	[18043]="soldier's medal", [18044]="lifesaving medal", [18045]="mager achievement", [18046]="Mercury prize", [18047]="honour among thieves", [18048]="wear-with-all award",
	[18049]="critical acclaim", [18050]="order of chivalry", [18051]="combat action medal", [18052]="medal of freedom", [18053]="legion of merit", [18054]="Noscar",
	[18055]="wedding ring", [19050]="paring knife", [19051]="bronze knife", [19052]="divine dagger", [19053]="poison moth knife", [19054]="batterfly knife",
	[19055]="dread dagger", [19057]="poison needle", [19058]="assassin's dagger", [19059]="icicle dirk", [19060]="Fenrir fang", [19061]="deadly nightblade",
	[19062]="sword breaker", [19063]="soul breaker", [19064]="falcon knife earring", [19065]="gladius", [19066]="flame tang", [19067]="pruning knife",
	[19068]="deft dagger", [19069]="darting dagger", [19070]="dashing dagger", [19071]="dynamo dagger", [19150]="oaken club", [19151]="ace of clubs",
	[19152]="sledgehammer", [19153]="war hammer", [19154]="Uber war hammer", [19155]="giant wrench", [19156]="terra tamper", [19157]="terra firmer",
	[19158]="terra hammer", [19159]="marauder's maul", [19160]="Hela's hammer", [19161]="giant's hammer", [19162]="titan's hammer", [19163]="megaton hammer",
	[19164]="warlord's hammer", [19165]="groundbreaker", [19166]="earthsplitter", [19167]="moonmasher", [19168]="starsmasher", [20000]="warrior's sword",
	[20001]="bandit blade", [20002]="Valkyrie sword", [20003]="rapier", [20004]="copper sword", [20005]="soldier's sword", [20006]="iron broadsword",
	[20007]="steel broadsword", [20008]="gigasteel broadsword", [20009]="Fizzle foil", [20010]="cautery sword", [20011]="aurora blade", [20012]="platinum sword",
	[20013]="dragonsbane", [20014]="dragon slayer", [20015]="falcon blade", [20016]="Uber falcon blade", [20017]="miracle sword", [20018]="Uber miracle sword",
	[20019]="fire blade", [20020]="inferno blade", [20021]="metal slime sword", [20022]="liquid metal sword", [20023]="metal king sword", [20024]="rusty sword",
	[20025]="Erdrick's sword", [20026]="stardust sword", [20027]="nebula sword", [20028]="supernova sword", [20029]="hypernova sword", [20100]="feather fan",
	[20101]="iron fan", [20102]="steel fan", [20103]="gigasteel fan", [20104]="war fan", [20105]="foehn fan", [20106]="gale force fan",
	[20107]="tortoiseshell fan", [20108]="Black Tortoise fan", [20109]="feline fan", [20110]="White Tiger fan", [20111]="fowl fan", [20112]="Vermillion Bird fan",
	[20113]="cobra fan", [20114]="Azure Dragon fan", [20115]="stellar fan", [20116]="lunar fan", [20117]="solar fan", [20118]="friendly fan",
	[20119]="attribeauty", [20120]="critical fan", [20121]="overcritical fan", [20122]="hypercritical fan", [20123]="dire critical fan", [20124]="white bouquet",
	[20200]="battle-axe", [20201]="pro's axe", [20202]="steel axe", [20203]="gigasteel axe", [20204]="golden axe", [20205]="moon axe",
	[20206]="full moon axe", [20207]="kaiser axe", [20208]="headsman's axe", [20209]="executioner's axe", [20210]="ice axe", [20211]="avalanche axe",
	[20212]="heavy hatchet", [20213]="bad axe", [20214]="maxi axe", [20215]="climaxe", [20216]="galaxy axe", [20291]="king axe",
	[20293]="iron axe", [20300]="leather whip", [20301]="thorn whip", [20302]="battle whip", [20303]="snakeskin whip", [20304]="serpentine whip",
	[20305]="sidewinder", [20306]="chain whip", [20307]="iron whip", [20308]="spiked steel whip", [20309]="gigaspike whip", [20310]="dragontail whip",
	[20311]="demon whip", [20312]="archdemon whip", [20313]="scourge whip", [20314]="queen's whip", [20315]="empress's whip", [20316]="Goddess whip",
	[20317]="wizardly whip", [20318]="Gringham whip", [20319]="mega Gringham whip", [20320]="giga Gringham whip", [20321]="Uber Gringham whip", [20400]="hieroglyph staff",
	[20401]="sage's staff", [20402]="brouhaha boomstick", [20403]="oak staff", [20404]="staff of sentencing", [20405]="staff of divine wrath", [20406]="Stolos' staff",
	[20407]="lightning conductor", [20408]="watermaul wand", [20409]="tsunami staff", [20410]="rune staff", [20411]="mega-magical mace", [20412]="Sceptre of Gitt",
	[20413]="savant's staff", [20414]="wyrmwand", [20415]="bright staff", [20416]="shining staff", [20417]="brilliant staff", [20418]="aurora staff",
	[20419]="faerie staff", [20493]="magical mace", [20494]="wizard's staff", [20495]="lightning staff", [20496]="magma staff", [20500]="bamboo lance",
	[20501]="celestial spear", [20502]="partisan", [20503]="iron lance", [20504]="steel lance", [20505]="gigasteel lance", [20506]="long spear",
	[20507]="holy lance", [20508]="battle fork", [20509]="trident", [20510]="Gracos's trident", [20511]="sandstorm spear", [20512]="halberd",
	[20513]="lightning lance", [20514]="storm spear", [20515]="demon spear", [20516]="hero spear", [20517]="metal slime spear", [20518]="liquid metal spear",
	[20519]="metal king spear", [20520]="poker", [20521]="stud poker", [20522]="split-pot poker", [20523]="red-hot poker", [20600]="laundry pole",
	[20601]="carrying pole", [20602]="oaken pole", [20603]="iron bar", [20604]="steel bar", [20605]="gigasteel bar", [20606]="pillar of strength",
	[20607]="sleepy stick", [20608]="slumber stick", [20609]="driller pillar", [20610]="killer pillar", [20611]="mistick", [20612]="optimistick",
	[20613]="ballistick", [20614]="sadistick", [20615]="dragon rod", [20616]="Xenlon rod", [20617]="orichalcudgel", [20618]="knockout rod",
	[20619]="senseless stick", [20620]="catatonic cosh", [20621]="coma cudgel", [20700]="boomerang", [20701]="reinforced boomerang", [20702]="edged boomerang",
	[20703]="cutting-edge boomerang", [20704]="crucerang", [20705]="razor-wing boomerang", [20706]="razer-wing boomerang", [20707]="erazor-wing boomerang", [20708]="swallowtail",
	[20709]="eaglewing", [20710]="gusterang", [20711]="blusterang", [20712]="flametang boomerang", [20713]="banefire boomerang", [20714]="pentarang",
	[20715]="hexarang", [20716]="meteorang", [20717]="asterang", [20718]="stellarang", [20719]="galaxarang", [20800]="stone claws",
	[20801]="iron claws", [20802]="steel claws", [20803]="gigasteel claws", [20804]="sacred claws", [20805]="razor claws", [20806]="crow's claws",
	[20807]="kestrel claws", [20808]="kite claws", [20809]="handrills", [20810]="hammer handrills", [20811]="dragon claws", [20812]="fire claws",
	[20813]="combusticlaws", [20814]="cobra claws", [20815]="king cobra claws", [20816]="beast claws", [20817]="beastmaster claws", [20818]="orichalcum claws",
	[20819]="Dragonlord claws", [20820]="Dragovian claws", [20821]="Dragovian lord claws", [20822]="Xenlon claws", [20900]="potshot bow", [20901]="short bow",
	[20902]="longbow", [20903]="hunter's bow", [20904]="Fuddle bow", [20905]="Cheiron's bow", [20906]="hotshot bow", [20907]="blowy bow",
	[20908]="billowing bow", [20909]="blustery bow", [20910]="great bow", [20911]="purblind bow", [20912]="blinding bow", [20913]="oh-no bow",
	[20914]="Odin's bow", [20915]="angel's bow", [20916]="archangel's bow", [20917]="aeon's bow", [20918]="seraph's bow", [21000]="warrior's shield",
	[21001]="shell shield", [21002]="kitty shield", [21003]="catty shield", [21004]="light shield", [21005]="platinum shield", [21006]="tempest shield",
	[21007]="saintess shield", [21008]="Goddess shield", [21009]="rusty shield", [21010]="brain drainer", [21011]="psyche swiper", [21012]="devilry drinker",
	[21013]="soul sucker", [21014]="slime shield", [21091]="bronze shield", [21092]="iron shield", [21093]="steel shield", [21095]="gigasteel shield",
	[21190]="metal slime shield", [21191]="Erdrick's shield", [21192]="scale shield", [21193]="liquid metal shield", [21194]="metal king shield", [21200]="white knight's shield",
	[21280]="enchanted shield", [21281]="ethereal shield", [21282]="empowered shield", [21290]="magic shield", [21291]="leather shield", [21292]="power shield",
	[21294]="silver shield", [21295]="white shield", [21296]="pot lid", [21297]="silver platter", [21298]="gold platter", [21299]="platinum platter",
	[21390]="flame shield", [21391]="dragon shield", [21392]="boss shield", [21393]="ruinous shield", [21394]="ogre shield", [21395]="ice shield",
	[21396]="dark shield", [21397]="big boss shield", [22000]="medicinal herb", [22001]="strong medicine", [22002]="special medicine", [22003]="superior medicine",
	[22004]="antidotal herb", [22005]="strong antidote", [22006]="special antidote", [22007]="moonwort bulb", [22008]="softwort", [22009]="lunaria",
	[22010]="angel bell", [22011]="panacea", [22012]="perfect panacea", [22013]="Yggdrasil leaf", [22014]="Yggdrasil dew", [22015]="magic water",
	[22016]="sage's elixir", [22017]="elfin elixir", [22018]="holy water", [22019]="chimaera wing", [22020]="mystifying mixture", [22021]="coagulant",
	[22022]="tangleweb", [22023]="sleeping hibiscus", [22024]="wakerobin", [22025]="party popper", [22026]="festive feast", [22027]="block o' choc",
	[22028]="choice chocolate", [22029]="basic biscuits", [22030]="posh biscuits", [22031]="Christmas cake", [22032]="birthday cake", [22033]="rockbomb shard",
	[22034]="watcher's wings", [22035]="sage's stone", [22036]="Gleeban groat", [22037]="Gleeban guinea", [22038]="Gleeban gold piece", [22039]="mini medal",
	[22041]="pretty betsy", [22045]="seed of life", [22046]="seed of magic", [22047]="seed of strength", [22048]="seed of deftness", [22049]="seed of agility",
	[22050]="seed of defence", [22051]="seed of sorcery", [22052]="seed of therapeusis", [22053]="seed of skill", [22070]="iron nails", [22071]="iron ore",
	[22072]="platinum ore", [22073]="mythril ore", [22074]="densinium", [22075]="gold bar", [22076]="orichalcum", [22077]="Hephaestus' flame",
	[22078]="cowpat", [22079]="horse manure", [22080]="saint's ashes", [22081]="enchanted stone", [22082]="ethereal stone", [22083]="wing of bat",
	[22084]="astral plume", [22085]="magic beast hide", [22086]="magic beast horn", [22087]="slimedrop", [22088]="butterfly wing", [22089]="kitty litter",
	[22090]="glass frit", [22091]="belle cap", [22092]="fisticup", [22093]="lava lump", [22094]="fresh water", [22095]="flurry feather",
	[22096]="royal soil", [22097]="ice crystal", [22098]="thunderball", [22099]="evencloth", [22100]="brighten rock", [22101]="tortoiseshell",
	[22102]="toad oil", [22103]="lambswool", [22104]="snakeskin", [22105]="manky mud", [22106]="corundum", [22107]="reset stone",
	[22108]="celestial skein", [22109]="sainted soma", [22110]="lucida shard", [22111]="agate of evolution", [22112]="resurrock", [22113]="mirrorstone",
	[22114]="sunstone", [22115]="flintstone", [22116]="malicite", [22117]="slipweed", [22118]="thinkincense", [22119]="narspicious",
	[22120]="seashell", [22121]="crimson coral", [22122]="emerald moss", [22123]="finessence", [22124]="aggressence", [22125]="MIMIC STONE",
	[22126]="BLARNEY STONE", [22141]="nectar", [22142]="birdsong nectar", [22143]="grubby bandage", [22144]="technicolour dreamcloth", [22256]="Sterling's whistle",
	[22257]="Evac-u-bell", [22258]="chronocrystal", [22259]="red orb", [22260]="blue orb", [22261]="yellow orb", [22262]="green orb",
	[22263]="purple orb", [22264]="silver orb", [22265]="\"Swordcraft in Summary\"", [22266]="\"Clear Spear Theory\"", [22267]="\"Knifing Know-How\"", [22268]="\"Wands and Beyond\"",
	[22269]="\"Working with Whips\"", [22270]="\"Staff Studies\"", [22271]="\"The Core of the Claw\"", [22272]="\"Further Fanmanship\"", [22273]="\"Advanced Axecraft\"", [22274]="\"Hardcore Hammering\"",
	[22275]="\"The Boomerang Bible\"", [22276]="\"Archery for the Adept\"", [22277]="\"Fearsome Fisticuffing\"", [22278]="\"Secrets of the Shield\"", [22279]="\"Warrior's Workbook\"", [22280]="\"Priest's Primer\"",
	[22281]="\"Mage's Manual\"", [22282]="\"Martial Artist's Manual\"", [22283]="\"Thief's Theory\"", [22284]="\"Minstrel's Manual\"", [22285]="\"Gladiator's Guide\"", [22286]="\"Paladin's Primer\"",
	[22287]="\"Armamentalist's Album\"", [22288]="\"Ranger's Revelations\"", [22289]="\"Sage's Scripture\"", [22290]="\"Luminary's Lore\"",
}
-- story event spots: map number -> { first chapter, step, last chapter, step, box x1, z1, x2, z2, event }
EVENT_SPOTS = {
	[200] = { {11,2,11,2,-7.19,-35.95,-23.97,-45.34,302} },
	[406] = { {1,1,19,99,5.06,-10.43,4.06,-11.43,314} },
	[1100] = { {1,3,1,4,3.57,0.44,0.78,-4.05,17} },
	[1300] = { {1,1,4,4,6.69,31.86,-0.90,29.06,22}, {4,5,4,6,6.69,31.86,-0.90,29.06,22} },
	[1500] = { {7,1,7,1,12.37,18.58,9.58,17.38,342} },
	[1900] = { {19,1,19,99,10.77,12.84,7.78,9.54,45} },
	[5101] = { {2,2,2,2,-0.31,18.86,-13.89,10.27,337}, {2,2,2,2,-7.16,2.40,-13.75,-1.50,325}, {2,2,2,2,-10.43,33.07,-17.23,29.07,342}, {2,7,2,7,-3.14,11.08,-20.22,6.69,239}, {4,7,4,99,-3.56,14.12,-9.35,9.53,331} },
	[5700] = { {14,4,14,4,-12.87,-8.00,-20.76,-9.30,314}, {14,4,14,4,-14.37,9.80,-20.67,8.30,45}, {14,4,14,4,12.16,-11.41,11.06,-16.11,45}, {14,4,14,4,-11.15,-11.57,-12.25,-15.97,314}, {14,4,14,4,13.49,-12.23,11.90,-17.42,45}, {14,4,14,4,-10.01,-13.89,-15.31,-15.49,45}, {14,6,14,6,12.99,-13.24,10.19,-14.24,314}, {14,6,14,6,-11.35,-11.62,-12.35,-16.22,314}, {14,6,14,6,13.85,-13.80,10.56,-14.80,314}, {14,6,14,6,-10.69,-14.03,-14.08,-15.03,222} },
	[5701] = { {14,4,14,5,-15.17,10.97,-16.37,9.37,314} },
	[5702] = { {14,6,14,6,-3.28,2.72,-4.28,1.42,28}, {14,6,14,6,3.47,1.74,2.17,0.74,331} },
	[7901] = { {9,3,9,3,25.25,-1.21,19.66,-3.71,359} },
	[8303] = { {12,5,12,5,3.42,7.35,0.13,6.35,80} },
	[9108] = { {19,2,19,99,6.04,3.89,-1.45,2.29,51} },
}

map_code_frame, map_code_val = -1, ""
local function map_code()
	if map_code_frame ~= frame then map_code_frame, map_code_val = frame, cstring(MAPCODE, 12) end
	local c = map_code_val
	if c:match("^%u%d%dM%d%d") then return c end
	return nil
end
local function map_name()
	local n = cstring(MAPNAME, 40)
	if printable(n) then return clean(n) end
	return nil
end

local function player_pos()
	local p = u32(PLAYER_PTR)
	if not inram(p, 0x60) then return nil end
	return s32(p + 0x44) / 4096, s32(p + 0x48) / 4096, s32(p + 0x4C) / 4096
end

-- Unit vectors for "up" and "right" on screen, in world x/z.
local function screen_axes()
	local px, _, pz = player_pos()
	if not px then return 0, -1, 1, 0 end
	local cx, cz = s32(CAMERA) / 4096, s32(CAMERA + 8) / 4096
	local ux, uz = px - cx, pz - cz
	local len = math.sqrt(ux * ux + uz * uz)
	if len < 0.01 then return 0, -1, 1, 0 end
	ux, uz = ux / len, uz / len
	return ux, uz, -uz, ux
end

local function steps(n, word)
	n = math.floor(math.abs(n) + 0.5)
	if n == 0 then return nil end
	return n .. (n == 1 and " step " or " steps ") .. word
end

local function directions_to(tx, tz)
	local px, _, pz = player_pos()
	if not px then return "unknown" end
	local ux, uz, rx, rz = screen_axes()
	local dx, dz = tx - px, tz - pz
	local fwd, right = dx * ux + dz * uz, dx * rx + dz * rz
	if math.sqrt(dx * dx + dz * dz) < 1.2 then return "right next to you" end
	local a = steps(fwd, fwd >= 0 and "up" or "down")
	local b = steps(right, right >= 0 and "right" or "left")
	if a and b then
		if math.abs(fwd) >= math.abs(right) then return a .. ", " .. b else return b .. ", " .. a end
	end
	return a or b or "right next to you"
end

-- Doors and exits: the game keeps a list of the current map's warp boxes. Each is 0x70 bytes:
-- +0 kind (0 = exit to the surrounding area, 1 = door into a building), +4 max x/y/z,
-- +0x10 min x/y/z, +0x1C id of the map it leads to. Pointer at 0x020FB474, count at 0x020FB478.
WARP_PTR, WARP_COUNT = 0x020FB474, 0x020FB478
local learned = {}          -- names of places reached through exits, learned as you travel
local people = {}           -- who people are, learned when you talk to them
local searched_load = {}
local events_done_load = {}
local function learn_name(id, name)
	if learned[id] == name then return end
	learned[id] = name
	local f = io.open(PLACES_FILE, "a")
	if f then f:write(string.format("%d|name|0|0|%s\n", id, name)) f:close() end
end
-- places the game gives no useful name to
EXIT_NAMES = { [4107] = "stairs up to the Great Hall",       -- Observatory level 2, where Apus Major is
               [4109] = "archway into the Observatory" }       -- the round hall inside level 3
local function door_name(id, kind)
	local m = MAPIDS[id]
	local name = (m and m[2]) or learned[id]
	-- the open field between towns shares its name with the town (Angel Falls): say what it is
	if kind == 0 and id >= 20000 and id < 30000 and not (m and m[2]) then name = "the open field" end
	if not name and m and kind == 0 then name = AREAS[m[1]:sub(1, 3)] end
	if not name and kind == 0 and id >= 20000 and id < 30000 then name = "the open field" end
	if kind == 0 and EXIT_NAMES[id] then return EXIT_NAMES[id] end
	if kind == 0 then
		local here = map_code()
		if name and m and here and m[1]:sub(1, 3) == here:sub(1, 3) and name:match("^Lv %d") then return "passage" end
		return name and ("exit to " .. name) or "exit"
	end
	if m and m[1]:match("^R0") then name = "Quester's Rest" end        -- the inn's own maps
	if name and (name == "Interior" or name:match("^Interior Lv")) and m[1]:match("^C") then name = "castle" end
	-- another part of the building you are in: the game's own part names ("Lv 1-2") mean nothing
	local here = map_code()
	if name and m and here and m[1]:sub(1, 3) == here:sub(1, 3) then
		if name:match("^Lv %d") or name:match("^Interior %- Lv") then name = nil
		elseif name:match("^Exterior") then return "door outside" end
	end
	return name and (name .. " door") or "door"
end
function door_gimmick_near(x, z, id)
	local base, n = u32(0x020FB480), u32(0x020FB484)
	if n == 0 or n > 200 or not inram(base, n * 0x74) then return id == nil end
	for k = 0, n - 1 do
		local g = base + k * 0x74
		if u32(g + 4) == 2 and math.abs(s32(g + 8) / 4096 - x) < 2 and math.abs(s32(g + 0x10) / 4096 - z) < 2 then
			-- (asked with a map: only a door that leads there)
			-- (also says where the door itself stands)
			if id == nil or u16(g + 0x30) == id then return true, s32(g + 8) / 4096, s32(g + 0x10) / 4096 end
		end
	end
	return false
end
doors_cache = { frame = -1000, id = -1, list = nil, town = nil, town_frame = -1000 }
local function doors()
	-- the doors of a map do not move: look them up again only now and then
	local id = u16(MAPID)
	if doors_cache.list and doors_cache.id == id and frame - doors_cache.frame < 60 then return doors_cache.list end
	local list = doors_raw()
	if stairs_mark then pcall(stairs_mark, list) end
	doors_cache.list, doors_cache.id, doors_cache.frame = list, id, frame
	return list
end
function doors_raw()
	local list = {}
	local base, n = u32(WARP_PTR), u32(WARP_COUNT)
	if n > 64 or not inram(base, n * 0x70) then return list end
	for k = 0, n - 1 do
		local S = base + k * 0x70
		local kind = u32(S)
		local x1, z1 = s32(S + 4) / 4096, s32(S + 12) / 4096
		local x0, z0 = s32(S + 16) / 4096, s32(S + 24) / 4096
		if kind <= 1 and x1 >= x0 and z1 >= z0 then
			-- an exit with a real door in front of it that leads to the same place is a door
			-- (otherwise it would be listed twice, once in each list)
			if kind == 0 and door_gimmick_near((x0 + x1) / 2, (z0 + z1) / 2, u16(S + 0x1C)) then kind = 1 end
			-- the thin side of the box is the way through it
			local nx, nz = 0, 1
			if (x1 - x0) < (z1 - z0) then nx, nz = 1, 0 end
			local label = door_name(u16(S + 0x1C), kind)
			local cx, cz = (x0 + x1) / 2, (z0 + z1) / 2
			local has, gx, gz = door_gimmick_near(cx, cz)
			if label == "door" and not has then
				label = "entrance"      -- a way in with no door, such as a well or a trapdoor
			end
			local e = { label = label, x = cx, z = cz, kind = kind, id = u16(S + 0x1C), nx = nx, nz = nz,
			            x0 = x0, x1 = x1, z0 = z0, z1 = z1, y0 = s32(S + 0x14) / 4096, y1 = s32(S + 8) / 4096 }
			-- an exit that is about as wide as it is deep (the top of a stairway) has no front:
			-- walk straight into it
			if kind == 0 then
				local w, dd = x1 - x0, z1 - z0
				if math.max(w, dd) < 1.5 * math.min(w, dd) then e.nx, e.nz = nil, nil end
			end
			-- a door standing in front of the exit box: the door is where you walk to, and the way
			-- in is from the door's side, through it, into the box
			if kind == 1 and gx then
				local ddx, ddz = gx - cx, gz - cz
				local dl = math.sqrt(ddx * ddx + ddz * ddz)
				if dl > 0.3 and dl < 2.5 then
					e.x, e.z, e.nx, e.nz, e.facing = gx, gz, ddx / dl, ddz / dl, true
					e.wx, e.wz = cx, cz
				end
			end
			list[#list + 1] = e
		end
	end
	return list
end

-- Your own marks, saved per map in dq9-access-places.txt, one per line:  mapcode|mark|x|z|label
local places = {}
local function load_places()
	local f = io.open(PLACES_FILE, "r")
	if not f then return end
	for line in f:lines() do
		local code, kind, x, z, label = line:match("^([^|]+)|([^|]+)|([^|]+)|([^|]+)|(.*)$")
		if code and kind == "name" and tonumber(code) then learned[tonumber(code)] = label end
		if code and kind == "npc" then people[code] = label end
		if code and kind == "searched" then searched_load[code] = true end
		if code and kind == "eventdone" then events_done_load[code] = true end
		if code and kind == "mark" and tonumber(x) and tonumber(z) then
			places[#places + 1] = { code = code, kind = kind, x = tonumber(x), z = tonumber(z), label = label }
		end
	end
	f:close()
end
local function add_place(code, kind, x, z, label)
	places[#places + 1] = { code = code, kind = kind, x = x, z = z, label = label }
	local f = io.open(PLACES_FILE, "a")
	if f then
		f:write(string.format("%s|%s|%.2f|%.2f|%s\n", code, kind, x, z, label))
		f:close()
	end
end

local function map_key(code) return code and code:sub(1, 6) or "" end
local function place_key() return map_key(map_code()) .. "#" .. u16(MAPID) end

-- The screen fades through the DS master brightness register; while it is fading the player is
-- walking through a door, not into a wall. If this BizHawk build cannot read hardware registers
-- the check simply says "not fading".
local brightness_ok = true
local function fading()
	if not brightness_ok then return false end
	local ok, v = pcall(function() return memory.read_u16_le(0x0400006C, "ARM9 System Bus") end)
	if not ok or type(v) ~= "number" then brightness_ok = false return false end
	return v ~= 0
end

local cur_code, code_changed_frame = nil, -1000
local settled = nil       -- the map we last announced: { code, label }
local pending = nil       -- a map change that is still loading
local near_door = nil     -- the door the player was last standing close to

-- "Angel Falls, Inn": the town name, then the building from the game's own map list
local function room_name()
	local m = MAPIDS[u16(MAPID)]
	if m and m[1]:match("^R0") and m[2] then
		-- the Quester's Rest: "Lobby Interior 1" is the lobby
		return "Quester's Rest " .. (m[2]:gsub(" Interior %d+$", ""):gsub(" Interior$", ""))
	end
	if m and #m[1] > 3 and m[2] and not m[2]:match("^M%d") then return m[2] end
	return nil
end
local function track_map()
	local code = map_code()
	if not code then return end
	code = code .. "#" .. u16(MAPID)
	local x, _, z = player_pos()
	if not x then return end
	if code ~= cur_code then
		cur_code, code_changed_frame = code, frame
		if not settled or map_key(code) .. (code:match("#%d+$") or "") ~= map_key(settled.code) .. (settled.code:match("#%d+$") or "") then
			pending = { sx = x, sz = z, door = near_door }
		end
	end
	if pending then
		-- The player is moved to the new map a little after the map code changes; wait for the jump.
		local jumped = math.abs(x - pending.sx) > 1 or math.abs(z - pending.sz) > 1
		local waited = frame - code_changed_frame
		if ((jumped or not settled) and not fading() and waited > 30 and map_name()) or waited > 150 then
			local label = map_name() or "somewhere new"
			-- going in through a door: say which building, if the game's map list names it
			local d = pending.door
			local room = room_name()
			if room and map_name() then
				label = map_name() .. ", " .. room
			elseif d and d.kind == 1 then
				label = label .. ", " .. (d.label ~= "door" and d.label:gsub(" door$", "") or "inside")
			elseif d and d.kind == 0 and map_name() and (d.label == "exit" or d.label == "exit to the open field") then
				learn_name(d.id, map_name())       -- the exit had no name: now we know where it goes
			end
			if not settled or label ~= settled.label then queue(label) end
			settled = { code = code, label = label }
			pending, near_door = nil, nil
		end
	elseif frame % 5 == 0 then
		near_door = nil
		for _, d in ipairs(doors()) do
			if math.abs(d.x - x) < 3 and math.abs(d.z - z) < 3 then near_door = d end
		end
		if not near_door and town_doors then
			for _, d in ipairs(town_doors()) do
				if math.abs(d.x - x) < 3 and math.abs(d.z - z) < 3 then near_door = d end
			end
		end
	end
end

------------------------------------------------------------------------------ nearby --------
local selected = 0
local nearby = {}

-- A person is known by the map and the spot the game placed them at, so the name you learn by
-- talking to them sticks even when they wander about.
local function npc_key(o)
	local r = u32(o + 0x0C)
	if not inram(r, 0x20) then return nil end
	if not map_code() then return nil end
	return place_key() .. ":" .. math.floor(s32(r + 0x10) / 4096 + 0.5) .. ":" .. math.floor(s32(r + 0x18) / 4096 + 0.5)
end

-- What the townspeople look like, from the game's own character pictures (data/ani/n001a.spr ...).
-- The letter after the number is a colour variant; "g" is the ghostly version.
NPC_LOOKS = {
	n001 = "man in a straw hat", n002 = "young woman in a dress", n003 = "stout man with a beard",
	n004 = "old woman in a headscarf and apron", n005 = "old man with a walking stick",
	n006 = "old woman with glasses", n007 = "big man in a horned helmet", n008 = "stout man in a cap",
	n009 = "man in a red coat", n010 = "minstrel with a lute", n011 = "man in a bandana",
	n012 = "old man with a white beard and a red cap", n013 = "woman in an apron", n014 = "boy",
	n015 = "little girl with a bow", n016 = "priest", n017 = "nun", n018 = "bearded man in a wide straw hat",
	n019 = "sailor in a striped shirt", n020 = "blonde woman in green", n021 = "dancer",
	n022 = "lady in a pink gown", n023 = "old man in black with a red bow tie", n024 = "cook",
	n025 = "king", n026 = "nobleman in a green robe", n027 = "lady in a blue gown", n028 = "soldier",
	n029 = "royal guard", n030 = "maid", n031 = "woman warrior with a spear",
	n032 = "woman in red with a shield", n033 = "martial artist in green", n034 = "hooded man",
	n035 = "woman in a purple cloak", n036 = "bald man with a beard", n037 = "stout man in a green coat",
	n039 = "angel, young man", n040 = "angel, woman with teal hair", n041 = "angel, bearded man",
	n042 = "angel, elder in a robe", n043 = "angel with a ponytail", n044 = "angel in purple",
	n045 = "angel in purple", n046 = "angel, blonde woman", n047 = "angel, child",
	n048 = "angel, woman with blue hair", n049 = "skeleton in a coat", n050 = "knight in dark armour",
	n051 = "warrior in red armour", n052 = "man in an orange robe", n053 = "woman in an orange dress",
	n054 = "stout man in green", n055 = "bald man in a yellow robe", n056 = "man in a blue robe",
	n057 = "woman with a red headband", n058 = "old man in a grey hat", n059 = "old woman in green",
	n060 = "boy in a teal cap", n061 = "girl in yellow", n062 = "man in a striped robe",
	n063 = "man with a red headband", n064 = "woman in white with a red headband",
	n065 = "old warrior with a grey beard", n066 = "old man in a red waistcoat",
	n067 = "woman in a long orange dress", n068 = "sailor in a blue waistcoat",
	n069 = "woman in a yellow dress", n070 = "old man with a long white beard",
	n071 = "blonde woman in white", n072 = "girl in a tribal outfit", n073 = "woman with pink pigtails",
	n074 = "boy with white hair", n075 = "girl in an orange dress", n076 = "old man in a purple robe",
	n077 = "man in a purple coat", n078 = "woman in a purple dress", n079 = "stout man in a red coat",
	n080 = "student in a red jacket", n081 = "student with spiky hair",
	n082 = "student, girl with blonde pigtails", n083 = "student, girl with a headband",
	n084 = "student with glasses", n085 = "student, girl with teal hair",
	n088 = "stout man in a brown coat", n089 = "man in a brown robe",
	n092 = "bald old man with a white beard", n095 = "shirtless man", n096 = "cat", n097 = "dog",
	n098 = "cow", n099 = "horse", n100 = "little floating spirit", n101 = "girl in a swimsuit",
	n102 = "skeleton", n103 = "skeleton", n104 = "sheep", n106 = "stone statue",
	n107 = "stone statue of a woman", n108 = "stone statue of a stout man",
	n109 = "stone statue of an old man", n110 = "stone statue of a man",
	n111 = "stone statue of a woman", n112 = "stone statue of a child",
	n113 = "stone statue of a man in a hat", n114 = "stone statue of a cat",
	n300 = "woman in a blue dress and apron", n301 = "woman in a yellow dress and apron",
	n302 = "woman with blue hair in a red dress", n303 = "winged woman with white hair",
	n304 = "fish", n305 = "alchemy pot", n306 = "woman in a green robe",
	n900 = "stout man in purple and gold", n901 = "bishop", n902 = "soldier in green",
	n903 = "young man in green", n904 = "young woman in a pink dress",
	n905 = "nobleman in a green robe", n906 = "king", n907 = "old woman in a headscarf and apron",
	n908 = "big man in a horned helmet", n909 = "nun", n910 = "boy",
	n911 = "bearded man in a wide straw hat", n912 = "stout man in blue",
	n913 = "old man with a walking stick", n916 = "blonde woman in green", n919 = "cat",
	n925 = "woman with blue hair in a red dress",
}
function npc_look(model)
	local desc = NPC_LOOKS[model:sub(1, 4)]
	if not desc then return nil end
	if model:sub(5, 5) == "g" then desc = "ghostly " .. desc end
	return desc
end

-- story models that are things, not characters
STORY_THINGS = { s097 = "shiny object" }
local function characters()
	local list = {}
	local n = u32(OBJ_COUNT)
	if n > 64 then return list end
	local px, _, pz = player_pos()
	for i = 0, n - 1 do
		local o = u32(OBJ_TABLE + 4 * i)
		if inram(o, 0x70) then
			local m = u32(o + 0x08)
			local model = inram(m, 12) and cstring(m + 4, 8) or ""
			-- story characters (models s001, s025 ...) are built differently: their position
			-- is further into the object
			local story = model:match("^s%d%d%d") ~= nil
			local x, z
			if story then x, z = s32(o + 0x64) / 4096, s32(o + 0x6C) / 4096
			else x, z = s32(o + 0x24) / 4096, s32(o + 0x2C) / 4096 end
			local far = math.abs(x) > 1000 or math.abs(z) > 1000       -- parked off the map
			if not far and not (px and math.abs(x - px) < 0.05 and math.abs(z - pz) < 0.05) then
				-- people are drawn from a character sprite (n001a ...); signs, statues and the
				-- like have none
				local person = model:match("^%l%d%d%d") ~= nil
				local key = npc_key(o)
				local label = key and people[key]
				local look = person and not story and npc_look(model)
				if not person and label then
					if label:find("reads the sign", 1, true) then label = "sign"
					else label = label:gsub("^someone who says", "something that says") end
				end
				-- only names are kept for people; what they said is not part of the label
				if person and label and label:find("^someone who says") then label = nil end
				if story and label then label = label .. ", story character" end
				label = label or look
				-- some story models are things to pick up, not people (the lost ring in the grass)
				local sthing = story and STORY_THINGS[model:sub(1, 4)]
				if sthing then
					list[#list + 1] = { label = sthing, x = x, z = z, obj = o, key = key, thing = true, item = true, posoff = 0x64 }
				else
				list[#list + 1] = { label = label or (story and "story character" or person and "someone" or "something"),
				                    x = x, z = z, obj = o, key = key, thing = not person, story = story, posoff = story and 0x64 or nil }
				end
			end
		end
	end
	return list
end

-- Things you can search (cupboards, pots, barrels, chests ...): the map's list of "gimmicks".
-- Each is a small box with a kind number; doors are kind 2 and are already in the door list.
GIMMICK_PTR, GIMMICK_COUNT = 0x020FB480, 0x020FB484
local searched = searched_load  -- things you have already opened or looked in, kept in the places file
GIMMICK_NAMES = { [0] = "pot or barrel", [1] = "treasure chest", [5] = "cupboard", [6] = "barrel", [8] = "bookshelf", [9] = "something to search" }
local function map_items()
	local list = {}
	local base, n = u32(GIMMICK_PTR), u32(GIMMICK_COUNT)
	if n == 0 or n > 200 or not inram(base, n * 0x74) then return list end
	for k = 0, n - 1 do
		local g = base + k * 0x74
		local kind = u32(g + 4)
		local sx, sz = s32(g + 0x14) / 4096, s32(g + 0x1C) / 4096
		if kind ~= 2 and kind < 64 and math.abs(sx) <= 3 and math.abs(sz) <= 3 then
			local x, z = s32(g + 8) / 4096, s32(g + 0x10) / 4096
			local key = place_key() .. ":" .. math.floor(x + 0.5) .. ":" .. math.floor(z + 0.5)
			local label = GIMMICK_NAMES[kind] or "something to search"
			if searched[key] then label = label .. (kind == 1 and ", opened" or ", searched") end
			list[#list + 1] = { label = label, x = x, z = z, item = true, gkind = kind, key = key }
		end
	end
	return list
end

-- Pressing A right next to a pot, barrel, chest ... (and nearer to it than to anyone) searches it:
-- remember that, so the list can say "searched" or "opened".
local function mark_searched()
	local px, _, pz = player_pos()
	if not px then return end
	local nearest_person = 99
	for _, c in ipairs(characters()) do
		local d = math.sqrt((c.x - px) ^ 2 + (c.z - pz) ^ 2)
		if d < nearest_person then nearest_person = d end
	end
	local best, bd = nil, 1.4
	for _, it in ipairs(map_items()) do
		local d = math.sqrt((it.x - px) ^ 2 + (it.z - pz) ^ 2)
		if d < bd then best, bd = it, d end
	end
	if best and bd < nearest_person and not searched[best.key] then
		searched[best.key] = true
		-- pots, barrels and shelves fill up again after a while; only opened chests are kept
		if best.gkind ~= 1 then return end
		local f = io.open(PLACES_FILE, "a")
		if f then f:write(best.key .. "|searched|0|0|" .. (GIMMICK_NAMES[best.gkind] or "") .. "\n") f:close() end
	end
end

-- Sparkly spots in the open fields: the game keeps a chain of the spots that are showing right
-- now. The field's list of spots says which item each one gives.
SPARKLE_GROUPS, SPARKLE_GROUP_COUNT, SPARKLE_HEAD = 0x02108FE8, 0x02108FEC, 0x0210902C
local function sparkle_item(x, z)
	local g0, n = u32(SPARKLE_GROUPS), u16(SPARKLE_GROUP_COUNT)
	if n == 0 or n > 40 or not inram(g0, n * 0x70) then return nil end
	for k = 0, n - 1 do
		local g = g0 + k * 0x70
		for j = 0, 7 do
			local a = g + 0x0C + j * 12
			if math.abs(s32(a) / 4096 - x) < 0.3 and math.abs(s32(a + 8) / 4096 - z) < 0.3 then
				local nm = ITEM_NAMES[u16(g)]
				return nm
			end
		end
	end
	return nil
end
-- Doors inside a town that open onto the same map (Stornway's houses, for example) are not warps,
-- only "gimmicks" of kind 2. List the ones that are not already a warp door.
function town_doors()
	local id = u16(MAPID)
	if doors_cache.town and doors_cache.town_id == id and frame - doors_cache.town_frame < 60 then return doors_cache.town end
	local list = town_doors_raw()
	doors_cache.town, doors_cache.town_id, doors_cache.town_frame = list, id, frame
	return list
end
function town_doors_raw()
	local list = {}
	local base, n = u32(GIMMICK_PTR), u32(GIMMICK_COUNT)
	if n == 0 or n > 200 or not inram(base, n * 0x74) then return list end
	local ws = doors()
	for k = 0, n - 1 do
		local g = base + k * 0x74
		if u32(g + 4) == 2 then
			local x, z = s32(g + 8) / 4096, s32(g + 0x10) / 4096
			local dup = false
			for _, d in ipairs(ws) do if d.kind == 1 and math.abs(d.x - x) < 2 and math.abs(d.z - z) < 2 then dup = true end end
			for _, d in ipairs(list) do if math.abs(d.x - x) < 1 and math.abs(d.z - z) < 1 then dup = true end end
			-- the map the door leads to (a shop, a house ...) is kept at +0x30
			local id = u16(g + 0x30)
			local label = (MAPIDS[id] or learned[id]) and door_name(id, 1) or "door"
			if not dup then list[#list + 1] = { label = label, x = x, z = z, kind = 1, gdoor = true, id = id } end
		end
	end
	return list
end

local function sparkles()
	local list = {}
	local node, guard = u32(SPARKLE_HEAD), 0
	while inram(node, 0x18) and guard < 40 do
		local x, z = s32(node + 4) / 4096, s32(node + 0x0C) / 4096
		if math.abs(x) < 1000 and math.abs(z) < 1000 then
			local what = sparkle_item(x, z)
			list[#list + 1] = { label = "sparkly spot" .. (what and (", " .. what) or ""), x = x, z = z, sparkle = true }
		end
		node, guard = u32(node + 0x14), guard + 1
	end
	return list
end

-- Story event spots: boxes on the map that start a story scene when you walk in, taken from the
-- game's trigger files. Each is only live for part of the story (chapter and step), which the
-- game keeps in two bytes. Once you have walked into one it is marked as done.
STORY_PROGRESS = 0x02108844
local events_done = events_done_load
local function event_spots()
	local list = {}
	local spots = EVENT_SPOTS[u16(MAPID)]
	if not spots then return list end
	local now = u8(STORY_PROGRESS) * 100 + u8(STORY_PROGRESS + 1)
	for _, e in ipairs(spots) do
		if now >= e[1] * 100 + e[2] and now <= e[3] * 100 + e[4] then
			local key = u16(MAPID) .. ":" .. e[9] .. ":" .. math.floor(e[5]) .. ":" .. math.floor(e[6])
			local x0, x1 = math.min(e[5], e[7]), math.max(e[5], e[7])
			local z0, z1 = math.min(e[6], e[8]), math.max(e[6], e[8])
			list[#list + 1] = { label = "story event" .. (events_done[key] and ", already seen" or ""),
			                    x = (x0 + x1) / 2, z = (z0 + z1) / 2, event = true, key = key,
			                    x0 = x0, x1 = x1, z0 = z0, z1 = z1 }
		end
	end
	return list
end
local function watch_events()
	local px, _, pz = player_pos()
	if not px then return end
	for _, e in ipairs(event_spots()) do
		if not events_done[e.key] and px >= e.x0 - 0.5 and px <= e.x1 + 0.5 and pz >= e.z0 - 0.5 and pz <= e.z1 + 0.5 then
			events_done[e.key] = true
			local f = io.open(PLACES_FILE, "a")
			if f then f:write(e.key .. "|eventdone|0|0|story event\n") f:close() end
		end
	end
end

-- Monsters walking about in the open: the game keeps twelve slots for them. Each points at an
-- entry of this area's monster list, which starts with the monster's name.
MONSTER_SLOTS = 0x020F35A0
local function monsters()
	local list = {}
	local px, _, pz = player_pos()
	for k = 0, 11 do
		local o = u32(MONSTER_SLOTS + 4 * k)
		if inram(o, 0x198) and u16(o + 2) ~= 0xFFFF and u16(o + 6) ~= 0xFFFF then
			local x, z = s32(o + 0x44) / 4096, s32(o + 0x4C) / 4096
			local e = u32(o + 0x180)
			local name = inram(e, 4) and clean(cstring(u32(e), 40)) or ""
			if name == "" or not printable(name) then name = "monster" end
			if math.abs(x) < 1000 and math.abs(z) < 1000 and not (px and math.abs(x - px) < 0.05 and math.abs(z - pz) < 0.05) then
				list[#list + 1] = { label = name, x = x, z = z, obj = o, posoff = 0x44, monster = true }
			end
		end
	end
	return list
end

-- Who did you just talk to? The nearest person. Their name if the message gives one, otherwise
-- the start of what they said, for example: someone who says "Welcome to the inn".
on_new_message = function(text, full)
	full = full or text
	local px, _, pz = player_pos()
	if not px then return end
	local best, bd = nil, 2.6
	for _, c in ipairs(characters()) do
		local d = math.sqrt((c.x - px) ^ 2 + (c.z - pz) ^ 2)
		if c.key and d < bd then best, bd = c, d end
	end
	local known = best and people[best.key]
	-- a sign read from the wrong side is learned again once it has been read properly
	if not best or (known and not (best.thing and (known == "sign" or known == "inscription" or known:find("something that says", 1, true) or known:find("reads the sign", 1, true)))) then return end
	local name = text:match("^([%u][%w%.' %-]-): ")
	local label
	if best.thing then
		if full:find("reads the sign", 1, true) then
			-- a sign: remember what it says (the words are on the next page)
			local said = full:match("reads the sign%.?%s*(.*)$") or ""
			said = said:gsub("^[%(%s'\"]+", ""):gsub("[%)%s'\"]+$", "")
			label = (said ~= "" and not said:find("wrong side", 1, true)) and ("sign: " .. said) or "sign"
		elseif full:lower():find("inscription", 1, true) then
			local said = full:match("inscription[^%.]*%.%s*(.*)$") or ""
			said = said:gsub("^[%(%s'\"]+", ""):gsub("[%)%s'\"]+$", "")
			label = said ~= "" and ("inscription: " .. said) or "inscription"
		elseif full:match("examines the ([%a%s%-]+)") then
			label = full:match("examines the ([%a%s%-]+)"):gsub("%s+$", "")
		end
		name = nil
	end
	if label then
		-- already worked out above
	elseif name and #name <= 24 then
		label = name
	else
		local words, out = 0, {}
		for w in text:gmatch("%S+") do
			words = words + 1
			out[#out + 1] = w
			if words >= 8 or w:match("[%.!%?]$") or (words >= 4 and w:match(",$")) then break end
		end
		local snippet = table.concat(out, " "):gsub("[%.,!%?]+$", "")
		if snippet == "" then return end
		label = (best.thing and 'something that says "' or 'someone who says "') .. snippet .. '"'
	end
	people[best.key] = label
	local f = io.open(PLACES_FILE, "a")
	if f then f:write(best.key .. "|npc|0|0|" .. label .. "\n") f:close() end
end

-- Many doors with no name of their own (the rooms around the Observatory's hall): call each
-- one after the side of the place it is on, "left door, upper", "top door, middle" and so on.
function name_doors_by_side(ds)
	local plain = {}
	for _, d in ipairs(ds) do
		d.base_label = d.base_label or d.label
		if d.kind == 1 and d.base_label == "door" then plain[#plain + 1] = d else d.label = d.base_label end
	end
	if #plain < 3 then for _, d in ipairs(plain) do d.label = d.base_label end return end
	local x0, x1, z0, z1 = math.huge, -math.huge, math.huge, -math.huge
	for _, d in ipairs(plain) do
		x0, x1 = math.min(x0, d.x), math.max(x1, d.x)
		z0, z1 = math.min(z0, d.z), math.max(z1, d.z)
	end
	local cx, cz = (x0 + x1) / 2, (z0 + z1) / 2
	local sides = { top = {}, bottom = {}, left = {}, right = {} }
	for _, d in ipairs(plain) do
		local dx, dz = d.x - cx, d.z - cz
		local side
		if math.abs(dx) > math.abs(dz) then side = dx < 0 and "left" or "right" else side = dz < 0 and "top" or "bottom" end
		table.insert(sides[side], d)
	end
	for side, list in pairs(sides) do
		local across = (side == "top" or side == "bottom")
		table.sort(list, function(a, b) if across then return a.x < b.x else return a.z < b.z end end)
		local words = across and { "left", "middle", "right" } or { "upper", "middle", "lower" }
		for i, d in ipairs(list) do
			local where = ""
			if #list == 2 then where = ", " .. (i == 1 and words[1] or words[3])
			elseif #list == 3 then where = ", " .. words[i]
			elseif #list > 3 then where = ", " .. i .. " of " .. #list .. (across and " from the left" or " from the top") end
			d.label = side .. " door" .. where
		end
	end
end

local function build_nearby()
	local px, _, pz = player_pos()
	if not px then return {} end
	local list = characters()
	for _, m in ipairs(monsters()) do list[#list + 1] = m end
	for _, m in ipairs(map_items()) do list[#list + 1] = m end
	for _, m in ipairs(sparkles()) do list[#list + 1] = m end
	for _, m in ipairs(event_spots()) do list[#list + 1] = m end
	local ds = {}
	for _, d in ipairs(doors()) do ds[#ds + 1] = d end
	for _, d in ipairs(town_doors()) do ds[#ds + 1] = d end
	name_doors_by_side(ds)
	-- many exits into the same place (the archways all round a tower): list only the nearest
	local same = {}
	for _, d in ipairs(ds) do
		if d.kind == 0 then same[d.id] = (same[d.id] or 0) + 1 end
	end
	local nearest = {}
	for _, d in ipairs(ds) do
		if d.kind == 0 and same[d.id] >= 3 then
			local dd = (d.x - px) ^ 2 + (d.z - pz) ^ 2
			if not nearest[d.id] or dd < nearest[d.id][2] then nearest[d.id] = { d, dd } end
		end
	end
	for _, d in ipairs(ds) do
		d.exit_label = d.exit_label or d.label
		if d.kind == 0 and same[d.id] >= 3 then
			if nearest[d.id][1] == d then
				d.label = d.exit_label .. ", nearest of " .. same[d.id]
				list[#list + 1] = d
			end
		else
			list[#list + 1] = d
		end
	end
	local key = place_key()
	for _, p in ipairs(places) do
		if p.code == key and p.kind == "mark" then list[#list + 1] = { label = p.label, x = p.x, z = p.z } end
	end
	for _, it in ipairs(list) do it.d = math.sqrt((it.x - px) ^ 2 + (it.z - pz) ^ 2) end
	table.sort(list, function(a, b) return a.d < b.d end)
	return list
end

local sel_item = nil
local function announce_selected()
	local it = nearby[selected]
	if not it then say("Nothing nearby.") return end
	sel_item = it
	it.code = map_code()
	say(it.label .. ", " .. directions_to(it.x, it.z) .. ". " .. selected .. " of " .. #nearby)
end

-- Categories for the nearby list: N and B (or the controller) only go through the chosen one.
CATEGORIES = { "People", "Monsters", "Items", "Sparkly spots", "Events", "Doors", "Exits", "Objects", "Marks" }
-- these are always offered, even when there are none here, so you know they exist
ALWAYS_SHOWN = { ["Sparkly spots"] = true, ["Events"] = true }
local category = 1
local function category_of(it)
	if it.monster then return "Monsters" end
	if it.sparkle then return "Sparkly spots" end
	if it.item then return "Items" end
	if it.event then return "Events" end
	if it.obj then return it.thing and "Objects" or "People" end
	if it.kind == 1 then return "Doors" end
	if it.kind == 0 then return "Exits" end
	return "Marks"
end
local function nearby_in_category(cat)
	local all = build_nearby()
	local out = {}
	for _, it in ipairs(all) do
		if category_of(it) == CATEGORIES[cat] then out[#out + 1] = it end
	end
	return out
end

local function step_nearby(delta)
	nearby = nearby_in_category(category)
	if #nearby == 0 then
		selected = 0 sel_item = nil
		say("No " .. CATEGORIES[category]:lower() .. " nearby.")
		return
	end
	-- keep your place in the list even though it is re-sorted by distance every time
	local at = 0
	if sel_item then
		-- the same thing again: same name, and the closest to where it was (people move a little)
		local bestd = 2.5
		for i, it in ipairs(nearby) do
			local d = math.abs(it.x - sel_item.x) + math.abs(it.z - sel_item.z)
			if it.label == sel_item.label and d < bestd then at, bestd = i, d end
		end
	end
	selected = at + delta
	if selected < 1 then selected = #nearby elseif selected > #nearby then selected = 1 end
	announce_selected()
end

-- Next or previous category, skipping the ones with nothing in them right now.
local function step_category(delta)
	for _ = 1, #CATEGORIES do
		category = (category - 1 + delta) % #CATEGORIES + 1
		local n = #nearby_in_category(category)
		if n > 0 or ALWAYS_SHOWN[CATEGORIES[category]] then
			selected, sel_item = 0, nil
			say(CATEGORIES[category] .. ", " .. (n > 0 and n or "none here right now"), true)
			return
		end
	end
end

-- Walk there for you: the script holds the D-pad toward the thing you picked. A door is walked
-- into from the front: the script first goes to a spot just outside it, then straight in. When
-- something is in the way it steps to one side and tries again. Any controller button takes over.
------------------------------------------------------------------------------ path finding --
-- The game's own collision walls for every map come from dq9-access-maps.bin (taken from the
-- ROM). With them the script plans a real route around cliffs, fences and houses.
NAV_FILE = "dq9-access-maps.bin"
local nav_index = nil          -- name -> { off, n }
local nav = nil                -- walls and floors of the current map
local nav_cache = nil
NB = 2.0                 -- bucket size in world units
NCELL = 0.5              -- path grid size

local function nav_load_index()
	if nav_index then return nav_index end
	nav_index = {}
	local f = io.open(NAV_FILE, "rb")
	if not f then return nav_index end
	local head = f:read(8)
	if head and head:sub(1, 4) == "DQ9N" then
		local count = string.unpack("<I4", head, 5)
		local idx = f:read(count * 16) or ""
		for i = 0, count - 1 do
			local name = idx:sub(i * 16 + 1, i * 16 + 8)
			local off, n, v = string.unpack("<I4I2I2", idx, i * 16 + 9)
			nav_index[name] = { off = off, n = n, scale = 2 ^ (12 - v) }
		end
	end
	f:close()
	return nav_index
end

local function bucket_add(t, x0, z0, x1, z1, v)
	for i = math.floor(x0 / NB), math.floor(x1 / NB) do
		for j = math.floor(z0 / NB), math.floor(z1 / NB) do
			local k = i * 100000 + j
			local b = t[k]
			if not b then b = {} t[k] = b end
			b[#b + 1] = v
		end
	end
end

-- The collision file of the map you are on, from the map number (the map name string is the
-- same for every house in a town, the number is not).
local function nav_name()
	local m = MAPIDS[u16(MAPID)]
	local code = m and m[1]
	if not code then
		code = map_code()
		return code and (code:sub(1, 3) .. "A" .. code:sub(5, 8))
	end
	if #code == 3 then return code .. "A0000" end
	return code:sub(1, 3) .. "A" .. code:sub(5, 6) .. "00"
end
-- Read a map's walls and floors from the file. When run as a background job (a coroutine) it
-- does a slice each frame, so arriving in a big area does not make the game hitch.
function nav_build(name)
	local e = nav_load_index()[name]
	if not e then return nil end
	local f = io.open(NAV_FILE, "rb")
	if not f then return nil end
	f:seek("set", e.off)
	local raw = f:read(e.n * 24) or ""
	f:close()
	local n = { name = name, walls = {}, wb = {}, fb = {}, bb = {}, nfloors = 0 }
	for t = 0, e.n - 1 do
		if t % 150 == 149 and coroutine.isyieldable() then coroutine.yield() end
		local v = { string.unpack("<hhhhhhhhhh", raw, t * 24 + 1) }
		local ny = v[10] / 4096
		local sc = e.scale
		local x1, z1, x2, z2, x3, z3 = v[1] / sc, v[3] / sc, v[4] / sc, v[6] / sc, v[7] / sc, v[9] / sc
		if ny >= 0.5 then
			local tri = { x1, z1, x2, z2, x3, z3, v[2] / sc, v[5] / sc, v[8] / sc }
			n.nfloors = n.nfloors + 1
			bucket_add(n.fb, math.min(x1, x2, x3), math.min(z1, z2, z3), math.max(x1, x2, x3), math.max(z1, z2, z3), tri)
		elseif ny > -0.5 then
			-- a wall: its footprint on the ground is its longest edge
			local p = { { x1, z1 }, { x2, z2 }, { x3, z3 } }
			local ba, bb, bl = 1, 2, -1
			for a = 1, 2 do for b = a + 1, 3 do
				local l = (p[a][1] - p[b][1]) ^ 2 + (p[a][2] - p[b][2]) ^ 2
				if l > bl then ba, bb, bl = a, b, l end
			end end
			if bl > 0.0001 then
				-- with its height, so walls of a floor below a bridge can be left out
				local y1, y2, y3 = v[2] / sc, v[5] / sc, v[8] / sc
				local w = { p[ba][1], p[ba][2], p[bb][1], p[bb][2], math.min(y1, y2, y3), math.max(y1, y2, y3) }
				-- where each corner sits along the footprint (0..1) and its height, so the wall's
				-- height at any point along it can be worked out (a slanted wall beside a ramp)
				local ax, az = w[3] - w[1], w[4] - w[2]
				local l = ax * ax + az * az
				local ys = { y1, y2, y3 }
				for c = 1, 3 do
					w[5 + 2 * c] = ((p[c][1] - w[1]) * ax + (p[c][2] - w[2]) * az) / l
					w[6 + 2 * c] = ys[c]
				end
				n.walls[#n.walls + 1] = w
				bucket_add(n.wb, math.min(w[1], w[3]) - 0.8, math.min(w[2], w[4]) - 0.8,
				           math.max(w[1], w[3]) + 0.8, math.max(w[2], w[4]) + 0.8, w)
			end
		end
	end
	return n
end
local function nav_for()
	local name = nav_name()
	if not name then return nil end
	if nav and nav.name == name then return nav end
	nav_cache = nav_cache or {}
	if nav_cache[name] then nav = nav_cache[name] return nav end
	local n = nav_build(name)
	if not n then return nil end
	nav = n
	nav_cache[name] = n
	return n
end
-- the walls of a map you have just arrived in, read in the background
nav_job = nil
function nav_prefetch()
	if nav_job then
		local ok, n = coroutine.resume(nav_job.co)
		if not ok then nav_job = nil return end
		if coroutine.status(nav_job.co) == "dead" then
			nav_cache = nav_cache or {}
			if n then nav_cache[nav_job.name] = n end
			nav_job = nil
			doors_cache.list = nil          -- name the stairs now that the floors are known
		end
		return
	end
	local name = nav_name()
	if name and not (nav_cache and nav_cache[name]) and name ~= nav_failed then
		nav_failed = name
		nav_job = { name = name, co = coroutine.create(function() return nav_build(name) end) }
	end
end
function nav_ready()
	local name = nav_name()
	return name and nav_cache and nav_cache[name] and nav_for() or nil
end

local function seg_dist2(px, pz, ax, az, bx, bz)
	local abx, abz = bx - ax, bz - az
	local l = abx * abx + abz * abz
	local t = l > 0 and ((px - ax) * abx + (pz - az) * abz) / l or 0
	if t < 0 then t = 0 elseif t > 1 then t = 1 end
	local dx, dz = px - (ax + t * abx), pz - (az + t * abz)
	return dx * dx + dz * dz
end
local function cross(ox, oz, px, pz, qx, qz) return (px - ox) * (qz - oz) - (pz - oz) * (qx - ox) end
local function seg_cross(ax, az, bx, bz, cx, cz, dx, dz)
	local d1, d2 = cross(cx, cz, dx, dz, ax, az), cross(cx, cz, dx, dz, bx, bz)
	local d3, d4 = cross(ax, az, bx, bz, cx, cz), cross(ax, az, bx, bz, dx, dz)
	return ((d1 > 0) ~= (d2 > 0)) and ((d3 > 0) ~= (d4 > 0))
end
local function has_floor(n, x, z)
	if n.nfloors == 0 then return true end
	local b = n.fb[math.floor(x / NB) * 100000 + math.floor(z / NB)]
	if not b then return false end
	for _, t in ipairs(b) do
		local x1, z1, x2, z2, x3, z3 = t[1], t[2], t[3], t[4], t[5], t[6]
		local d = (z2 - z3) * (x1 - x3) + (x3 - x2) * (z1 - z3)
		if d ~= 0 then
			local l1 = ((z2 - z3) * (x - x3) + (x3 - x2) * (z - z3)) / d
			local l2 = ((z3 - z1) * (x - x3) + (x1 - x3) * (z - z3)) / d
			if l1 >= -0.001 and l2 >= -0.001 and l1 + l2 <= 1.001 then return true end
		end
	end
	return false
end
-- can you stand here with this much room around you?
local function clear_at(n, x, z, clear, floors)
	if floors and not has_floor(n, x, z) then return false end
	local k = math.floor(x / NB) * 100000 + math.floor(z / NB)
	local bl = n.bb[k]
	if bl then
		for _, o in ipairs(bl) do
			if (x - o[1]) ^ 2 + (z - o[2]) ^ 2 < (o[3] + clear) ^ 2 then return false end
		end
	end
	local b = n.wb[k]
	if not b then return true end
	local c2 = clear * clear
	local py = n.py
	for _, w in ipairs(b) do
		if not (py and (w[6] < py - 0.4 or w[5] > py + 2.2)) then
			if seg_dist2(x, z, w[1], w[2], w[3], w[4]) < c2 then return false end
		end
	end
	return true
end
-- things the walls do not show (trees, barrels, people) are learned when you bump into them
local function nav_block(n, x, z, r)
	bucket_add(n.bb, x - r - 1, z - r - 1, x + r + 1, z + r + 1, { x, z, r })
end
-- (walls wholly below your feet, or high above your head, are on another level)
local function wall_between(n, x0, z0, x1, z1)
	local py = n.py
	local b = n.wb[math.floor(x1 / NB) * 100000 + math.floor(z1 / NB)]
	if b then for _, w in ipairs(b) do
		if not (py and (w[6] < py - 0.4 or w[5] > py + 2.2)) and seg_cross(x0, z0, x1, z1, w[1], w[2], w[3], w[4]) then return true end
	end end
	b = n.wb[math.floor(x0 / NB) * 100000 + math.floor(z0 / NB)]
	if b then for _, w in ipairs(b) do
		if not (py and (w[6] < py - 0.4 or w[5] > py + 2.2)) and seg_cross(x0, z0, x1, z1, w[1], w[2], w[3], w[4]) then return true end
	end end
	return false
end
-- a straight line you can walk along
local function line_ok(n, x0, z0, x1, z1, clear, avoid)
	local d = math.sqrt((x1 - x0) ^ 2 + (z1 - z0) ^ 2)
	local steps = math.max(1, math.ceil(d / 0.3))
	local lx, lz = x0, z0
	for i = 1, steps do
		local x, z = x0 + (x1 - x0) * i / steps, z0 + (z1 - z0) * i / steps
		if not clear_at(n, x, z, clear, false) or wall_between(n, lx, lz, x, z) then return false end
		if avoid then
			for _, b in ipairs(avoid) do
				if x > b.x0 - 0.5 and x < b.x1 + 0.5 and z > b.z0 - 0.5 and z < b.z1 + 0.5 then return false end
			end
		end
		lx, lz = x, z
	end
	return true
end

-- A* over a half-step grid. Runs a little each frame (it is a coroutine) so the game never stalls:
-- at most about 5 milliseconds of planning per frame.
PLAN_SLICE = 0.005
plan_clock = nil
function plan_resume(co)
	plan_clock = os.clock and os.clock() or nil
	return coroutine.resume(co)
end
NEIGH = { { 1, 0, 1 }, { -1, 0, 1 }, { 0, 1, 1 }, { 0, -1, 1 }, { 1, 1, 1.4142 }, { 1, -1, 1.4142 }, { -1, 1, 1.4142 }, { -1, -1, 1.4142 } }
local function find_path(n, sx, sz, gx, gz, clear, floors, budget, avoid)
	local C = NCELL
	local si, sj = math.floor(sx / C + 0.5), math.floor(sz / C + 0.5)
	local gi, gj = math.floor(gx / C + 0.5), math.floor(gz / C + 0.5)
	local function key(i, j) return (i + 20000) * 40000 + (j + 20000) end
	local function h(i, j) local a, b = math.abs(i - gi), math.abs(j - gj) return math.max(a, b) + 0.4142 * math.min(a, b) end
	local ok = {}
	local function passable(i, j)
		local k = key(i, j)
		local v = ok[k]
		if v == nil then
			local x, z = i * C, j * C
			v = clear_at(n, x, z, clear, floors)
			if v and avoid then
				-- keep out of doorways and exits you are not going to
				for _, b in ipairs(avoid) do
					if x > b.x0 - 0.6 and x < b.x1 + 0.6 and z > b.z0 - 0.6 and z < b.z1 + 0.6 then v = false break end
				end
			end
			ok[k] = v
		end
		return v
	end
	-- binary heap
	local heap, hn = {}, 0
	local function push(f, k, i, j)
		hn = hn + 1
		local e = { f, k, i, j }
		local c = hn
		heap[c] = e
		while c > 1 do
			local p = c // 2
			if heap[p][1] <= f then break end
			heap[c], heap[p] = heap[p], heap[c]
			c = p
		end
	end
	local function pop()
		local top = heap[1]
		heap[1] = heap[hn] heap[hn] = nil hn = hn - 1
		local c = 1
		while true do
			local l, r, m = c * 2, c * 2 + 1, c
			if l <= hn and heap[l][1] < heap[m][1] then m = l end
			if r <= hn and heap[r][1] < heap[m][1] then m = r end
			if m == c then break end
			heap[c], heap[m] = heap[m], heap[c]
			c = m
		end
		return top
	end
	local g, came = {}, {}
	local sk = key(si, sj)
	g[sk] = 0
	push(h(si, sj), sk, si, sj)
	local best, bestk, bi, bj = h(si, sj), sk, si, sj
	local count = 0
	while hn > 0 do
		local e = pop()
		local k, i, j = e[2], e[3], e[4]
		local gc = g[k]
		if e[1] - h(i, j) <= gc + 0.0001 then
			local hd = h(i, j)
			if hd < best then best, bestk, bi, bj = hd, k, i, j end
			if hd < 1 then break end
			count = count + 1
			if count > 60000 then break end
			if count % budget == 0 or (count % 24 == 0 and plan_clock and os.clock() - plan_clock > PLAN_SLICE) then
				coroutine.yield()
				plan_clock = os.clock and os.clock()
			end
			for _, d in ipairs(NEIGH) do
				local ni, nj = i + d[1], j + d[2]
				if passable(ni, nj) and not wall_between(n, i * C, j * C, ni * C, nj * C) then
					local nk = key(ni, nj)
					local ng = gc + d[3]
					if ng < (g[nk] or 1e18) then
						g[nk] = ng came[nk] = { k, i, j }
						push(ng + h(ni, nj), nk, ni, nj)
					end
				end
			end
		end
	end
	-- walk back from the closest point reached
	local pts = {}
	local k, i, j = bestk, bi, bj
	while k do
		table.insert(pts, 1, { i * C, j * C })
		local c = came[k]
		if not c then break end
		k, i, j = c[1], c[2], c[3]
	end
	-- straighten it: from each point jump to the farthest point you can walk to in a line
	local out = {}
	local a = 1
	while a < #pts do
		local b = math.min(#pts, a + 40)
		while b > a + 1 and not line_ok(n, pts[a][1], pts[a][2], pts[b][1], pts[b][2], clear * 0.8, avoid) do b = b - 1 end
		out[#out + 1] = pts[b]
		a = b
	end
	return out, best * C
end

-- The same, but knowing about levels: a bridge over a hall, a balcony, stairs between them.
-- Every half step it keeps the height of the floor you would be standing on; you can only step
-- onto floor near that height, and only walls at the height of your body are in the way.
function floor_heights(n, x, z)
	local b = n.fb[math.floor(x / NB) * 100000 + math.floor(z / NB)]
	local out = {}
	if not b then return out end
	for _, t in ipairs(b) do
		local x1, z1, x2, z2, x3, z3 = t[1], t[2], t[3], t[4], t[5], t[6]
		local d = (z2 - z3) * (x1 - x3) + (x3 - x2) * (z1 - z3)
		if d ~= 0 and t[7] then
			local l1 = ((z2 - z3) * (x - x3) + (x3 - x2) * (z - z3)) / d
			local l2 = ((z3 - z1) * (x - x3) + (x1 - x3) * (z - z3)) / d
			if l1 >= -0.001 and l2 >= -0.001 and l1 + l2 <= 1.001 then
				out[#out + 1] = l1 * t[7] + l2 * t[8] + (1 - l1 - l2) * t[9]
			end
		end
	end
	return out
end
function floor_near(n, x, z, h, reach)
	local best, bd = nil, reach
	for _, y in ipairs(floor_heights(n, x, z)) do
		local d = math.abs(y - h)
		if d <= bd then best, bd = y, d end
	end
	return best
end
-- how high a wall reaches at the point along it nearest to (x, z)
function wall_span_at(w, x, z)
	if not w[7] then return w[5], w[6] end
	local ax, az = w[3] - w[1], w[4] - w[2]
	local l = ax * ax + az * az
	local t = l > 0 and ((x - w[1]) * ax + (z - w[2]) * az) / l or 0
	if t < 0 then t = 0 elseif t > 1 then t = 1 end
	local lo, hi = nil, nil
	for a = 1, 3 do
		local b = a % 3 + 1
		local ta, ya, tb, yb = w[5 + 2 * a], w[6 + 2 * a], w[5 + 2 * b], w[6 + 2 * b]
		if (ta - t) * (tb - t) <= 0 then
			local y
			if math.abs(tb - ta) < 1e-6 then y = math.max(ya, yb)
				lo, hi = math.min(lo or ya, ya, yb), math.max(hi or ya, ya, yb)
			else
				y = ya + (yb - ya) * (t - ta) / (tb - ta)
				lo, hi = math.min(lo or y, y), math.max(hi or y, y)
			end
		end
	end
	if not lo then return w[5], w[6] end
	return lo, hi
end
function wall_in_band(w, h, x, z)
	if w[5] >= h + 1.4 or w[6] <= h + 0.3 then return false end
	if not x then return true end
	local lo, hi = wall_span_at(w, x, z)
	return lo < h + 1.4 and hi > h + 0.3
end
function clear_at3(n, x, z, h, clear)
	local k = math.floor(x / NB) * 100000 + math.floor(z / NB)
	local bl = n.bb[k]
	if bl then
		for _, o in ipairs(bl) do
			if (x - o[1]) ^ 2 + (z - o[2]) ^ 2 < (o[3] + clear) ^ 2 then return false end
		end
	end
	local b = n.wb[k]
	if not b then return true end
	local c2 = clear * clear
	for _, w in ipairs(b) do
		if seg_dist2(x, z, w[1], w[2], w[3], w[4]) < c2 and wall_in_band(w, h, x, z) then return false end
	end
	return true
end
function wall_between3(n, x0, z0, x1, z1, h)
	for _, k in ipairs({ math.floor(x1 / NB) * 100000 + math.floor(z1 / NB), math.floor(x0 / NB) * 100000 + math.floor(z0 / NB) }) do
		local b = n.wb[k]
		if b then for _, w in ipairs(b) do
			if seg_cross(x0, z0, x1, z1, w[1], w[2], w[3], w[4]) and wall_in_band(w, h, (x0 + x1) / 2, (z0 + z1) / 2) then return true end
		end end
	end
	return false
end
function in_avoid(avoid, x, z, h, pad)
	if not avoid then return false end
	for _, b in ipairs(avoid) do
		if x > b.x0 - pad and x < b.x1 + pad and z > b.z0 - pad and z < b.z1 + pad
			and (not b.y0 or (h > b.y0 - 0.5 and h < b.y1 + 0.5)) then return true end
	end
	return false
end
STEP_RISE = 0.6
function line_ok3(n, x0, z0, h0, x1, z1, clear, avoid, h1)
	local d = math.sqrt((x1 - x0) ^ 2 + (z1 - z0) ^ 2)
	local steps = math.max(1, math.ceil(d / 0.3))
	local lx, lz, h = x0, z0, h0
	for i = 1, steps do
		local x, z = x0 + (x1 - x0) * i / steps, z0 + (z1 - z0) * i / steps
		-- keep to the floor the route is on (not a floor above or below it)
		local want = h1 and (h0 + (h1 - h0) * i / steps) or h
		local nh = floor_near(n, x, z, want, h1 and 0.45 or STEP_RISE * 0.6)
		if nh and math.abs(nh - h) > STEP_RISE then nh = nil end
		if not nh or not clear_at3(n, x, z, nh, clear) or wall_between3(n, lx, lz, x, z, math.max(h, nh))
			or in_avoid(avoid, x, z, nh, 0.5) then return false end
		lx, lz, h = x, z, nh
	end
	return true
end
function find_path3(n, sx, sy, sz, gx, gz, gy, clear, budget, avoid)
	local C = NCELL
	local si, sj = math.floor(sx / C + 0.5), math.floor(sz / C + 0.5)
	local gi, gj = math.floor(gx / C + 0.5), math.floor(gz / C + 0.5)
	local sh = floor_near(n, sx, sz, sy, 1.5) or sy
	local function key(i, j, h) return ((i + 20000) * 40000 + (j + 20000)) * 64 + (math.floor(h * 2 + 0.5) % 64) end
	local function hd(i, j, h)
		local a, b = math.abs(i - gi), math.abs(j - gj)
		local v = math.max(a, b) + 0.4142 * math.min(a, b)
		if gy then v = v + math.max(0, math.abs(h - gy) - 1.2) * 2 end
		return v
	end
	local heap, hn = {}, 0
	local function push(f, e)
		hn = hn + 1
		local c = hn
		heap[c] = { f, e }
		while c > 1 do
			local p = c // 2
			if heap[p][1] <= f then break end
			heap[c], heap[p] = heap[p], heap[c]
			c = p
		end
	end
	local function pop()
		local top = heap[1]
		heap[1] = heap[hn] heap[hn] = nil hn = hn - 1
		local c = 1
		while true do
			local l, r, m = c * 2, c * 2 + 1, c
			if l <= hn and heap[l][1] < heap[m][1] then m = l end
			if r <= hn and heap[r][1] < heap[m][1] then m = r end
			if m == c then break end
			heap[c], heap[m] = heap[m], heap[c]
			c = m
		end
		return top[2]
	end
	local g, came = {}, {}
	local fh_memo, clear_memo = {}, {}
	local s0 = { si, sj, sh, key(si, sj, sh) }
	g[s0[4]] = 0
	push(hd(si, sj, sh), s0)
	local best, bestn = hd(si, sj, sh), s0
	local count = 0
	while hn > 0 do
		local e = pop()
		local i, j, h, k = e[1], e[2], e[3], e[4]
		local gc = g[k]
		if not e.done then
			e.done = true
			local dd = hd(i, j, h)
			if dd < best then best, bestn = dd, e end
			if dd < 1 then break end
			count = count + 1
			if count > 60000 then break end
			if count % budget == 0 or (count % 24 == 0 and plan_clock and os.clock() - plan_clock > PLAN_SLICE) then
				coroutine.yield()
				plan_clock = os.clock and os.clock()
			end
			for _, d in ipairs(NEIGH) do
				local ni, nj = i + d[1], j + d[2]
				local x, z = ni * C, nj * C
				-- every floor within a step's reach is a way on (a ramp over a floor: both)
				local ck = (ni + 20000) * 40000 + (nj + 20000)
				local fhs = fh_memo[ck]
				if not fhs then fhs = floor_heights(n, x, z) fh_memo[ck] = fhs end
				for _, nh in ipairs(fhs) do
					local ok_here = clear_memo[ck * 64 + (math.floor(nh * 2 + 0.5) % 64)]
					if ok_here == nil then
						ok_here = clear_at3(n, x, z, nh, clear)
						clear_memo[ck * 64 + (math.floor(nh * 2 + 0.5) % 64)] = ok_here
					end
					if math.abs(nh - h) <= STEP_RISE * d[3] and ok_here
						and not wall_between3(n, i * C, j * C, x, z, math.max(h, nh))
						and not in_avoid(avoid, x, z, nh, 0.6) then
						local nk = key(ni, nj, nh)
						local ng = gc + d[3]
						if ng < (g[nk] or 1e18) then
							g[nk] = ng
							local ne = { ni, nj, nh, nk }
							came[nk] = e
							push(ng + hd(ni, nj, nh), ne)
						end
					end
				end
			end
		end
	end
	local pts = {}
	local e = bestn
	while e do
		table.insert(pts, 1, { e[1] * C, e[2] * C, e[3] })
		e = came[e[4]]
	end
	local out = {}
	local a = 1
	while a < #pts do
		local b = math.min(#pts, a + 40)
		while b > a + 1 and not line_ok3(n, pts[a][1], pts[a][2], pts[a][3], pts[b][1], pts[b][2], clear * 0.8, avoid, pts[b][3]) do b = b - 1 end
		out[#out + 1] = pts[b]
		a = b
	end
	return out, best * C
end
-- Exits at the top or bottom of a flight of stairs: the floor inside the exit's box climbs.
-- Call them "stairs up to ..." or "stairs down to ..." (from the height you are at now).
function stairs_mark(list)
	local nv = nav_ready()
	if not nv or nv.nfloors == 0 then return end
	local _, py = player_pos()
	for _, d in ipairs(list) do
		if d.kind == 0 and d.y0 and not EXIT_NAMES[d.id] and not (d.id >= 20000 and d.id < 30000) then
			local lo, hi, sum, n = math.huge, -math.huge, 0, 0
			for i = 0, 4 do for j = 0, 4 do
				local x, z = d.x0 + (d.x1 - d.x0) * i / 4, d.z0 + (d.z1 - d.z0) * j / 4
				for _, h in ipairs(floor_heights(nv, x, z)) do
					if h >= d.y0 - 0.5 and h <= d.y1 + 0.5 then
						lo, hi, sum, n = math.min(lo, h), math.max(hi, h), sum + h, n + 1
					end
				end
			end end
			if n > 0 and hi - lo > 0.7 then
				local name = (d.label:gsub("^exit to ", ""))
				if name == "exit" or name == "passage" then name = nil end
				local mid = sum / n
				local way = ""
				if py and mid > py + 1 then way = " up" elseif py and mid < py - 1 then way = " down" end
				d.label = "stairs" .. way .. (name and (" to " .. name) or "")
			end
		end
	end
end
-- the planner to use: with levels when the map has floors with heights
function plan_path(n, sx, sy, sz, gx, gz, gy, clear, floors, budget, avoid)
	if floors and sy and n.nfloors > 0 then
		local p, rem = find_path3(n, sx, sy, sz, gx, gz, gy, clear, budget, avoid)
		return p, rem
	end
	return find_path(n, sx, sz, gx, gz, clear, floors, budget, avoid)
end

DIRS = { { Up = true }, { Up = true, Right = true }, { Right = true }, { Down = true, Right = true },
               { Down = true }, { Down = true, Left = true }, { Left = true }, { Up = true, Left = true } }
local function dir_toward(dx, dz)
	local ux, uz, rx, rz = screen_axes()
	local f, r = dx * ux + dz * uz, dx * rx + dz * rz
	local a = (math.atan2 or math.atan)(r, f)
	return math.floor(a / (math.pi / 4) + 0.5) % 8
end
-- Doorways and exits a route keeps out of: all but the one you are going to and the one you are
-- standing in (the planner knows their heights, so one on another level is no obstacle)
function avoid_list(tx, tz, px, pz)
	local py = select(2, player_pos())
	local avoid = {}
	for _, d in ipairs(doors()) do
		local mine = tx and math.abs(d.x - tx) < 0.1 and math.abs(d.z - tz) < 0.1
		local here = px > d.x0 and px < d.x1 and pz > d.z0 and pz < d.z1
		if not mine and not here then avoid[#avoid + 1] = d end
	end
	return avoid
end
local walk = nil
local function stop_walk(msg)
	walk = nil
	if msg then say(msg, true) end
end
dq9_debug = function() return walk end
local function start_walk()
	local it = sel_item
	if not it then say("Press N to pick something first.") return end
	local px, _, pz = player_pos()
	if not px then say("Cannot walk right now.") return end
	-- things bumped into on earlier walks (often a person who has since moved) are forgotten
	local nv0 = nav_for()
	if nv0 then nv0.bb = {} end
	walk = { x = it.x, z = it.z, tx0 = it.x, tz0 = it.z, gy = it.y0 and (it.y0 + 1) or nil, label = it.label, obj = it.obj, posoff = it.posoff or 0x24, start = frame, code = map_code(), sx = px, sz = pz,
	         best = 1e9, progress = frame, side = 1, side_until = 0, tries = 0, push = 0 }
	if it.nx then
		-- a door: its thin side faces the way in. Start from the side you are on.
		-- (a door in front of its exit box is always entered from the door's own side)
		local sgn = ((px - it.x) * it.nx + (pz - it.z) * it.nz) >= 0 and 1 or -1
		if it.facing then sgn = 1 end
		walk.door = { x = it.x, z = it.z, nx = it.nx * sgn, nz = it.nz * sgn, flipped = it.facing or false, wx = it.wx, wz = it.wz }
		local out = it.facing and 1.4 or 1.8
		walk.x, walk.z = it.x + walk.door.nx * out, it.z + walk.door.nz * out
		walk.stage = "front"
	end
	say("Walking to " .. it.label .. ". Press any button to stop.", true)
end
local function walk_step(host_pressed)
	if not walk then return end
	if host_pressed then stop_walk("Stopped.") return end
	if map_code() ~= walk.code then stop_walk() return end               -- went through a door
	if in_battle() or frame - last_dialogue_frame < 10 then stop_walk() return end
	local px, _, pz = player_pos()
	if not px then stop_walk() return end
	if walk.obj then                                                     -- people move: follow them
		local x, z = s32(walk.obj + walk.posoff) / 4096, s32(walk.obj + walk.posoff + 8) / 4096
		if math.abs(x) < 2000 and math.abs(z) < 2000 then walk.x, walk.z = x, z end
	end
	if frame - walk.start > 60 * 240 then stop_walk("Could not get there.") return end
	local dx, dz = walk.x - px, walk.z - pz
	local d = math.sqrt(dx * dx + dz * dz)
	if walk.stage == "front" and d < 0.5 then
		walk.stage, walk.x, walk.z = "in", walk.door.x - walk.door.nx * 0.6, walk.door.z - walk.door.nz * 0.6
		-- through the door and on into the exit box behind it
		if walk.door.wx then walk.x, walk.z = walk.door.wx - walk.door.nx * 0.5, walk.door.wz - walk.door.nz * 0.5 end
		walk.best, walk.progress, walk.tries, walk.follow, walk.stall, walk.path, walk.co = 1e9, frame, 0, nil, 0, nil, nil
		return
	end
	if walk.stage == "in" then
		if d < 0.3 then walk.push = walk.push + 1 end
		if walk.push > 40 or (frame - walk.progress > 40) then
			if not walk.door.flipped then
				-- nothing opened from this side: try the other side of the door
				local dr = walk.door
				dr.nx, dr.nz, dr.flipped = -dr.nx, -dr.nz, true
				walk.stage, walk.x, walk.z = "front", dr.x + dr.nx * 1.8, dr.z + dr.nz * 1.8
				walk.best, walk.progress, walk.tries, walk.push, walk.follow, walk.stall, walk.path, walk.co = 1e9, frame, 0, 0, nil, 0, nil, nil
				return
			end
			if walk.label == "entrance" then stop_walk("At the entrance. Walk into it or press A.") return end
			stop_walk("At " .. walk.label .. ", but it did not open. Try walking into it yourself.") return
		end
	elseif not walk.door and d < (walk.obj and 1.4 or 0.7) then
		stop_walk("Arrived at " .. walk.label .. ".") return
	end
	if math.abs(px - walk.sx) + math.abs(pz - walk.sz) > 0.3 then walk.moved = true end
	if not walk.moved and frame - (walk.checked_from or walk.start) > 150 and not walk.co then stop_walk("You cannot move right now.") return end
	if walk.stage == "in" then
		-- straight into the door
		if d < walk.best - 0.25 then walk.best, walk.progress = d, frame end
		pcall(function() joypad.set(DIRS[dir_toward(dx, dz) + 1]) end)
		return
	end
	-- Follow a planned route when the map's walls are known.
	local nv = not walk.nopath and nav_for()
	if nv then
		if walk.path and walk.obj and ((walk.x - walk.goal[1]) ^ 2 + (walk.z - walk.goal[2]) ^ 2) > 4 then walk.path = nil end
		if not walk.path then
			if not walk.co then
				local sx, sz, gx, gz = px, pz, walk.x, walk.z
				walk.goal = { gx, gz }
				local avoid = avoid_list(walk.tx0, walk.tz0, px, pz)
				nv.py = select(2, player_pos())
				local sy = select(2, player_pos())
				local gy = walk.gy
				walk.co = coroutine.create(function()
					local p, rem = plan_path(nv, sx, sy, sz, gx, gz, gy, 0.45, true, 20000, avoid)
					if rem > 1.5 then
						local p2, rem2 = find_path(nv, sx, sz, gx, gz, 0.3, false, 20000, avoid)
						if rem2 < rem - 1 then p, rem = p2, rem2 end
					end
					return p, rem
				end)
			end
			local ok, p, rem = plan_resume(walk.co)
			if not ok then
				walk.nopath, walk.co = true, nil
			elseif coroutine.status(walk.co) == "dead" then
				walk.co, walk.path, walk.pi, walk.wbest, walk.wprog, walk.rem = nil, p or {}, 1, 1e9, frame, rem or 0
				walk.checked_from = frame
			end
			return
		end
		local wp = walk.path[walk.pi]
		while wp and ((wp[1] - px) ^ 2 + (wp[2] - pz) ^ 2) < 0.36 do
			walk.pi, walk.wbest, walk.wprog = walk.pi + 1, 1e9, frame
			wp = walk.path[walk.pi]
		end
		if wp then
			local wx, wz = wp[1] - px, wp[2] - pz
			local wd = math.sqrt(wx * wx + wz * wz)
			if wd < walk.wbest - 0.2 then walk.wbest, walk.wprog = wd, frame end
			if frame - walk.wprog > 30 then
				-- something the walls do not show is in the way: remember it and plan around it
				walk.replans = (walk.replans or 0) + 1
				if walk.replans > 12 then walk.nopath = true return end
				nav_block(nv, px + wx / math.max(wd, 0.01) * 0.8, pz + wz / math.max(wd, 0.01) * 0.8, 0.5)
				walk.path = nil
				return
			end
			pcall(function() joypad.set(DIRS[dir_toward(wx, wz) + 1]) end)
			return
		end
		-- the route is done: the last bit is straight
		dx, dz = walk.x - px, walk.z - pz
		if (walk.rem or 0) > 1.0 and walk.stage ~= "in" then
			-- the route could not reach it (a shop counter, a fence): turn to face it and stop here
			walk.final = walk.final or frame + 12
			if frame < walk.final then
				pcall(function() joypad.set(DIRS[dir_toward(dx, dz) + 1]) end)
				return
			end
			local label, tx, tz = walk.label, walk.x, walk.z
			stop_walk()
			say("As close as you can get. " .. label:gsub("^%l", string.upper) .. " is " .. directions_to(tx, tz) .. ".", true)
			return
		end
	end
	-- Head straight for the target. When a wall stops you, follow the wall (keeping it on one
	-- side) until you are closer than where you hit it, then head straight again. If one side
	-- leads nowhere for a long time, try the other side.
	walk.tick = walk.tick or frame
	walk.tx = walk.tx or px
	walk.tz = walk.tz or pz
	walk.hand = walk.hand or 1
	walk.dir = walk.dir or dir_toward(dx, dz)
	if frame - walk.tick >= 8 then
		local moved = math.sqrt((px - walk.tx) ^ 2 + (pz - walk.tz) ^ 2)
		walk.tick, walk.tx, walk.tz = frame, px, pz
		local goal = dir_toward(dx, dz)
		local f = walk.follow
		if not f then
			if moved < 0.2 then walk.stall = (walk.stall or 0) + 1 else walk.stall = 0 end
			walk.dir = goal
			if walk.stall >= 2 then
				walk.stall = 0
				walk.follow = { h = (goal - 2 * walk.hand) % 8, hit = d, since = frame, best = d, good = 0 }
				walk.dir = walk.follow.h
			end
		else
			if d < f.best - 0.25 then f.best, f.since = d, frame end
			if d < f.hit - 1.0 then
				walk.follow, walk.dir, walk.stall = nil, goal, 0
			else
				if moved >= 0.2 then
					f.good = f.good + 1
					if f.good >= 2 then f.good = 0 f.h = (f.h + walk.hand) % 8 end   -- lean back toward the wall
				else
					f.good = 0
					f.h = (f.h - walk.hand) % 8                                     -- turn away from it
				end
				walk.dir = f.h
				if frame - f.since > 60 * 20 then
					walk.flips = (walk.flips or 0) + 1
					if walk.flips > 3 then stop_walk("Could not find a way there. Try walking part of the way, then press J again.") return end
					walk.hand = -walk.hand
					walk.follow = { h = (goal - 2 * walk.hand) % 8, hit = d, since = frame, best = d, good = 0 }
					walk.dir = walk.follow.h
				end
			end
		end
	end
	local b = {}
	for k, v in pairs(DIRS[walk.dir + 1]) do b[k] = v end	pcall(function() joypad.set(b) end)
end

------------------------------------------------------------------------------ alerts --------
local still_frames, last_px, last_pz, bumped = 0, nil, nil, false
local close_to = {}

local function alerts(pad)
	if not ALERTS_ON then return end
	local px, _, pz = player_pos()
	if not px then return end
	local moving_input = pad.up or pad.down or pad.left or pad.right
	if moving_input and last_px and math.abs(px - last_px) < 0.01 and math.abs(pz - last_pz) < 0.01
	   and frame - last_dialogue_frame > 60 and frame - last_menu_frame > 120
	   and not in_battle() and not pending
	   and frame - code_changed_frame > 60 and not fading() then
		still_frames = still_frames + 1
		if still_frames == 12 and not bumped then
			bumped = true
			say("blocked", true)
		end
	else
		still_frames = 0
		if not moving_input or (last_px and (math.abs(px - last_px) > 0.02 or math.abs(pz - last_pz) > 0.02)) then
			bumped = false
		end
	end
	last_px, last_pz = px, pz
	-- someone right next to you
	if frame % 10 == 0 and not in_battle() and frame - last_dialogue_frame > 60 and not pending then
		local around = characters()
		for _, m in ipairs(monsters()) do around[#around + 1] = m end
		for _, c in ipairs(around) do
			local d = math.sqrt((c.x - px) ^ 2 + (c.z - pz) ^ 2)
			local near = c.monster and 5 or 1.8
			if d > near + 1.2 then close_to[c.obj] = nil end
			if d < near and not close_to[c.obj] then
				close_to[c.obj] = true
				queue(c.label .. " " .. directions_to(c.x, c.z))
			end
		end
	end
end

------------------------------------------------------------------------------ party ---------
REC0, REC_SIZE = 0x020F3888, 0x964
VOCATIONS = { [0] = "", "Warrior", "Priest", "Mage", "Martial Artist", "Thief", "Minstrel",
	"Gladiator", "Armamentalist", "Paladin", "Sage", "Luminary", "Ranger" }
IN_BATTLE = 0x020EF0E8

local function party_records()
	local list = {}
	local hero = cstring(0x020FB258, 12)
	for k = 0, 3 do
		local n = REC0 + k * REC_SIZE
		local name = cstring(n, 12)
		local maxhp = u16(n + 0x30)
		if printable(name) and maxhp > 1 and maxhp < 1000 and name ~= "NineJJ" then
			local r = { addr = n, name = name, hp = u16(n - 0x20), mp = u16(n - 0x1E), maxhp = maxhp,
			            maxmp = u16(n + 0x32), voc = u8(n + 0x429) }
			local lv = u16(n + 0x130 + 2 * r.voc)
			if lv > 0 and lv < 100 then r.level = lv end
			if name == hero then table.insert(list, 1, r) else list[#list + 1] = r end
		end
	end
	return list
end

-- Experience: remember everyone's total outside battles; the battle adds the reward just before
-- "... receives some experience!", so the difference is what was earned.
local exp_before = {}
battle_seen_frame, exp_frozen, exp_freeze_pos = -1000, false, nil
local function snapshot_experience()
	for _, r in ipairs(party_records()) do exp_before[r.name] = u32(r.addr + 0x114) end
end
experience_fix = function(text)
	if not text:lower():find("experience", 1, true) then return text end
	local gains = {}
	for _, r in ipairs(party_records()) do
		local before = exp_before[r.name]
		local now = u32(r.addr + 0x114)
		if before and now > before and now - before < 10000000 then gains[#gains + 1] = { r.name, now - before } end
	end
	if #gains == 0 then return text end
	if #gains == 1 and text:find("some experience", 1, true) then
		return (text:gsub("some experience", gains[1][2] .. " experience points"))
	end
	local parts = {}
	for _, g in ipairs(gains) do parts[#parts + 1] = g[1] .. " " .. g[2] end
	return text .. " Experience: " .. table.concat(parts, ", ") .. "."
end

-- In a battle the live numbers are kept in the battle's own copy of each fighter. Find it once per
-- battle by looking for the leader's maximum HP and MP side by side, then trust it while it checks out.
local battle_base, battle_checked = nil, -1000
BATTLE_STRIDE = 0x448
local function find_battle_party(members)
	if #members == 0 then return nil end
	local m1 = members[1]
	-- a fighter in battle: two pointers 0x18 apart, then max HP, max MP, HP, MP
	for _, range in ipairs({ { 0x02380000, 0x60000 }, { 0x02300000, 0x80000 }, { 0x023E0000, 0x20000 } }) do
	local from, len = range[1], range[2]
	local t = read_bytes(from, len)
	for i = 9, #t - 8, 4 do
		local mh = t[i] + t[i + 1] * 256
		if mh == m1.maxhp and (t[i + 2] + t[i + 3] * 256) == m1.maxmp then
			local hp, mp = t[i + 4] + t[i + 5] * 256, t[i + 6] + t[i + 7] * 256
			local a = from + i - 1
			local p1, p2 = u32(a - 8), u32(a - 4)
			if hp <= mh and mp <= m1.maxmp and inram(p1, 4) and inram(p2, 4) and p1 - p2 == 0x18 then
				local good = true
				for k = 2, #members do
					local b = a + (k - 1) * BATTLE_STRIDE
					if u16(b) ~= members[k].maxhp or u16(b + 2) ~= members[k].maxmp then good = false end
				end
				if good then return a end
			end
		end
	end
	end
	return nil
end

-- Whose turn it is to pick a command: the battle keeps the number of that fighter here
-- (fighters are 0x448 bytes apart, in the battle's own order), with max HP and MP at the start.
BATTLE_ACTOR_IDX, BATTLE_FIGHTER0 = 0x0239532C, 0x02395B10
function battle_actor_name()
	local idx = u8(BATTLE_ACTOR_IDX)
	if idx > 3 then return nil end
	local b = BATTLE_FIGHTER0 + idx * BATTLE_STRIDE
	if u32(b - 8) - u32(b - 4) ~= 0x18 then return nil end
	local mh, mm = u16(b), u16(b + 2)
	local found = nil
	for _, r in ipairs(party_records()) do
		if r.maxhp == mh and r.maxmp == mm then
			if found then return nil end        -- two alike: can't tell
			found = r.name
		end
	end
	return found
end
function turn_text(name)
	return (name:gsub("^%l", string.upper)) .. "'s turn. "
end

local function say_party()
	local members = party_records()
	if #members == 0 then say("No party information.") return end
	local in_battle = in_battle()
	if in_battle then
		local ok = battle_base and u16(battle_base) == members[1].maxhp and u16(battle_base + 4) <= members[1].maxhp
			and u32(battle_base - 8) - u32(battle_base - 4) == 0x18
		if not ok and frame - battle_checked > 30 then
			battle_checked = frame
			battle_base = find_battle_party(members)
		end
		if battle_base then
			for k, r in ipairs(members) do
				local b = battle_base + (k - 1) * BATTLE_STRIDE
				if u16(b) == r.maxhp then r.hp, r.mp = u16(b + 4), u16(b + 6) end
			end
		end
	else
		battle_base = nil
	end
	local parts = {}
	for _, r in ipairs(members) do
		local s = r.name .. ", " .. r.hp .. " of " .. r.maxhp .. " HP"
		if r.maxmp > 0 then s = s .. ", " .. r.mp .. " of " .. r.maxmp .. " MP" end
		if not in_battle then
			local voc = VOCATIONS[r.voc]
			if r.level then s = s .. ", level " .. r.level end
			if voc and voc ~= "" then s = s .. " " .. voc end
		end
		parts[#parts + 1] = s
	end
	say(table.concat(parts, ". "))
end


-- Each party record keeps the names of the equipment it is drawn with, in lower case, 0x30 bytes
-- apart starting at +0x534. Slot order seen in the game: body, legs, (2), feet, (4), weapon, shield.
-- Slots 2 and 4 were empty on every save tested; they are taken to be arms and head.
EQUIP_SLOTS = { { 5, "weapon" }, { 6, "shield" }, { 4, "head" }, { 0, "body" },
	{ 2, "arms" }, { 1, "legs" }, { 3, "feet" } }
local function say_equipment()
	local out = {}
	for _, r in ipairs(party_records()) do
		local worn = {}
		for _, slot in ipairs(EQUIP_SLOTS) do
			local item = clean(cstring(r.addr + 0x534 + slot[1] * 0x30, 0x30))
			if item ~= "" and printable(item) then worn[#worn + 1] = slot[2] .. " " .. item end
		end
		out[#out + 1] = r.name .. ": " .. (#worn > 0 and table.concat(worn, ", ") or "nothing equipped")
	end
	say(#out > 0 and table.concat(out, ". ") or "No party information.")
end

-- The equipment screen draws its list as pictures, so it is read here: the list control has a
-- recognisable shape (count, 1, 1, count, ..., cursor, then four pointers back into itself).
EQUIP_LIST = 0x0230FBB8
EQUIP_SCREEN_SLOTS = { { 5, "Weapon" }, { 6, "Shield" }, { 4, "Head" }, { 0, "Body" },
	{ 2, "Arms" }, { 1, "Legs" }, { 3, "Feet" }, { nil, "Accessory" } }
local equip_cursor = nil
local function list_control_ok(b, count)
	return u32(b) == count and u32(b + 0x20) == b + 8 and u32(b + 0x24) == b + 0xC
		and u32(b + 0x28) == b + 0x18 and u32(b + 0x2C) == b + 0x1C
end
EQUIP_SHOWN = 0x0230FB78          -- number of the item the top screen is showing
local equip_grid_item = nil
local function item_name(id)
	if id == 0xFFFF or id == 0 then return nil end
	local n = ITEM_NAMES[id]
	return n and (n:gsub("^%l", string.upper)) or ("item " .. id)
end
local equip_state, equip_due = nil, nil
------------------------------------------------------------------------------ shop screens --
-- Shops (and other screens built the same way) are laid out as a numbered list of boxes: text
-- boxes point at their words, number boxes hold a number (a price). The screen remembers which
-- box the cursor is on, so the script reads that box and the other boxes on the same line.
LAYOUT_PTR = 0x02108EE4
local lay_state, lay_pending, lay_since = nil, nil, 0
ls_cache, ls_table = {}, nil
function layout_string_raw(t, sid)
	local e, n = u32(t), u16(t + 4)
	if n > 2000 or not inram(e, n * 8) then return nil end
	for k = 0, n - 1 do
		if u16(e + k * 8) == sid then          -- the upper half of the id is sometimes junk
			local s = clean(cstring(u32(e + k * 8 + 4), 80))
			if s ~= "" and not s:match("^<") then return s end
			return nil
		end
	end
	return nil
end
local function layout_string(L, sid)
	local t = u32(L)
	if not inram(t, 8) then return nil end
	if t ~= ls_table then ls_cache, ls_table = {}, t end
	local c = ls_cache[sid]
	if type(c) == "string" then return c end
	if type(c) == "number" and frame - c < 30 then return nil end
	local v = layout_string_raw(t, sid)
	ls_cache[sid] = v or frame
	return v
end
local function layout_box(L, W, i)
	local a = W + 0x30 * i
	local v, fl = u32(a), u16(a + 0x12)
	local kind = fl >> 8
	if kind == 0xFA or kind == 0xAA then
		if inram(v, 1) then
			local s = clean(cstring(v, 80))
			if s ~= "" then return (s:gsub("^%l", string.upper)) end
		end
		local sid = u16(a + 0x0E)
		if sid ~= 0xFFFF then return layout_string(L, sid) end
	elseif (kind == 0xF8 or kind == 0xA8) and (fl & 0xFF) == 3 then
		return tostring(v)
	end
	return nil
end
-- The next fighter's command list can look exactly like the last one, so the menu reader
-- sees no change: say whose turn it is once the turn has moved on and held still.
battle_actor_since, battle_actor_seen = 0, nil
battle_actor_text, battle_actor_frame, battle_start_frame = nil, -1000, nil
function watch_battle_actor()
	if not in_battle() then battle_actor_said, battle_actor_seen, battle_start_frame = nil, nil, nil return end
	battle_start_frame = battle_start_frame or frame
	-- back at Fight / Examine / Flee: the first fighter's turn is news again
	if menu_raw_seen:find("<N=0>Fight</N>", 1, true) then battle_actor_said = nil end
	-- the list left over from the last battle is not this battle's
	if last_menu_frame <= battle_start_frame or frame - last_menu_frame < 20 then return end
	if battle_phase() ~= 3 or not menu_raw_seen:find("<N=0>Attack</N>", 1, true) then return end
	local who = battle_actor_name()
	if who ~= battle_actor_seen then battle_actor_seen, battle_actor_since = who, frame return end
	if not who or who == battle_actor_said or frame - battle_actor_since < 8 then return end
	if frame - last_menu_spoken < 8 then return end
	local cursor = tonumber(menu_raw_seen:match("<CURSOR=(%d+)>") or "")
	local items, count = parse_menu(menu_raw_seen)
	local it = cursor and items[cursor]
	if not it then return end
	battle_actor_said = who
	battle_actor_text, battle_actor_frame = describe_item(it, cursor, count), frame
	last_menu_spoken = frame
	say(turn_text(who) .. battle_actor_text, true)
end

EQUIP_POPUP = { Equip = true, Move = true, Discard = true, Cancel = true }
local function read_layout()
	local p = u32(LAYOUT_PTR)
	if p == 0 or not inram(p, 0x40) then lay_state = nil return end
	-- two layouts can be up at once (a list below, details above): the pointer follows the one
	-- drawn last, which may have no cursor. Then use the last one that had a cursor.
	local fallback_ok, using_fallback = true, false
	if u16(p - 4 + 0x36) == 0xFFFF and not lay_good then lay_good = 0x02389268 end   -- where the list usually is
	if u16(p - 4 + 0x36) == 0xFFFF and fallback_ok and lay_good and lay_good ~= p and inram(lay_good, 0x40) then
		local g = lay_good - 4
		local gs, gn = u16(g + 0x36), u16(g + 8)
		if gs ~= 0xFFFF and gn > 0 and gn < 1000 and inram(u32(g + 4), gn * 0x30) then p, using_fallback = lay_good, true end
	end
	local L = p - 4
	local W, count, sel = u32(L + 4), u16(L + 8), u16(L + 0x36)
	if sel ~= 0xFFFF then lay_good, lay_good_frame = p, frame end
	if count == 0 or count > 1000 or not inram(W, count * 0x30) then return end
	-- the cursor holds a box's id (+4), which is usually, but not always, its place in the array
	if sel >= count or u16(W + 0x30 * sel + 4) ~= sel then
		local found = nil
		for i = 0, count - 1 do if u16(W + 0x30 * i + 4) == sel then found = i break end end
		if not found then return end
		sel = found
	end
	-- a new message (the shopkeeper speaking again) means the same menu is news again
	-- (but not the list you just left, which stays in memory for a moment while the menu comes back)
	if lay_serial ~= dialogue_serial and not using_fallback then lay_serial, lay_skip, lay_state, lay_rearm = dialogue_serial, lay_state, nil, frame end
	local text = layout_box(L, W, sel)
	if not text then return end
	local a = W + 0x30 * sel
	local sx, sy = u16(a + 6), u16(a + 8)
	-- the boxes of one list are chained together: count them for "2 of 6"
	local first, guard = a, 0
	while guard < 60 do
		local pv = u32(first + 0x18)
		if not inram(pv, 0x30) or (pv - W) % 0x30 ~= 0 then break end
		first, guard = pv, guard + 1
	end
	local pos, total, it, last = 0, 0, first, sel
	guard = 0
	while it and guard < 60 do
		local id = (it - W) // 0x30
		if id > last then last = id end
		if layout_box(L, W, id) then
			total = total + 1
			if it == a then pos = total end
		end
		local nx = u32(it + 0x1C)
		if not inram(nx, 0x30) or (nx - W) % 0x30 ~= 0 then break end
		it, guard = nx, guard + 1
	end
	-- the boxes on this line that belong to it (a price, how many you have): they come right
	-- after the list. Only lists of names have them.
	local extra = {}
	if u16(a + 0x12) == 0xFA04 or (u16(a + 0x12) >> 8) == 0xAA then
		for i = last + 1, math.min(count - 1, last + 45) do
			local b = W + 0x30 * i
			local bx, by = u16(b + 6), u16(b + 8)
			if math.abs(by - sy) <= 1 and bx >= sx + 30 and u16(b + 0x0A) > 0 then
				local t = layout_box(L, W, i)
				if t then extra[#extra + 1] = { bx, t } end
			end
		end
	end
	local shop = layout_string(L, 5) == "Buy"
	table.sort(extra, function(x, y) return x[1] < y[1] end)
	local line = text
	for k, e in ipairs(extra) do
		local t = e[2]
		if shop and t:match("^%d+$") then t = t .. (k == 1 and " gold" or " held") end
		line = line .. ", " .. t
	end
	line = line:gsub("Lv%.,%s*(%d+)", "level %1")
	-- the little Equip / Move / Discard / Cancel list on the equipment screen stays in memory
	-- after it closes, and the list of who to equip then moves its old cursor
	if total == 4 and EQUIP_POPUP[text] then
		if not equip_popup_open and frame - (equip_popup_arm or -1000) < 60 then equip_popup_open = true end
		if not equip_popup_open then
			local w = equip_who_items and equip_who_items[pos - 1]
			if not w then return end
			line = w.text
		end
	end
	if total > 1 then line = line .. ", " .. pos .. " of " .. total end
	if line == lay_state then lay_pending = nil return end
	-- the list fills in over a few frames: wait until it holds still
	if line ~= lay_pending then lay_pending, lay_since = line, frame return end
	if frame - lay_since < 4 then return end
	-- the same line as before the shopkeeper spoke: wait a moment in case it is the old list
	if line == lay_skip and frame - lay_rearm < 90 then return end
	lay_skip = nil
	lay_state, lay_pending = line, nil
	if frame - last_dialogue_frame < 5 then queue(line) else say(line, true) end
end


------------------------------------------------------------------------------ record screens -
-- Battle Records (the item list and the like) are built from small "element" objects chained
-- together in memory: text boxes (function 0x021FE708) and cursor lists (function 0x021FE80C).
-- A list keeps the ids of the text boxes it moves over (+0x20 array, +0x24 count, +0x28 cursor).
-- A text box has its text at +0x20, or the number of a string in the screen's string table at
-- +0x38. The screen's string table is pointed to from 0x02108DC0.
UI_LIST_FN, UI_TEXT_FN, UI_STRINGS = 0x021FE80C, 0x021FE708, 0x02108DC0
ui = { lists = {}, texts = {}, table = nil, focus = nil, said = {}, checked = -1000 }
ui_cache, ui_cache_table = {}, nil
function ui_string(sid)
	local h = u32(UI_STRINGS)
	if h ~= ui_cache_table then ui_cache, ui_cache_table = {}, h end
	-- found strings are kept; a miss is only trusted for a second (the table may still be loading)
	local c = ui_cache[sid]
	if type(c) == "string" then return c end
	if type(c) == "number" and frame - c < 60 then return nil end
	local v = ui_string_raw(sid, h)
	ui_cache[sid] = v or frame
	return v
end
function ui_string_raw(sid, h)
	if not inram(h, 8) then return nil end
	local e, n = u32(h), u16(h + 4)
	if n > 500 or not inram(e, n * 8) then return nil end
	for k = 0, n - 1 do
		if u16(e + k * 8) == sid then
			local s = clean(cstring(u32(e + k * 8 + 4), 100))
			return s ~= "" and s or nil
		end
	end
	return nil
end
function ui_text(e)
	if not e or u32(e) ~= UI_TEXT_FN then return nil end
	local p = u32(e + 0x20)
	if inram(p, 1) then
		local s = clean(cstring(p, 100))
		if s ~= "" then return (s:gsub("^%l", string.upper)) end
		return nil
	end
	return ui_string(u16(e + 0x38))
end
function ui_scan()
	ui.lists, ui.texts, ui.focus = {}, {}, nil
	local from, len = 0x02380000, 0x40000
	local head = nil
	for off = 0, len - 4096, 4096 do
		-- a little at a time: this runs over several frames so the game does not stutter
		if off > 0 and coroutine.isyieldable() then coroutine.yield() end
		local t = read_bytes(from + off, 4096)
		for i = 1, #t - 3, 4 do
			if t[i + 3] == 0x02 and t[i + 2] == 0x1F and t[i + 1] == 0xE8 and t[i] == 0x0C then
				ui.lists[#ui.lists + 1] = from + off + i - 1
			end
		end
	end
	if #ui.lists == 0 then return end
	-- walk back along the chain from the first list to its first box
	local e, guard = ui.lists[1], 0
	while inram(e, 0x40) and guard < 400 do
		head = e
		local pv = u32(e + 0x14)
		if not inram(pv, 0x40) then break end
		e, guard = pv, guard + 1
	end
	ui.head = head
	-- the screen keeps a pointer to the chain's first box; 0x98 bytes further on is the id of
	-- the list that has the cursor
	for off = 0, len - 4096, 4096 do
		-- a little at a time: this runs over several frames so the game does not stutter
		if off > 0 and coroutine.isyieldable() then coroutine.yield() end
		local t = read_bytes(from + off, 4096)
		local b0, b1, b2, b3 = head & 0xFF, (head >> 8) & 0xFF, (head >> 16) & 0xFF, (head >> 24) & 0xFF
		for i = 1, #t - 3, 4 do
			if t[i] == b0 and t[i + 1] == b1 and t[i + 2] == b2 and t[i + 3] == b3 then
				local a = from + off + i - 1
				local f = u32(a - 0x14)          -- a box's own back link is not it
				if not (f >= 0x02000000 and f < 0x02400000 and f & 0xFFF00000 == 0x02100000) then ui.focus = a + 0x98 end
			end
		end
	end
end
function ui_describe(o)
	local n, cur, arr = u16(o + 0x24), u16(o + 0x28), u32(o + 0x20)
	if n == 0 or n > 64 or cur >= n or not inram(arr, n * 2) then return nil end
	local text = ui_text(ui.texts[u16(arr + cur * 2)])
	if not text then return nil end
	local pos, total = 0, 0
	for k = 0, n - 1 do
		if ui_text(ui.texts[u16(arr + k * 2)]) then
			total = total + 1
			if k == cur then pos = total end
		end
	end
	return total > 1 and (text .. ", " .. pos .. " of " .. total) or text
end
function read_ui_screen()
	-- a search for the screen's boxes that is still going on
	if ui.co then
		local ok = coroutine.resume(ui.co)
		if not ok or coroutine.status(ui.co) == "dead" then ui.co = nil end
		if ui.co then return end
	end
	if frame - ui.checked < 4 then return end
	ui.checked = frame
	local tbl = u32(UI_STRINGS)
	local hf = ui.head and u32(ui.head) or 0
	local valid = hf >= 0x021F0000 and hf < 0x02200000
	if tbl ~= ui.table or (ui.head and not valid) then
		ui.table = tbl
		ui.said, ui.head = {}, nil
		ui.co = coroutine.create(ui_scan)
		return
	end
	if not ui.head then return end
	-- boxes and lists come and go as the screen changes: walk the chain every time
	ui.lists, ui.texts = {}, {}
	local e, guard = ui.head, 0
	while inram(e, 0x40) and guard < 400 do
		local f = u32(e)
		if f == UI_TEXT_FN then ui.texts[u16(e + 6)] = e
		elseif f == UI_LIST_FN then ui.lists[#ui.lists + 1] = e end
		e, guard = u32(e + 0x18), guard + 1
	end
	if #ui.lists == 0 then ui.head = nil return end
	local focus = ui.focus and u16(ui.focus) or nil
	local pick, changed = nil, {}
	for _, o in ipairs(ui.lists) do
		if u32(o) == UI_LIST_FN then
			local line = ui_describe(o)
			local id = u16(o + 6)
			if line and line ~= ui.said[o] then
				changed[#changed + 1] = o
				if id == focus then pick = o end
			end
			ui.said[o] = line
		end
	end
	if not pick and #changed == 1 then pick = changed[1] end
	if not pick and #changed > 1 then
		-- no way to tell which one has the cursor: the one that moved, else the longest list
		local best = 0
		for _, o in ipairs(changed) do if u16(o + 0x24) > best then best, pick = u16(o + 0x24), o end end
	end
	if pick and (not focus or u16(pick + 6) == focus) then
		local line = ui.said[pick]
		if frame - last_dialogue_frame < 5 then queue(line) else say(line, true) end
	end
end


-- Battle Records (Stella's book): big picture buttons with no text in memory. The menu keeps a
-- small block: the ids of the buttons on show (+0, one byte each), how many (+8) and the cursor
-- (+0x28), followed by pointers back into itself (+0x2C = +0x14, +0x34 = +0x24, +0x38 = +0x28).
REC_LABELS = { [0] = "Defeated Monster List", "Wardrobe", "Item List", "Alchenomicon", "Accolades Earnt", "Guest List" }
rec = { addr = nil, until_frame = -1, last = nil, next_scan = 0 }
function rec_valid(m)
	return inram(m, 0x40) and u32(m + 0x38) == m + 0x28 and u32(m + 0x2C) == m + 0x14 and u32(m + 0x34) == m + 0x24
end
function read_records_menu(pad)
	if pad.a and not rec.pad_a and last_menu_item == "Battle Records" and frame - last_menu_spoken < 1200 then
		rec.until_frame, rec.addr, rec.last = frame + 400, nil, nil
	end
	rec.pad_a = pad.a
	if rec.addr and not rec_valid(rec.addr) then rec.addr, rec.last = nil, nil end
	if not rec.addr then
		if frame > rec.until_frame or frame < rec.next_scan then return end
		rec.next_scan = frame + 20
		local from, len = 0x02380000, 0x40000
		for off = 0, len - 4096, 4096 do
			local t = read_bytes(from + off, 4096)
			for i = 1, #t - 3, 4 do
				local x = from + off + i - 1
				if t[i + 3] == 0x02 and t[i] + t[i + 1] * 256 + t[i + 2] * 65536 + 0x02000000 == x - 0x10 then
					local m = x - 0x38
					if rec_valid(m) then rec.addr = m break end
				end
			end
			if rec.addr then break end
		end
		if not rec.addr then return end
	end
	local m = rec.addr
	-- one of the lists inside (the item list ...) is open: say the button again when you come back
	if ui.head then rec.last = nil return end
	local n, cur = u32(m + 8), u32(m + 0x28)
	if n == 0 or n > 8 or cur >= n then return end
	local label = REC_LABELS[u8(m + cur)] or ("option " .. (cur + 1))
	local line = label .. ", " .. (cur + 1) .. " of " .. n
	if line ~= rec.last then
		rec.last = line
		if frame - last_dialogue_frame < 5 then queue(line) else say(line, true) end
	end
end


-- Choices inside a conversation (Erinn's "Stay at the inn / Canvass for guests ..."): the message
-- that asks ends with <ADD> in the menu buffer, the choices are a "<N=0>...</N>" line among the
-- messages the game has loaded, and the cursor is copied to the player's record (+0x250), like
-- the yes or no answer.
choice = { sig = nil, items = nil, last = nil }
function find_choice_lists()
	local lists = {}
	local from, len = 0x0211C000, 0x24000
	for off = 0, len - 4096, 4096 do
		local t = read_bytes(from + off, 4096)
		for i = 1, #t - 5 do
			-- "<N=0>"
			if t[i] == 60 and t[i + 1] == 78 and t[i + 2] == 61 and t[i + 3] == 48 and t[i + 4] == 62 then
				local a = from + off + i - 1
				local sraw = cstring(a, 400)
				if not sraw:find("%s", 1, true) then
					local items = {}
					for txt in sraw:gmatch("<N=%d+>(.-)</N>") do items[#items + 1] = clean(txt) end
					if #items >= 2 then lists[#lists + 1] = items end
				end
			end
		end
	end
	return lists
end
function read_choice()
	local m = menu_raw_seen
	local asking = m:sub(-5) == "<ADD>" and (m:find("<PAGE>", 1, true) or m:find("//", 1, true) or m:find("<N_TURN>", 1, true))
	if not asking then choice.sig, choice.items, choice.last = nil, nil, nil return end
	-- the same question asked again (talking to Erinn twice) is a new question
	local sig = m .. "#" .. tostring(msg_serial)
	if sig ~= choice.sig then
		choice.sig, choice.last = sig, nil
		local lists = find_choice_lists()
		choice.items = #lists == 1 and lists[1] or nil
		choice.since, choice.ctl = frame, nil
	end
	if not choice.items then return end
	-- only while the question itself is on screen (not the pages before it, not the reply after)
	local q = m:gsub("<ADD>$", ""):match(".*<PAGE>(.*)$") or m:gsub("<ADD>$", "")
	local nq = clean(q):gsub("[^%a]", ""):sub(-15)
	local pg = cstring(u32(PAGE_START), 400)
	local cut = pg:find("\13\255", 1, true)
	if cut then pg = pg:sub(1, cut - 1) end
	local nd = clean(pg):gsub("[^%a]", "")
	if nq == "" or nd:sub(-#nq) ~= nq then return end
	-- wait until the question has been written out
	if frame - choice.since < 20 then return end
	-- the window's own cursor: a small block that points back into itself (+0x24 = +0x0C,
	-- +0x2C = +0x1C, +0x30 = +0x20), with the count at +4 and the cursor at +0x20
	if choice.items and not choice.ctl and frame >= (choice.next_scan or 0) and frame - choice.since < 300 then
		choice.next_scan = frame + 15
		local from, len = 0x02380000, 0x40000
		for off = 0, len - 4096, 4096 do
			local t = read_bytes(from + off, 4096)
			for i = 1, #t - 3, 4 do
				local x = from + off + i - 1
				if t[i + 3] == 0x02 and t[i] + t[i + 1] * 256 + t[i + 2] * 65536 + 0x02000000 == x - 0x10 then
					local c = x - 0x30
					if u32(c + 0x24) == c + 0x0C and u32(c + 0x2C) == c + 0x1C and u32(c + 4) == #choice.items then
						choice.ctl = c break
					end
				end
			end
			if choice.ctl then break end
		end
	end
	if not choice.ctl and frame - choice.since < 140 then return end
	local cur
	if choice.ctl and u32(choice.ctl + 0x30) == choice.ctl + 0x20 then
		cur = u32(choice.ctl + 0x20)
	else
		local player = u32(PLAYER_PTR)
		cur = inram(player, 0x260) and u8(player + 0x250) or 0
	end
	local n = #choice.items
	if cur >= n then return end
	local line = choice.items[cur + 1] .. ", " .. (cur + 1) .. " of " .. n
	if line ~= choice.last then
		local first = choice.last == nil
		-- the window can still hold the last cursor for a moment when it opens: the first
		-- reading must hold still for a quarter of a second
		if first then
			if line ~= choice.pending then choice.pending, choice.pending_at = line, frame return end
			if frame - choice.pending_at < 15 then return end
		end
		choice.last, choice.pending = line, nil
		if first then queue(line) else say(line, true) end
	end
end


-- Create a companion (Patty's): eight steps across the top (a row of tabs) and big buttons
-- below. Both are one grid control that changes shape: columns +8, rows +0xC, cursor column
-- +0x18 and row +0x1C, with pointers back to its own rows and columns at +0x20 and +0x24.
-- Only the gender buttons have words; the others are pictures, so they are read as numbers.
CREATE_STEPS = { "Gender", "Body type", "Hairstyle", "Hair colour", "Face", "Skin colour", "Eye colour", "Name" }
create = { grid = nil, next_scan = 0, last = nil, step = 1, said_title = false }
HERO_CREATE_GRID = 0x022A517C
function create_grid_ok(g)
	return inram(g, 0x28) and u32(g + 0x20) == g + 0x0C and u32(g + 0x24) == g + 0x08
end
function read_create()
	-- Patty's screens load her own string table ("Recruit a Friend" is string 5)
	if ui_string(5) ~= "Recruit a Friend" then
		-- making your own hero after "Create a new adventure log": its picture list lives here
		if cstring(MAPCODE, 12) == "" and u32(PLAYER_PTR) == 0 and create_grid_ok(HERO_CREATE_GRID) then
			create.grid = HERO_CREATE_GRID
			-- after the name: "Begin your adventure with this character?", drawn from text the
			-- game does not keep, so say it here along with the answer the cursor is on
			local yn = menu_raw_seen:find("<N=0>Yes</N>", 1, true) ~= nil
			if yn and create.step == 8 and not create.asked then
				create.asked = true
				local c = tonumber(menu_raw_seen:match("<CURSOR=(%d+)>") or "0") or 0
				say("Begin your adventure with this character? " .. (c == 0 and "Yes, 1 of 2" or "No, 2 of 2"), true)
				-- the menu reader need not say the answer again
				menu_raw_done, menu_sig, menu_cursor = menu_raw_seen, (menu_raw_seen:gsub("<CURSOR=%d+>", "")), c
				return
			elseif not yn and menu_raw_seen:match("^<X=%d+>[^<]*%*") then create.asked = false end   -- back at the keyboard
			local g = create.grid
			local cols, rows, cx, cy = u32(g + 8), u32(g + 0xC), u32(g + 0x18), u32(g + 0x1C)
			if cols == 0 or rows == 0 or cols > 12 or rows > 12 or cx >= cols or cy >= rows then return end
			-- Male or Female: the list at the top only shows the choice for a moment, so say it here
			if not (cols == 1 and rows == 2) then create.last = nil return end
			local line = "Gender: " .. (cy == 0 and "Male" or "Female") .. ", " .. (cy + 1) .. " of 2"
			if line ~= create.last then
				create.last = line
				creation_last = "Gender: " .. (cy == 0 and "Male" or "Female")
				say(line, true)
			end
			return
		end
		create.grid, create.last, create.said_title = nil, nil, false
		return
	end
	if create.grid and not create_grid_ok(create.grid) then create.grid = nil end
	if not create.grid and create_grid_ok(0x023107A8) then create.grid = 0x023107A8 end   -- where it usually is
	if not create.grid then
		if frame < create.next_scan then return end
		create.next_scan = frame + 150
		local from, len = 0x02300000, 0x40000
		for off = 0, len - 4096, 4096 do
			local t = read_bytes(from + off, 4096)
			for i = 1, #t - 7, 4 do
				local x = from + off + i - 1
				if t[i + 3] == 0x02 and t[i] + t[i + 1] * 256 + t[i + 2] * 65536 + 0x02000000 == x - 0x14 then
					if u32(x + 4) == x - 0x18 then create.grid = x - 0x20 break end
				end
			end
			if create.grid then break end
		end
		if not create.grid then return end
	end
	local g = create.grid
	-- the last question ("Add this character to your character list?") is drawn from text the
	-- game does not keep, so say it here when the yes or no box comes up after the name
	local yn = menu_raw_seen:find("<N=0>Yes</N>", 1, true) ~= nil
	if yn and create.step == 8 and not create.asked then
		create.asked = true
		queue("Add this character to your character list?")
	elseif not yn then create.asked = false end
	-- which step: the highlighted line of the list at the top (palette 14)
	if menu_raw_seen:match("^<X=%d+>[^<]*%*+$") then create.step = 8 end   -- the name being typed
	if menu_raw_seen:match("^<PLTT=1[45]>") then
		local i = 0
		for pltt in menu_raw_seen:gmatch("<PLTT=(%d+)>") do
			i = i + 1
			if pltt == "14" then create.step = i end
		end
	end
	local cols, rows, cx, cy = u32(g + 8), u32(g + 0xC), u32(g + 0x18), u32(g + 0x1C)
	if cols == 0 or rows == 0 or cols > 12 or rows > 12 or cx >= cols or cy >= rows then return end
	local line
	if cols == 8 and rows == 1 then
		create.step = cx + 1
		line = CREATE_STEPS[cx + 1] .. ", step " .. (cx + 1) .. " of 8"
		if not create.said_title then line = "Create a companion. " .. line create.said_title = true end
	else
		local idx, n = cy * cols + cx, cols * rows
		-- the other steps are said by the list at the top, which shows each picture's name
		if not (create.step == 1 and n == 2) then create.last = nil return end
		line = (idx == 0 and "Male" or "Female") .. ", " .. (idx + 1) .. " of " .. n
	end
	if line ~= create.last then
		create.last = line
		say(line, true)
	end
end

function equip_shaped(b)
	local p1, p2 = u32(b + 0x20), u32(b + 0x24)
	return p1 ~= p2 and (p1 == b + 8 or p1 == b + 0xC) and (p2 == b + 8 or p2 == b + 0xC)
end
equip_grid, equip_next_scan = nil, 0

-- The top screen's box of numbers ("Attack 25 -> 34"). It is a small tree of parts:
-- a table of nodes (0x18 bytes: key, parent, first child, previous, next, shown flag)
-- followed by a list of part ids and then the parts (0x14 bytes: id, type, x, y, value).
-- Parts: 8-11 names of the numbers; 12,14,15,16 the number now (for what is worn);
-- 38-41 the number now, 42-45 the number with the highlighted thing; 35 "Cannot Equip".
function stat_panel_ok(s)
	local nodes, parts, n = u32(s), u32(s + 4), u16(s + 0xC)
	if n ~= 57 or u16(s + 0xE) ~= 42 then return false end
	if parts ~= nodes + n * 0x1C or not inram(parts, 42 * 0x14) then return false end
	return u16(parts + 0x14 * 27) == 38 and u16(parts + 0x14 * 27 + 4) == 122
end
stat_panel, stat_panel_pos = nil, 0
-- looked for a little at a time (64 KB a frame) so the game does not stutter
function find_stat_panel()
	if stat_panel and stat_panel_ok(stat_panel) then return stat_panel end
	stat_panel = nil
	local from, len = 0x02300000, 0x100000
	local base = from + stat_panel_pos
	stat_panel_pos = (stat_panel_pos + 0x10000) % len
	for off = 0, 0x10000 - 4096, 4096 do
		local t = read_bytes(base + off, 4096)
		for i = 1, #t - 3, 4 do
			-- 57 nodes, 42 parts
			if t[i] == 57 and t[i + 1] == 0 and t[i + 2] == 42 and t[i + 3] == 0 then
				local s = base + off + i - 1 - 0xC
				if stat_panel_ok(s) then stat_panel = s return s end
			end
		end
	end
	return nil
end
function stat_panel_read()
	local s = find_stat_panel()
	if not s then return nil end
	local nodes, n = u32(s), 57
	local ids = nodes + n * 0x18
	local parts = ids + n * 4
	local node_of, by_key, part_of = {}, {}, {}
	for k = 0, n - 1 do
		local nd = nodes + k * 0x18
		by_key[u16(nd)] = nd
		local p = u32(nd + 4)
		if inram(p, 2) and u16(nd + 2) == 1 then node_of[u16(p)] = nd end
	end
	for k = 0, 41 do local a = parts + k * 0x14 part_of[u16(a)] = a end
	local function shown(id)
		local nd, guard = node_of[id], 0
		if not nd then return false end
		while nd and guard < 20 do
			-- the box itself (key 0x0B) is shown whatever its flag says
			if u16(nd) == 0x0B then return true end
			if (u8(nd + 0x16) & 1) == 0 then return false end
			-- the parent is kept on the first child only
			local g2 = 0
			while u16(nd + 0x10) ~= 0 and g2 < 20 do nd, g2 = by_key[u16(nd + 0x10)], g2 + 1 if not nd then return true end end
			local up = u16(nd + 0xC)
			if up == 0 then return true end
			nd, guard = by_key[up], guard + 1
		end
		return true
	end
	local function value(id)
		local a = part_of[id]
		if not a then return nil end
		local kind, v = u8(a + 3), u32(a + 0xC)
		if (kind & 0xF) == 8 and u8(a + 2) == 2 then return tostring(v), kind >> 4 end
		if inram(v, 1) then
			local t = clean(cstring(v, 40))
			if t ~= "" and not t:match("^<") then return t, kind >> 4 end
		end
		return nil
	end
	if shown(35) then return "cannot equip" end
	local out = {}
	local worn = false
	for r = 0, 3 do
		local name = shown(8 + r) and value(8 + r)
		if name then
			local now_id = ({ 12, 14, 15, 16 })[r + 1]
			if shown(38 + r) and shown(42 + r) then
				local a, b = value(38 + r), value(42 + r)
				local na, nb = tonumber(a), tonumber(b)
				if na and nb then
					local d = nb - na
					local how = d > 0 and ("up " .. d) or d < 0 and ("down " .. -d) or "no change"
					out[#out + 1] = name .. " " .. how .. ", " .. a .. " to " .. b
				elseif a and b then
					out[#out + 1] = name .. " " .. a .. " to " .. b
				end
			elseif shown(now_id) then
				local a = value(now_id)
				if a then out[#out + 1] = name .. " " .. a worn = true end
			end
		end
	end
	if #out == 0 then return nil end
	return (worn and "equipped, " or "") .. table.concat(out, ", ")
end

local function read_equip_screen()
	-- straight from "Equip" in the menu, or from the list of who to equip (a party of more than one)
	local it = menu_items[menu_cursor]
	local popup_left = menu_items[0] and menu_items[0].text == "Equip" and menu_items[2] and menu_items[2].text == "Discard"
	local came_from_menu = equip_popup_open or popup_left or (it and (it.text == "Equip" or menu_title == "Equip"))
	if menu_title == "Equip" and it and not equip_popup_open then equip_who_name = it.text end
	if it and it.text == "Equip" and menu_title ~= "Equip" and not popup_left then equip_who_name = nil end
	if not came_from_menu then equip_cursor, equip_state, equip_due = nil, nil, nil return end
	-- the control is not always at the same place (it moves with the size of the party)
	local b = equip_grid
	if not (b and equip_shaped(b)) then
		b = nil
		if equip_shaped(EQUIP_LIST) then b = EQUIP_LIST
		elseif frame >= equip_next_scan then
			equip_next_scan = frame + 60
			local from, len = 0x02300000, 0x80000
			for off = 0, len - 4096, 4096 do
				local t = read_bytes(from + off, 4096)
				for i = 1, #t - 7, 4 do
					local x = from + off + i - 1
					if t[i + 3] == 0x02 and t[i + 7] == 0x02 then
						local c = x - 0x20
						if equip_shaped(c) then
							local cols, rows = u32(c + 8), u32(c + 12)
							if (cols == 1 and rows == 8) or (cols == 8 and rows == 1) or (cols >= 1 and cols <= 8 and rows >= 1 and rows <= 8) then b = c break end
						end
					end
				end
				if b then break end
			end
		end
		equip_grid = b
	end
	if not b then equip_cursor, equip_state, equip_due = nil, nil, nil return end
	local shown = b - 0x40                 -- number of the item the top screen is showing
	-- the control is a grid: columns, rows, then the cursor's column and row
	local cols, rows, cx, cy = u32(b + 8), u32(b + 12), u32(b + 0x18), u32(b + 0x1C)
	local mode = (cols == 1 and rows == 8) and "slots" or (cols == 8 and rows == 1) and "tabs" or "grid"
	local state = mode .. cx .. "," .. cy
	-- what the highlighted thing does to the numbers, said once the top screen has caught up
	-- (the box empties a few frames after the cursor moves and is filled again after about ten)
	if equip_stats_due then
		if state ~= equip_stats_state or frame > equip_stats_due + 60 then
			equip_stats_due = nil
		elseif frame >= equip_stats_due then
			local st = stat_panel_read()
			if not st then equip_stats_blank = true
			elseif equip_stats_blank or frame >= equip_stats_due + 12 then
				say(st, false)
				equip_stats_due = nil
			end
		end
	end
	if state ~= equip_state then
		-- back out of the list of things to put on: the top screen takes a moment to show the slot again
		local wait = (equip_state and equip_state:sub(1, 4) == "grid" and mode ~= "grid") and 14 or 3
		equip_state, equip_due = state, frame + wait
		return
	end
	if not equip_due or frame < equip_due then return end
	equip_due = nil
	local who = party_records()[1]
	if equip_who_name then
		for _, r in ipairs(party_records()) do if r.name == equip_who_name then who = r end end
	end
	if mode == "grid" then
		local nm = item_name(u16(shown))
		say((nm or "empty space") .. ", row " .. (cy + 1) .. ", column " .. (cx + 1), true)
		if nm then equip_stats_due, equip_stats_state, equip_stats_blank = frame, state, false else equip_stats_due = nil end
		return
	end
	local c = (mode == "slots") and cy or cx
	if c > 7 then return end
	local first = equip_cursor == nil
	equip_cursor = c
	local slot = EQUIP_SCREEN_SLOTS[c + 1]
	local item = item_name(u16(shown))
	if not item and who and slot[1] then
		local n = clean(cstring(who.addr + 0x534 + slot[1] * 0x30, 0x30))
		if n ~= "" and printable(n) then item = n end
	end
	item = item or "nothing equipped"
	local text = slot[2] .. ": " .. item .. ", " .. (c + 1) .. " of 8"
	if mode == "tabs" then text = text .. ". Down for things you can put on" end
	if first then say("Equipment" .. (who and (" for " .. who.name) or "") .. ". " .. text, true) else say(text, true) end
end

-- The attributes: kept in the character's record as three words of three 10-bit numbers each.
local function attributes_of(r)
	local n = r.addr
	local w1, w2, w3 = u32(n + 0x8E0), u32(n + 0x8E4), u32(n + 0x8E8)
	local f = function(w, k) return (w >> (10 * k)) & 0x3FF end
	local voc = VOCATIONS[r.voc] or ""
	local parts = { r.name .. (voc ~= "" and (", " .. voc) or "") .. (r.level and (", level " .. r.level) or "") }
	parts[#parts + 1] = "Experience " .. u32(n + 0x114)
	parts[#parts + 1] = "Strength " .. f(w1, 0)
	parts[#parts + 1] = "Agility " .. f(w1, 1)
	parts[#parts + 1] = "Resilience " .. f(w1, 2)
	parts[#parts + 1] = "Deftness " .. f(w2, 0)
	parts[#parts + 1] = "Charm " .. f(w2, 1)
	parts[#parts + 1] = "Magical mending " .. f(w2, 2)
	parts[#parts + 1] = "Magical might " .. f(w3, 0)
	parts[#parts + 1] = "Max HP " .. r.maxhp
	parts[#parts + 1] = "Max MP " .. r.maxmp
	parts[#parts + 1] = "Attack " .. u16(n + 0x34)
	parts[#parts + 1] = "Defence " .. u16(n + 0x36)
	return table.concat(parts, ". ")
end
local function say_attributes(only)
	local out = {}
	for _, r in ipairs(party_records()) do
		if not only or r.name == only then out[#out + 1] = attributes_of(r) end
	end
	say(#out > 0 and table.concat(out, ". Next, ") or "No party information.", true)
end

-- Picking someone in the Attributes menu opens a picture of their attributes: read it out.
local attr_due, attr_who, pad_prev_a = nil, nil, false
pad_prev_a2 = false
local function watch_attributes(pad)
	if pad.a and not pad_prev_a and menu_title == "Attributes" and menu_items[menu_cursor] then
		local who = menu_items[menu_cursor].text
		attr_due, attr_who = frame + 50, (who ~= "Whole Party") and who or nil
	end
	pad_prev_a = pad.a
	if attr_due and frame >= attr_due then
		attr_due = nil
		say_attributes(attr_who)
	end
end

local function say_gold()
	local g = u32(0x020F6D48)
	if g > 9999999 then say("Gold unknown.") return end
	say(g .. " gold")
end

local function say_where()
	local code = map_code()
	local px, py, pz = player_pos()
	local s = (settled and map_key(settled.code) == map_key(code) and settled.label) or map_name() or "Unknown place"
	if room_name() and map_name() then s = map_name() .. ", " .. room_name() end
	if px then
		local ex, sz = math.floor(px + 0.5), math.floor(pz + 0.5)
		s = s .. ". " .. (ex < 0 and ("west " .. -ex) or ("east " .. ex)) .. ", " ..
			(sz < 0 and ("north " .. -sz) or ("south " .. sz))
	end
	say(s)
end

------------------------------------------------------------------------------ debug ---------
local function hexdump(s)
	return (s:gsub(".", function(c)
		local b = c:byte()
		if b >= 32 and b < 127 then return c end
		return string.format("\\x%02X", b)
	end))
end
local function capture()
	local f = io.open(LOG_FILE, "a")
	if not f then say("Could not write the log.") return end
	f:write("==== frame " .. frame .. " " .. os.date() .. "\n")
	f:write("map " .. tostring(map_code()) .. " / " .. tostring(map_name()) .. "\n")
	local px, py, pz = player_pos()
	f:write(string.format("pos %s %s %s  battle %s\n", tostring(px), tostring(py), tostring(pz), tostring(in_battle())))
	f:write("dialogue " .. hexdump(cstring(DLG, 1200)) .. "\n")
	f:write(string.format("page %08X %08X\n", u32(PAGE_START), u32(PAGE_END)))
	f:write("menu " .. hexdump(cstring(MENU, 2400)) .. "\n")
	f:write(string.format("yesno %08X %d choice %d event %d %d\n", u32(yesno_obj), u8(yesno_obj + 0x28), u8(u32(PLAYER_PTR) + 0x250), u32(EVENT_CHOICE_COUNT), u32(EVENT_CHOICE_CURSOR)))
	for _, c in ipairs(characters()) do f:write(string.format("obj %08X %.2f %.2f\n", c.obj, c.x, c.z)) end
	-- the screen's boxes of words and numbers, when the screen is built from them
	pcall(function()
		local lp = u32(LAYOUT_PTR)
		if lp ~= 0 and inram(lp, 0x40) then
			local L = lp - 4
			local W, count, sel = u32(L + 4), u16(L + 8), u16(L + 0x36)
			f:write(string.format("layout %08X widgets %08X count %d selected %d\n", L, W, count, sel))
			for i = 0, math.min(count, 600) - 1 do
				local a = W + 0x30 * i
				local t = layout_box(L, W, i)
				if t then f:write(string.format("  %d x%d y%d w%d fl%04X %s\n", i, u16(a + 6), u16(a + 8), u16(a + 0x0A), u16(a + 0x12), t)) end
			end
		end
	end)
	f:write(string.format("equip %d %d %d %d shown %d\n", u32(EQUIP_LIST), u32(EQUIP_LIST + 8), u32(EQUIP_LIST + 0x18), u32(EQUIP_LIST + 0x1C), u16(EQUIP_SHOWN)))
	f:write("last said: " .. last_said .. "\n\n")
	f:close()
	say("Snapshot saved.")
end

------------------------------------------------------------------------------ keys ----------
local keys_prev = {}
local controller_pressed = false      -- a button on a game controller went down this frame
-- Names of controller buttons as EmuHawk reports them (X1 = first Xbox controller; J1 = other pads)
local function pad_name(k, names)
	if type(k) ~= "string" or not (k:match("^X%d ") or k:match("^J%d ")) then return false end
	local rest = k:gsub("^%u%d ", ""):lower()
	for _, n in ipairs(names) do if rest == n then return true end end
	return false
end
LT_NAMES = { "lefttrigger", "triggerleft", "lt", "z+" }
L3_NAMES = { "leftthumb", "leftstick", "ls", "l3", "b9" }
R3_NAMES = { "rightthumb", "rightstick", "rs", "r3", "b10" }
DPAD = {
	up = { "dpadup", "dpup", "pov1u" }, down = { "dpaddown", "dpdown", "pov1d" },
	left = { "dpadleft", "dpleft", "pov1l" }, right = { "dpadright", "dpright", "pov1r" },
}
local lt_held = false
local seen_pad_names = {}
local function key_edges()
	local ok, now = pcall(function() return input.get() end)
	if not ok or type(now) ~= "table" then return {} end
	local pressed = {}
	controller_pressed = false
	lt_held = false
	for k, v in pairs(now) do
		if v and pad_name(k, LT_NAMES) then lt_held = true end
	end
	for k, v in pairs(now) do
		if v and not keys_prev[k] then
			pressed[k] = true
			if type(k) == "string" and (k:match("^X%d ") or k:match("^J%d ")) then
				-- the left trigger and the combinations made with it do not take over from auto walk
				if not lt_held and not pad_name(k, LT_NAMES) and not pad_name(k, R3_NAMES) then controller_pressed = true end
				if not seen_pad_names[k] then seen_pad_names[k] = true log_line("controller button: " .. k) end
			end
		end
	end
	keys_prev = now
	return pressed
end
local function pad_edge(pressed, names)
	for k in pairs(pressed) do if pad_name(k, names) then return true end end
	return false
end

-- Left trigger combinations on the controller:
--   LT + right / left on the D-pad: next / previous category of nearby things
--   LT + down / up on the D-pad: next / previous thing in that category
--   LT + pressing in the left stick: walk to the thing you picked
local function handle_pad_combos(k)
	-- pressing in the right stick: gold, or health and magic in a battle
	-- pressing in the right stick: the route to the thing picked on the list (gold when nothing
	-- is picked, or with the left trigger held), or health and magic in a battle
	if pad_edge(k, R3_NAMES) then
		if in_battle() then say_party()
		elseif not lt_held and sel_item and sel_item.code == map_code() then route_request()
		else say_gold() end
	end
	if not lt_held then return end
	-- keep the D-pad away from the game while the trigger is held
	pcall(function() joypad.set({ Up = false, Down = false, Left = false, Right = false }) end)
	if pad_edge(k, DPAD.right) then step_category(1) end
	if pad_edge(k, DPAD.left) then step_category(-1) end
	if pad_edge(k, DPAD.down) then step_nearby(1) end
	if pad_edge(k, DPAD.up) then step_nearby(-1) end
	if pad_edge(k, L3_NAMES) then if walk then stop_walk("Stopped.") else start_walk() end end
end

------------------------------------------------------------------------------ route ---------
-- Spoken directions along the planned route to the thing picked on the list: the same planner
-- as walking there, but you walk it yourself. "Up" and "left" are as on screen right now.
route = nil
function route_request()
	local it = sel_item
	if not it then say("Pick something on the list first.") return end
	if it.code and it.code ~= map_code() then say("Pick something here first.") return end
	local px, py, pz = player_pos()
	if not px then say("Cannot plan a route right now.") return end
	local nv = nav_for()
	if not nv then say(it.label .. ", " .. directions_to(it.x, it.z) .. ". There is no map of the walls here to plan a route.", true) return end
	nv.bb = {}
	local gx, gz = it.x, it.z
	if it.nx then
		-- a door: go to just in front of it, on your side
		local sgn = ((px - it.x) * it.nx + (pz - it.z) * it.nz) >= 0 and 1 or -1
		if it.facing then sgn = 1 end
		gx, gz = it.x + it.nx * sgn * 1.2, it.z + it.nz * sgn * 1.2
	end
	if math.sqrt((gx - px) ^ 2 + (gz - pz) ^ 2) < 1.2 then
		say(it.label .. " is " .. directions_to(it.x, it.z) .. ".", true)
		return
	end
	local avoid = avoid_list(it.x, it.z, px, pz)
	nv.py = select(2, player_pos())
	route = { it = it, sx = px, sz = pz, gx = gx, gz = gz, start = frame,
		co = coroutine.create(function()
			local p, rem = plan_path(nv, px, py, pz, gx, gz, it.y0 and (it.y0 + 1) or nil, 0.45, true, 20000, avoid)
			if rem > 1.5 then
				local p2, rem2 = find_path(nv, px, pz, gx, gz, 0.3, false, 20000, avoid)
				if rem2 < rem - 1 then p, rem = p2, rem2 end
			end
			return p, rem
		end) }
end
local function dirs_between(fx, fz, tx, tz)
	local ux, uz, rx, rz = screen_axes()
	local dx, dz = tx - fx, tz - fz
	local f, r = dx * ux + dz * uz, dx * rx + dz * rz
	local a = steps(f, f >= 0 and "up" or "down")
	local b = steps(r, r >= 0 and "right" or "left")
	if a and b then return math.abs(f) >= math.abs(r) and (a .. ", " .. b) or (b .. ", " .. a) end
	return a or b
end
function route_step()
	if not route then return end
	local ok, p, rem = plan_resume(route.co)
	if not ok then route = nil say("Could not plan a route.") return end
	if coroutine.status(route.co) ~= "dead" then
		if frame - route.start > 1800 then route = nil say("Could not plan a route.") end
		if frame - route.start == 90 then queue("Working out the route.") end
		return
	end
	local r = route
	route = nil
	local ux, uz, rx, rz = screen_axes()
	local pts = { { r.sx, r.sz } }
	for _, q in ipairs(p or {}) do pts[#pts + 1] = q end
	-- each leg: straight up, down, left or right, or a diagonal
	local legs = {}
	local function add(kind, n, n2)
		local last = legs[#legs]
		if last and last.kind == kind then last.n, last.n2 = last.n + n, (last.n2 or 0) + (n2 or 0)
		else legs[#legs + 1] = { kind = kind, n = n, n2 = n2 } end
	end
	for i = 2, #pts do
		local dx, dz = pts[i][1] - pts[i - 1][1], pts[i][2] - pts[i - 1][2]
		local f, s = dx * ux + dz * uz, dx * rx + dz * rz
		local af, as = math.abs(f), math.abs(s)
		local v, h = f >= 0 and "up" or "down", s >= 0 and "right" or "left"
		if af >= 0.2 or as >= 0.2 then
			if as < 0.4 * af then add(v, af)
			elseif af < 0.4 * as then add(h, as)
			elseif math.abs(af - as) < 0.35 * math.max(af, as) then add(v .. " and " .. h, math.max(af, as))
			elseif af > as then add(v, af) add(h, as)
			else add(h, as) add(v, af) end
		end
	end
	local words = {}
	for _, l in ipairs(legs) do
		local n = math.floor(l.n + 0.5)
		if n >= 1 then
			if l.kind:find(" and ") then
				words[#words + 1] = n .. (n == 1 and " step " or " steps ") .. "diagonally " .. l.kind
			else
				words[#words + 1] = steps(l.n, l.kind)
			end
		end
	end
	local label = r.it.label
	local tail
	local last = pts[#pts]
	if (rem or 0) > 1.5 then
		local rest = dirs_between(last[1], last[2], r.it.x, r.it.z)
		tail = "that is as close as the way goes" .. (rest and (". " .. label .. " is then " .. rest) or "")
	elseif r.it.nx or r.it.kind == 1 then
		tail = r.it.kind == 1 and "then walk into the door" or "then walk on through"
	else
		tail = "then you are there"
	end
	if #words == 0 then say(label .. ": " .. tail .. ".", true) return end
	local more = ""
	if #words > 8 then
		for i = #words, 9, -1 do table.remove(words, i) end
		more = ", and after that press again for the rest"
		tail = nil
	end
	say("Route to " .. label .. ": " .. table.concat(words, ", then ") .. (tail and (", " .. tail) or more) .. ".", true)
end

HELP = "R repeat. Q stop. W where am I. H party. S attributes. E equipment. G gold. I last information. O all menu options. " ..
	"N and B, next and previous nearby thing. V next category. D directions again. P route there. J walk there. M mark this spot. " ..
	"T alerts on or off. C save a debug snapshot. K keys. " ..
	"On the controller, hold the left trigger: D-pad right and left change category, down and up go through the things in it, " ..
	"and pressing in the left stick walks there. Pressing in the right stick gives the route to the thing you picked, step by step, " ..
	"or your gold when nothing is picked or the left trigger is held, or health and magic in a battle. P also gives the route."

local function handle_keys()
	local k = key_edges()
	handle_pad_combos(k)
	if k[KEYS.repeat_last] then say(last_said) end
	if k[KEYS.stop] then stop_speech() end
	if k[KEYS.where] then say_where() end
	if k[KEYS.party] then say_party() end
	if k[KEYS.gold] then say_gold() end
	if k[KEYS.equipment] then say_equipment() end
	if k[KEYS.stats] then say_attributes() end
	if k[KEYS.info] then say(last_info ~= "" and last_info or "No information yet.") end
	if k[KEYS.options] then read_all_options() end
	if k[KEYS.next_thing] then step_nearby(1) end
	if k[KEYS.category] then step_category(1) end
	if k[KEYS.prev_thing] then step_nearby(-1) end
	if k[KEYS.directions] then
		if nearby[selected] then
			local it = nearby[selected]
			say(it.label .. ", " .. directions_to(it.x, it.z))
		else say("Press N to pick something first.") end
	end
	if k[KEYS.mark] then
		local code = map_code()
		local x, _, z = player_pos()
		if code and x then
			local n = 1
			for _, p in ipairs(places) do if p.code == place_key() and p.kind == "mark" then n = n + 1 end end
			add_place(place_key(), "mark", x, z, "mark " .. n)
			say("Marked, mark " .. n)
		else say("Cannot mark here.") end
	end
	if k[KEYS.walk] then if walk then stop_walk("Stopped.") else start_walk() end end
	if k[KEYS.route] then route_request() end
	if k[KEYS.alerts] then
		ALERTS_ON = not ALERTS_ON
		say(ALERTS_ON and "Alerts on" or "Alerts off")
	end
	if k[KEYS.capture] then capture() end
	if k[KEYS.help] then say(HELP) end
end

------------------------------------------------------------------------------ start ---------
local function game_ok()
	local ok, code = pcall(function()
		local c = {}
		for i = 0, 3 do c[#c + 1] = string.char(memory.read_u8(0x0C + i, "ROM")) end
		return table.concat(c)
	end)
	if ok and code == "YDQE" then return true end
	local ok2, name = pcall(function() return gameinfo.getromname() end)
	return ok2 and type(name) == "string" and name:lower():find("dragon quest ix", 1, true) ~= nil
end

if not game_ok() then
	say("This script is for Dragon Quest 9, US version. Load that game first, then open the script again.")
	return
end

load_places()
menu_raw_done = cstring(MENU, 2400)     -- do not read out a menu left over from before the script started
menu_raw_seen, menu_seen_count = menu_raw_done, 2
-- the message buffer keeps the last message after its box closes, so do not read it out at start
do
	local raw = cstring(DLG, 1200)
	dlg_last_raw = raw
	local offset = u32(PAGE_START) - DLG
	dlg_last_page = 1
	if raw ~= "" and offset > 0 and offset < #raw then
		for k, pg in ipairs(split_pages(raw)) do if offset + 1 >= pg[1] then dlg_last_page = k end end
	end
	dlg_sig = table.concat(read_bytes(DLG, 48), ",") .. ":" .. u32(PAGE_START) .. ":" .. u32(PAGE_END)
end
say("Dragon Quest 9 access is running. Press K for keys.")
pcall(function() event.onexit(function() stop_speech() end) end)
local last_error = nil

while true do
	frame = frame + 1
	local pad = pad_state()
	for _, n in ipairs({ "a", "b", "x", "y", "start", "select", "up", "down", "left", "right", "l", "r" }) do
		if pad[n] and not pad_prev[n] then last_button_frame, last_button_name = frame, n end
	end
	-- A on something in the equipment list opens its little Equip / Move / Discard list; A or B there closes it
	if last_button_frame == frame and (last_button_name == "a" or last_button_name == "b") then
		if equip_popup_open then equip_popup_open, equip_popup_arm = false, nil
		elseif last_button_name == "a" and equip_state and equip_state:sub(1, 4) == "grid" then equip_popup_arm = frame end
	end
	pad_prev = pad

	local ok, err = pcall(function()
		-- remember experience only out in the world with no message up (the reward is added
		-- while the battle's closing messages are still showing)
		if battle_phase() ~= round_phase then
			if battle_phase() == 3 then battle_round = battle_round + 1 end
			round_phase = battle_phase()
		end
		if in_battle() then
			battle_seen_frame, exp_frozen = frame, true
		elseif exp_frozen then
			-- after a battle, wait until you are walking again (or the reward has been read)
			local px, _, pz = player_pos()
			if px and not exp_freeze_pos then exp_freeze_pos = { px, pz } end
			if px and exp_freeze_pos and math.abs(px - exp_freeze_pos[1]) + math.abs(pz - exp_freeze_pos[2]) > 0.5 then
				exp_frozen, exp_freeze_pos = false, nil
			end
		elseif frame % 30 == 0 and frame - last_dialogue_frame > 90 and frame - battle_seen_frame > 120 then snapshot_experience() end
		read_dialogue()
		read_menu()
		read_yesno()
		read_battle_phase()
		watch_battle_actor()
		read_title()
		read_equip_screen()
		read_layout()
		read_ui_screen()
		read_records_menu(pad)
		read_choice()
		read_create()
		watch_attributes(pad)
		if frame % 15 == 0 then watch_events() end
		if pad.a and not pad_prev_a2 and not in_battle() and frame - last_menu_frame > 30 then pcall(mark_searched) end
		pad_prev_a2 = pad.a
		read_name_entry()
		track_map()
		if not walk then alerts(pad) end
		handle_keys()
		walk_step(controller_pressed)
		route_step()
		nav_prefetch()
	end)
	if not ok and tostring(err) ~= last_error then
		last_error = tostring(err)
		console.log("dq9-access error: " .. last_error)
		log_line("ERROR " .. last_error)
	end
	emu.frameadvance()
end
